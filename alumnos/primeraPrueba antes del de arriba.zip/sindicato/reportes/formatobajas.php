<?php 
include_once "../model/seg_catpermisos.php";
ob_start();
@session_start();
include('../components/fpdf/fpdf.php');

$UsuarioID =$_SESSION['UsuarioID'];

@$FechaInicial=$_REQUEST['FechaInicial'];
@$FechaFinal=$_REQUEST['FechaFinal'];
@$AgrupacionID =base64_decode($_REQUEST['QWdydXBhY2lvbklE']);
@$AgrupacionID_adv =base64_decode($_REQUEST['QWdydXBhY2lvbklE']);
@$AreaID = base64_decode($_REQUEST['QXJlYUlE']);
@$AreaID_adv=base64_decode($_REQUEST['QXJlYUlE']);
@$TipoNominaID=base64_decode($_REQUEST['VGlwb05vbWluYUlE']);
@$DepartamentoID=$_REQUEST['RGVwYXJ0YW1lbnRvSUQ='];
$Movimiento="BAJA";

$seg_catpermisos = new grid_funciones($AgrupacionID,$TipoNominaID,$UsuarioID,$AreaID,$DepartamentoID,$FechaInicial,$FechaFinal,$Movimiento);
$r = $seg_catpermisos->reporte_alta_baja();
/*
    $ArregloTotal[0][0] $d['Codigo'];
    $ArregloTotal[0][1] $d['Empleado'],
    $ArregloTotal[0][2] $d['Departamento'],
    $ArregloTotal[0][3] $d['Area'],
    $ArregloTotal[0][4] $d['Puesto'],
    $ArregloTotal[0][5] $d['Fecha'],
    $ArregloTotal[0][6] $d['Movimiento'],
    $ArregloTotal[0][8] $d['TipoNomina']
    $ArregloTotal[0][9] $d['Agrupacion']
*/
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();

$agrupa="";
$tem2="";
$depa="";
$tipnom="";
$cont=0;
    foreach ($r as $datos) {
$agrupa=$datos['Agrupacion'];
$tem2=$datos['Area'];
$depa=$datos['Departamento'];
//$suc=$datos['Sucursal'];
$tipnom=$datos['TipoNomina'];
}
$pdf->SetFont('Arial','B',10);
$pdf->Cell(100,10,"REPORTE DE BAJAS DE PERSONAL ",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(100,5,"Periodo del: ".$FechaInicial." al ".$FechaFinal,0,0,"L");
$pdf->Cell(90,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");
$pdf->Ln();
$Nombre = $_SESSION['Nombre'];
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID_adv>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"C"); }
    	if($AreaID_adv > 0){$pdf->Cell(40,5,$tem2,0,0,"C"); }
    	//if($SucursalID > 0){ $pdf->Cell(40,5,$suc,0,0,"C"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"C"); }
    	$cont=$cont+20;
$pdf->Ln();
$pdf->SetFont('Arial','B',10);
		$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
		$pdf->Ln();
$pdf->Cell(20,5,"ID",0,0,"L");
		$pdf->Cell(75,5,"Nombre",0,0,"L");
		$pdf->Cell(55,5,"Puesto",0,0,"L");
		$pdf->Cell(45,5,"Fecha movimiento",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,1,'_________________________________________________________________________________________________',0,0,"L");
		$cont=$cont+15;
		$pdf->Ln();

$areaant="";
$departamentoant="";
foreach ($r as $d) {
if ($cont>220) {
$cont=0;
	$pdf->AddPage();
	$pdf->SetFont('Arial','B',10);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(100,10,"Periodo del: ".$FechaInicial." al ".$FechaFinal,0,0,"L");
$pdf->Cell(100,10,"REPORTE DE BAJAS DE PERSONAL ",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(90,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");
$pdf->Ln();
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID_adv>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"C"); }
    	if($AreaID_adv > 0){$pdf->Cell(40,5,$tem2,0,0,"C"); }
    	//if($SucursalID > 0){ $pdf->Cell(40,5,$suc,0,0,"C"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"C"); }
    	$cont=$cont+20;
$pdf->Ln();
$pdf->SetFont('Arial','B',10);
		$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
		$pdf->Ln();
$pdf->Cell(20,5,"ID",0,0,"L");
		$pdf->Cell(75,5,"Nombre",0,0,"L");
		$pdf->Cell(55,5,"Puesto",0,0,"L");
		$pdf->Cell(45,5,"Fecha movimiento",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,1,'_________________________________________________________________________________________________',0,0,"L");
		$cont=$cont+15;
		$pdf->Ln();
}

if($d['Area'] != $areaant){ 
	$areaant=$d['Area'];
	$pdf->Ln();
$pdf->SetFont('Arial','B',10);
$tem=explode(" ", $areaant);
$pdf->Cell(180,5,$areaant,0,0,"C");
$pdf->Ln();
$cont=$cont+8;
}
if($d['Departamento'] != $departamentoant){
	$departamentoant=$d['Departamento'];
	$pdf->Ln();
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(150,5,$departamentoant,0,0,"L");
	$pdf->Ln();
	$cont=$cont+8;
	

}
 $fecha = new DateTime($d1['Fecha']);
 $fecha1=$fecha->format('d/m/Y');
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(20,5,$d['Codigo'],0,0,"L");
		$pdf->Cell(75,5,$d['Empleado'],0,0,"L");
		$pdf->Cell(55,5,$d['Puesto'],0,0,"L");
		$pdf->Cell(45,5,$fecha1,0,0,"L");
		$pdf->Ln();
		$cont=$cont+5;

	
}

$pdf->Ln();
$pdf->Cell(180,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");
$pdf->Output("Reporte_Bajas.pdf",'I');
ob_end_flush(); 
?>