<?php 
include_once "../model/seg_catpermisos.php";
include_once "../model/conexion.php";
include_once '../model/nom_captura.php';
//include_once '../model/nom_reportes.php';
@session_start();

ob_start();
include('../components/fpdf/fpdf.php');

$UsuarioID =$_SESSION['UsuarioID'];

@$FechaInicial=$_REQUEST['FechaInicial'];
@$FechaFinal=$_REQUEST['FechaFinal'];
@$AgrupacionID =base64_decode($_REQUEST['QWdydXBhY2lvbklE']);
@$AgrupacionID_adv =base64_decode($_REQUEST['QWdydXBhY2lvbklE']);
@$AreaID = base64_decode($_REQUEST['QXJlYUlE']);
@$AreaID_adv=base64_decode($_REQUEST['QXJlYUlE']);
@$TipoNominaID=base64_decode($_REQUEST['VGlwb05vbWluYUlE']);
@$DepartamentoID=$_REQUEST['RGVwYXJ0YW1lbnRvSUQ='];
@$BusquedaAvazada=$_REQUEST['BusquedaAvazada']."<br>";


$seg_catpermisos = new seg_catpermisos("","",$UsuarioID,"","");
$r = $seg_catpermisos->get_permisos_user();

$agrupant="";
$areaant="";
$departamentoant="";
$conexion = new conexion();
$sql = "SELECT AgrupacionID, Agrupacion, AreaID, TipoNomina, `Area`, DepartamentoID, Departamento, PuestoID, Puesto,SUM(Activos) AS E, SUM(Altas) AS A, SUM(Bajas) AS B
FROM ( SELECT mp.AgrupacionID,a.Agrupacion, mp.AreaID, n.TipoNomina,ar.Area, mp.DepartamentoID, d.Departamento, pu.PuestoID, pu.Puesto, 0 AS Activos, SUM(IF(LEFT(mo.Movimiento,4) = 'ALTA',1,0)) AS Altas, SUM(IF(LEFT(mo.Movimiento,4) = 'BAJA',1,0)) AS Bajas
    FROM nom_catempleados e
    INNER JOIN nom_catnominas n ON e.TipoNominaID = n.TipoNominaID
    INNER JOIN nom_catperiodos pe ON e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1
    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
    INNER JOIN nom_catagrupaciones a ON mp.AgrupacionID = a.AgrupacionID
    INNER JOIN nom_movpersonal mo ON e.Codigo = mo.Codigo
    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND p.UsuarioID = $UsuarioID AND p.DepartamentoID = mp.DepartamentoID 
    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
    INNER JOIN nom_catpuestos pu ON mp.PuestoID =  pu.PuestoID
    WHERE mo.Fecha BETWEEN '$FechaInicial' AND '$FechaFinal'";
    if($AgrupacionID_adv > 0){ $sql = $sql." AND mp.AgrupacionID = '$AgrupacionID_adv'"; }
    if($TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$TipoNominaID'"; }
    if($AreaID_adv > 0){ $sql = $sql." AND mp.AreaID ='$AreaID'"; }
    if($DepartamentoID > 0){ $sql = $sql." AND mp.DepartamentoID = '$DepartamentoID'"; }

    $sql=$sql." GROUP BY mp.AgrupacionID,a.Agrupacion, mp.AreaID,e.TipoNominaID, ar.Area, mp.DepartamentoID, d.Departamento, pu.PuestoID, pu.Puesto
    UNION ALL
    SELECT mp.AgrupacionID,a.Agrupacion, mp.AreaID,n.TipoNomina, ar.Area, mp.DepartamentoID, d.Departamento, pu.PuestoID, pu.Puesto, COUNT(e.CodigoNominaID) AS Activos, 0 AS Altas, 0 AS Bajas
    FROM nom_catempleados e
    INNER JOIN nom_catnominas n ON e.TipoNominaID = n.TipoNominaID
    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
    INNER JOIN nom_catagrupaciones a ON mp.AgrupacionID = a.AgrupacionID
    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND p.UsuarioID = $UsuarioID
    AND p.DepartamentoID = mp.DepartamentoID 
    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
    INNER JOIN nom_catpuestos pu ON mp.PuestoID =  pu.PuestoID
    WHERE e.Estatus = 'A' ";
    if($AgrupacionID_adv > 0){ $sql = $sql." AND mp.AgrupacionID = '$AgrupacionID_adv'"; }
    if($TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$TipoNominaID'"; }
    if($AreaID_adv > 0){ $sql = $sql." AND mp.AreaID ='$AreaID'"; }
    if($DepartamentoID > 0){ $sql = $sql." AND mp.DepartamentoID = '$DepartamentoID'"; }
    $sql=$sql." GROUP BY mp.AgrupacionID,a.Agrupacion, mp.AreaID, ar.Area, mp.DepartamentoID, d.Departamento, pu.PuestoID, pu.Puesto
    )AS R 
    GROUP BY AgrupacionID, Agrupacion,AreaID, `Area`, DepartamentoID, Departamento, PuestoID, Puesto
    ORDER BY AgrupacionID, AreaID, DepartamentoID, Puesto";
$resp = $conexion->ejecutarconsulta($sql);
// $nom_reportes = new nom_reportes("","","","","","","","","");
// $resp = $nom_reportes->reporte_concentrado();
$agrupa="";
$tem2="";
$depa="";
$tipnom="";
foreach ($resp as $datos) {
$agrupa=$datos['Agrupacion'];
$tem2=$datos['Area'];
$depa=$datos['Departamento'];
//$suc=$datos['Sucursal'];
$tipnom=$datos['TipoNomina'];
}


$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',10);
$cont=0;
// $pdf->Image('../img/imagenes/logo-liga3.jpg',13,13,25,25,'JPG','');
$pdf->Cell(100,10,"REPORTE DE PERSONAL POR PUESTOS",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(190,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");
$pdf->Ln();
$Nombre = $_SESSION['Nombre'];
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID_adv>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"C"); }
    	if($AreaID_adv > 0){$pdf->Cell(40,5,$tem2,0,0,"C"); }
    	//if($SucursalID > 0){ $pdf->Cell(40,5,$suc,0,0,"C"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"C"); }

$pdf->SetFont('Arial','B',10);
$pdf->Ln();
$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
$pdf->Cell(40,5,"Area",0,0,"L");
		$pdf->Cell(50,5,"Departamento",0,0,"L");
		$pdf->Cell(50,5,"Puesto",0,0,"L");
		$pdf->Cell(20,5,"Activos",0,0,"L");
		$pdf->Cell(20,5,"Altas",0,0,"L");
		$pdf->Cell(20,5,"Bajas",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
		$cont=35;
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;
foreach ($resp as $datos) {

if ($cont>370) {
	$pdf->AddPage();
$pdf->SetFont('Arial','B',10);
$cont=0;
// $pdf->Image('../img/imagenes/logo-liga3.jpg',13,13,25,25,'JPG','');
$pdf->Cell(100,10,"REPORTE DE PERSONAL POR PUESTOS",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(190,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");
$pdf->Ln();
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID_adv>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"C"); }
    	if($AreaID_adv > 0){$pdf->Cell(40,5,$tem2,0,0,"C"); }
    	//if($SucursalID > 0){ $pdf->Cell(40,5,$suc,0,0,"C"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"C"); }

$pdf->SetFont('Arial','B',10);
$pdf->Ln();
$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
$pdf->Cell(40,5,"Area",0,0,"L");
		$pdf->Cell(50,5,"Departamento",0,0,"L");
		$pdf->Cell(50,5,"Puesto",0,0,"L");
		$pdf->Cell(20,5,"Activos",0,0,"L");
		$pdf->Cell(20,5,"Altas",0,0,"L");
		$pdf->Cell(20,5,"Bajas",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
		$cont=35;
		$pdf->SetFont('Arial','',8);
		


}



	if($datos['Area'] != $areaant){ 
	if($cont==35){$pdf->Ln();}
	$areaant=$datos['Area'];
		if($contadorVueltas>0){
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_______",0,0,"L");;
		$pdf->Ln();
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(20,5,$contadorActivos,0,0,"C");
		$pdf->Cell(20,5,$contadorAltas,0,0,"C");
		$pdf->Cell(20,5,$contadorBajas,0,0,"C");
		$pdf->Ln();
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;
		$cont=$cont+6;
	
	}
	
	
	$pdf->Ln();
$pdf->SetFont('Arial','B',10);
$tem=$areaant;
$pdf->Cell(50,5,$datos['Area'],0,0,"L");
$pdf->Cell(50,5,"",0,0,"L");
$cont=$cont+5;
$pdf->Ln();
}
if($datos['DepartamentoID'] != $departamentoant){
	$departamentoant=$datos['DepartamentoID'];
	if($contadorVueltas>0){
	if($cont==35){$pdf->Ln();}
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_______",0,0,"L");;
		$pdf->Ln();
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(20,5,$contadorActivos,0,0,"C");
		$pdf->Cell(20,5,$contadorAltas,0,0,"C");
		$pdf->Cell(20,5,$contadorBajas,0,0,"C");
		$pdf->Ln();
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;
		$cont=$cont+6;
	
	}
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,$datos['Departamento'],0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$cont=$cont+5;
	$pdf->Ln();
}
$pdf->SetFont('Arial','',8);
	$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,$datos['Puesto'],0,0,"L");
	$pdf->Cell(20,5,$datos['E'],0,0,"C");
		$pdf->Cell(20,5,$datos['A'],0,0,"C");
		$pdf->Cell(20,5,$datos['B'],0,0,"C");
		$pdf->Ln();
	// 	$pdf->Cell(30,5,"",0,0,"L");
	// $pdf->Cell(30,5,"",0,0,"L");
	// $pdf->Cell(40,5,"",0,0,"L");
	// 	$pdf->Cell(40,5,"",0,0,"L");
	// 	$pdf->Cell(20,5,$datos['E'],0,0,"C");
	// 	$pdf->Cell(20,5,$datos['A'],0,0,"C");
	// 	$pdf->Cell(20,5,$datos['B'],0,0,"C");
	// 	$pdf->Ln();
		$contadorActivos=$contadorActivos+$datos['E'];
		$contadorBajas=$contadorBajas+$datos['B'];
		$contadorAltas=$contadorAltas+$datos['A'];
		$cont=$cont+10;
		$contadorVueltas++;
	

}
$pdf->Ln();

$pdf->Cell(40,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"________",0,0,"L");;
		$pdf->Ln();
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(20,5,$contadorActivos,0,0,"C");
		$pdf->Cell(20,5,$contadorAltas,0,0,"C");
		$pdf->Cell(20,5,$contadorBajas,0,0,"C");
		$pdf->Ln();
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;

$pdf->Output("Recibo_Altas.pdf",'I');

ob_end_flush(); 
?>