<?php 
include_once "../model/seg_catpermisos.php";
ob_start();
@session_start();
include('../components/fpdf/fpdf.php');

$UsuarioID =$_SESSION['UsuarioID'];
@$AgrupacionID =base64_decode($_REQUEST['QWdydXBhY2lvbklE']);
//@$AgrupacionID = $_POST['AgrupacionID'];
@$TipoNominaID=base64_decode($_REQUEST['VGlwb05vbWluYUlE']);
//@$TipoNominaID=$_POST['TipoNominaID'];
//@$AreaID=$_POST['AreaID'];
@$AreaID = base64_decode($_REQUEST['QXJlYUlE']);
@$DepartamentoID=$_REQUEST['RGVwYXJ0YW1lbnRvSUQ='];
//@$DepartamentoID=$_POST['DepartamentoID'];
@$TipoReporte=$_POST['TipoReporte'];

$grid_funciones = new grid_funciones($AgrupacionID,$TipoNominaID,$UsuarioID,$AreaID,$DepartamentoID,"","","");
$r = $grid_funciones->reporte_activo();
/*
    $ArregloTotal[0][0] $d1['Codigo'],
    $ArregloTotal[0][1] $d1['Empleado'],
    $ArregloTotal[0][2] $d1['Departamento'],
    $ArregloTotal[0][3] $d1['Area'],
    $ArregloTotal[0][4] $d1['Puesto'],
    $ArregloTotal[0][5] $d1['FechaIngreso'],
    $ArregloTotal[0][6] $d1['FechaInicial'],
    $ArregloTotal[0][7] $d1['FechaFinal'],
    $ArregloTotal[0][8] $d1['Agrupacion']

*/
$agrupa="";
$tem2="";
$depa="";
$tipnom="";
    foreach ($r as $datos) {
$agrupa=$datos['Agrupacion'];
$tem2=$datos['Area'];
$depa=$datos['Departamento'];
//$suc=$datos['Sucursal'];
$tipnom=$datos['TipoNomina'];
}

$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',12);
$cont=0;
// $pdf->Image('../img/imagenes/logo-liga3.jpg',13,13,25,25,'JPG','');
//$pdf->Cell(100,10,"Activos de trabajadores",0,0,"L");

#$pdf->Cell(100,10,"Periodo del: ".$fch_ini." al ".$fch_fin,0,0,"L");
//$pdf->Ln();
//$cont=$cont+20;

$pdf->SetFont('Arial','B',10);
$pdf->Cell(100,10,"REPORTE DE PERSONAL ACTIVO",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(190,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");
$pdf->Ln();
$Nombre = $_SESSION['Nombre'];
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"C"); }
    	if($AreaID > 0){$pdf->Cell(40,5,$tem2,0,0,"C"); }
    	//if($SucursalID > 0){ $pdf->Cell(40,5,$suc,0,0,"C"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"C"); }
    	$cont=$cont+20;
$pdf->Ln();
$pdf->SetFont('Arial','B',10);
		$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
		$pdf->Ln();
$pdf->Cell(20,5,"ID",0,0,"L");
		$pdf->Cell(75,5,"Nombre",0,0,"L");
		$pdf->Cell(55,5,"Puesto",0,0,"L");
		$pdf->Cell(45,5,"Fecha Ingreso",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,1,'_________________________________________________________________________________________________',0,0,"L");
		$cont=$cont+15;
		$pdf->Ln();

$areaant="";
$departamentoant="";
foreach ($r as $d1) {
if ($cont>230) {
$cont=0;

	$pdf->AddPage();
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(100,10,"REPORTE DE PERSONAL ACTIVO",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(190,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");
$pdf->Ln();
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"C"); }
    	if($AreaID > 0){$pdf->Cell(40,5,$tem2,0,0,"C"); }
    	//if($SucursalID > 0){ $pdf->Cell(40,5,$suc,0,0,"C"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"C"); }
    	$cont=$cont+20;
	$pdf->Ln();
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
$pdf->Cell(20,5,"ID",0,0,"L");
		$pdf->Cell(75,5,"Nombre",0,0,"L");
		$pdf->Cell(55,5,"Puesto",0,0,"L");
		$pdf->Cell(45,5,"Fecha Ingreso",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,1,'_________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
		$cont=$cont+15;


}

if($d1['Area'] != $areaant){ 
	$areaant=$d1['Area'];
	$pdf->Ln();
$pdf->SetFont('Arial','B',10);
$tem=explode(" ", $areaant);
$pdf->Cell(180,5,$areaant,0,0,"L");
$pdf->Ln();
$cont=$cont+8;
}
if($d1['Departamento'] != $departamentoant){
	$departamentoant=$d1['Departamento'];
	$pdf->Ln();
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(150,5,$departamentoant,0,0,"L");
	$pdf->Ln();
	$cont=$cont+8;
	

}
$fecha = new DateTime($d1['FechaIngreso']);
 $fecha1=$fecha->format('d/m/Y');
 
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(20,5,$d1['Codigo'],0,0,"L");
		$pdf->Cell(75,5,$d1['Empleado'],0,0,"L");
		$pdf->Cell(55,5,$d1['Puesto'],0,0,"L");
		$pdf->Cell(45,5,$fecha1,0,0,"L");
		$pdf->Ln();
		$cont=$cont+5;

	
}

$pdf->Ln();

$pdf->Output("Reporte_Activos.pdf",'I');
ob_end_flush(); 
?>