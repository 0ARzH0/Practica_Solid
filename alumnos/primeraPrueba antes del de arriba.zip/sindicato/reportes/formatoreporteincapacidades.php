<?php 
include_once "../model/seg_catpermisos.php";
include_once "../model/nom_catdepartamentos.php";
include_once "../model/nom_catnominas.php";
include_once "../model/nom_catareas.php";
include_once "../model/nom_catagrupaciones.php";
ob_start();
@session_start();
include('../components/fpdf/fpdf.php');

$UsuarioID =$_SESSION['UsuarioID'];

@$FechaInicial=$_REQUEST['FechaInicial'];
@$FechaFinal=$_REQUEST['FechaFinal'];
@$AgrupacionID =base64_decode($_REQUEST['QWdydXBhY2lvbklE']);
@$AgrupacionID_adv =base64_decode($_REQUEST['QWdydXBhY2lvbklE']);
@$AreaID = base64_decode($_REQUEST['QXJlYUlE']);
@$AreaID_adv=base64_decode($_REQUEST['QXJlYUlE']);
@$TipoNominaID=base64_decode($_REQUEST['VGlwb05vbWluYUlE']);
@$DepartamentoID=$_REQUEST['RGVwYXJ0YW1lbnRvSUQ='];

$grid_funciones = new grid_funciones($AgrupacionID_adv,$TipoNominaID,$UsuarioID,$AreaID_adv,$DepartamentoID,$fch_ini,$fch_fin,"");

$rfi= date_create($fch_ini);
$rfic=date_format($rfi, 'd/m/Y');
$rff= date_create($fch_fin);
$rffc=date_format($rff, 'd/m/Y');

$pdf=new FPDF('L','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',12);
$cont=0;
// $pdf->Image('../img/imagenes/logo-liga3.jpg',13,13,25,25,'JPG','');
$pdf->Cell(200,10,"Reporte de incapacidades",0,0,"L");
$pdf->Cell(275,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"L");
$pdf->Ln();
$Nombre = $_SESSION['Nombre'];
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");
$pdf->SetFont('Arial','B',10);
$pdf->Ln();
$pdf->Cell(100,10,"Periodo del: "."$rfic"." al "."$rffc",0,0,"L");
$pdf->Ln();
$cont=$cont+20;

if($AgrupacionID_adv>0){
      $nom_catagrupaciones = new nom_catagrupaciones($AgrupacionID_adv,"","","","","","","","","","","","","","","","","");
      $r= $nom_catagrupaciones->get_agrupacion();
      foreach ($r as $d) {
        $agrupacion=$d['Agrupacion'];
      }  
      $pdf->SetFont('Arial','B',8);  
      $pdf->Cell(50,5,"Agrupacion: ".$agrupacion,0,0,"L");           
}

if($TipoNominaID>0){
      $nom_catnominas= new nom_catnominas($TipoNominaID,"");
      $q=$nom_catnominas->get_tiponomina();
      foreach ($q as $d2) {
        $TipoNomina=$d2['TipoNomina'];
      }
      $pdf->SetFont('Arial','B',8);  
      $pdf->Cell(50,5,"Tipo nomina: ".$TipoNomina,0,0,"L");
  } 
  
  if($AreaID_adv>0){
      $nom_catareas = new nom_catareas($AreaID_adv,"","","","","");
      $a = $nom_catareas -> get_area();
      foreach ($a as $d3) {
        $Area=$d3['Area'];
      }
      $pdf->SetFont('Arial','B',8);  
      $pdf->Cell(50,5,"Area: ".$Area,0,0,"L");
  } 

  if($DepartamentoID>0){
      $nom_catdepartamentos= new nom_catdepartamentos($DepartamentoID,"","","","","");
      $t=$nom_catdepartamentos->get_departamento();
      foreach ($t as $d5) {
        $Departamento=$d5['Departamento'];
      }
      $pdf->SetFont('Arial','B',8);  
      $pdf->Cell(50,5,"Departamento: ".$Departamento,0,0,"L");  
  } 
if($AgrupacionID_adv>0||$TipoNominaID>0||$AreaID_adv>0||$DepartamentoID>0){
    $cont=$cont+5;
    $pdf->Ln();
}

$regpatant="";
$incapacidades = $grid_funciones->formatoincapacidades();
$pdf->SetFont('Arial','B',10);
$pdf->Cell(350,5,'___________________________________________________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
$pdf->Cell(20,5,"IMSS",0,0,"L");
$pdf->Cell(80,5,"Empleado",0,0,"L");
$pdf->Cell(20,5,"Referencia",0,0,"L");
$pdf->Cell(25,5,"Dias de",0,0,"L");
$pdf->Cell(25,5,"Fecha",0,0,"L");
$pdf->Cell(25,5,"Fecha",0,0,"L");
$pdf->Cell(30,5,"Rama",0,0,"L");
$pdf->Cell(50,5,"Area",0,0,"L");
$pdf->Ln();
$pdf->Cell(20,5,"",0,0,"L");
$pdf->Cell(80,5,"",0,0,"L");
$pdf->Cell(20,5,"",0,0,"L");
$pdf->Cell(25,5,"incapacidad",0,0,"L");
$pdf->Cell(25,5,"inicial",0,0,"L");
$pdf->Cell(25,5,"final",0,0,"L");
$pdf->Cell(30,5,"incapacidad",0,0,"L");
$pdf->Cell(50,5,"",0,0,"L");
$pdf->Ln();
$pdf->Cell(350,3,'___________________________________________________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
$cont=$cont+20;





foreach ($incapacidades as $dato) {
    /*$Regpat=$dato['RegistroPatronal'];
    if ($regpatant!=$Regpat) {
        $pdf->SetFont('Arial','B',10);
        $pdf->Ln();
        $pdf->Cell(100,5,"Registro patronal  ".$dato['RegistroPatronal'],0,0,"B");
        $pdf->Ln();
        $regpatant=$Regpat;
        $cont=$cont+5;
    }*/
  $pdf->SetFont('Arial','',8);
	$pdf->Cell(20,5,$dato['Imss'],0,0,"L");
	$pdf->Cell(80,5,$dato['CodigoNominaID']."	".$dato['Empleado'],0,0,"L");
	$pdf->Cell(20,5,$dato['SerieFolio'],0,0,"L");
	$pdf->Cell(25,5,$dato['DiasAutorizados'],0,0,"L");
    $FI= date_create($dato['ApartirDel']);
    $FIC=date_format($FI, 'd/m/Y');
	$pdf->Cell(25,5,$FIC,0,0,"L");
    $FF=date_create($dato['FechaFin']);
    $FFC=date_format($FF, 'd/m/Y');
	$pdf->Cell(25,5,$FFC,0,0,"L");
	$pdf->Cell(30,5,$dato['RamoSeguro'],0,0,"L");
	$pdf->Cell(50,5,$dato['Area'],0,0,"L");
	$pdf->Ln();
    $cont=$cont+5;
    if ($cont>175) {
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(200,10,"Reporte de incapacidades",0,0,"L");
        $pdf->Cell(275,5,utf8_decode("Fecha de generación ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"L");
        $pdf->Ln();
$pdf->Cell(190,5,utf8_decode("Generado Por ").$Nombre,0,0,"R");
        $pdf->SetFont('Arial','B',10);
        $pdf->Ln();
        $pdf->Cell(100,10,"Periodo del: "."$rfic"." al "."$rffc",0,0,"L");
        $pdf->Ln();
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(350,5,'___________________________________________________________________________________________________________________________________________',0,0,"L");
        $pdf->Ln();
        $pdf->Cell(20,5,"IMSS",0,0,"L");
        $pdf->Cell(80,5,"Empleado",0,0,"L");
        $pdf->Cell(20,5,"Referencia",0,0,"L");
        $pdf->Cell(25,5,"Dias de",0,0,"L");
        $pdf->Cell(25,5,"Fecha",0,0,"L");
        $pdf->Cell(25,5,"Fecha",0,0,"L");
        $pdf->Cell(30,5,"Rama",0,0,"L");
        $pdf->Cell(50,5,"Area",0,0,"L");
        $pdf->Ln();
        $pdf->Cell(20,5,"",0,0,"L");
        $pdf->Cell(80,5,"",0,0,"L");
        $pdf->Cell(20,5,"",0,0,"L");
        $pdf->Cell(25,5,"incapacidad",0,0,"L");
        $pdf->Cell(25,5,"inicial",0,0,"L");
        $pdf->Cell(25,5,"final",0,0,"L");
        $pdf->Cell(30,5,"incapacidad",0,0,"L");
        $pdf->Cell(50,5,"",0,0,"L");
        $pdf->Ln();
        $pdf->Cell(350,3,'___________________________________________________________________________________________________________________________________________',0,0,"L");
        $pdf->Ln();
        /*$pdf->Cell(100,5,"Registro patronal  ".$dato['RegistroPatronal'],0,0,"B");
        $pdf->Ln();*/
        $cont=45;
    }
}

$pdf->Output("Reporte_de_incapacidades.pdf",'I');
ob_end_flush(); 
?>