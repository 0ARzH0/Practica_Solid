<?php

include_once 'conexion.php';

class nom_movpersonal{

var $Codigo;
var $Movimiento;
var $Fecha;
var $Sueldo;
var $SueldoIntegrado;

function nom_movpersonal($Codigo,$Movimiento,$Fecha,$Sueldo,$SueldoIntegrado){

$this->Codigo=$Codigo;
$this->Movimiento=$Movimiento;
$this->Fecha=$Fecha;
$this->Sueldo=$Sueldo;
$this->SueldoIntegrado=$SueldoIntegrado;

}
function show_nom_movpersonal(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_movpersonal");
return $resp;
}
function add_nom_movpersonal(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_movpersonal (Codigo,Movimiento,Fecha,Sueldo,SueldoIntegrado) VALUES ('$this->Codigo' ,'$this->Movimiento' ,'$this->Fecha' ,'$this->Sueldo' ,'$this->SueldoIntegrado' ) ");
return $resp;
}
function mod_nom_movpersonal(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_movpersonal SET Codigo='$this->Codigo', Movimiento='$this->Movimiento', Fecha='$this->Fecha', Sueldo='$this->Sueldo', SueldoIntegrado='$this->SueldoIntegrado'   WHERE Codigo = '$this->Codigo'");
return $resp;
}
function del_nom_movpersonal(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_movpersonal WHERE Codigo = '$this->Codigo' ");
return $resp;
}
}
?>
