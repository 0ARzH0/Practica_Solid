<?php 

include_once "conexion.php";

class seg_catusuarios{

var $UsuarioID;
var $Nombre;
var $Usuario;
var $Password;
var $TipoUsuario;

function seg_catusuarios($UsuarioID,$Nombre,$Usuario,$Password,$TipoUsuario){

$this->UsuarioID=$UsuarioID;
$this->Nombre=$Nombre;
$this->Usuario=$Usuario;
$this->Password=$Password;
$this->TipoUsuario=$TipoUsuario;

}

function show_usuarios(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM seg_catusuarios");
return $resp;
}
function get_usuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM seg_catusuarios WHERE UsuarioID='$this->UsuarioID'");
return $resp;
}
function bus_usuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM seg_catusuarios WHERE Usuario LIKE '%$this->Usuario%'");
return $resp;
}
function get_usuario_nom(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM seg_catusuarios WHERE Usuario='$this->Usuario'");
return $resp;
}
function get_usuario_pass(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM seg_catusuarios WHERE Password='$this->Password'");
return $resp;
}
function iniciar_usuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM seg_catusuarios WHERE Password='$this->Password' AND Usuario='$this->Usuario' ");
return $resp;
}
function mod_usuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE seg_catusuarios SET Usuario='$this->Usuario',Nombre
= '$this->Nombre' ,Password='$this->Password' WHERE UsuarioID='$this->UsuarioID' ");
return $resp;
}
function add_usuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO seg_catusuarios (Nombre,Usuario,Password,TipoUsuario) VALUES ('$this->Nombre','$this->Usuario','$this->Password','$this->TipoUsuario') ");
return $resp;
}
}
?>
