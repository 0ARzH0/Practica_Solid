<?php

include_once 'conexion.php';

class bit_catdias{

var $DiaID;
var $Dia;
var $DiaID;

function bit_catdias($DiaID,$Dia,$DiaID){

$this->DiaID=$DiaID;
$this->Dia=$Dia;
$this->DiaID=$DiaID;

}

function show_bit_catdias(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM bit_catdias");
return $resp;
}
function add_bit_catdias(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO bit_catdias (DiaID,Dia,DiaID) VALUES ('$this->DiaID' ,'$this->Dia' ,'$this->DiaID' ) ");
return $resp;
}
function mod_bit_catdias(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE bit_catdias SET DiaID='$this->DiaID', Dia='$this->Dia', DiaID='$this->DiaID'   WHERE DiaID = '$this->DiaID'");
return $resp;
}
function del_bit_catdias(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM bit_catdias WHERE DiaID = '$this->DiaID' ");
return $resp;
}
}
?>
