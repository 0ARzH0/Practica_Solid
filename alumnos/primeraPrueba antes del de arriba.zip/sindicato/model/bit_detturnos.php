<?php

include_once 'conexion.php';

class bit_detturnos{

var $DetTurnoID;
var $TurnoID;
var $DiaID;
var $Entrada;
var $Salida;
var $EntradaMD;
var $SalidaMD;
var $Descanso;

function bit_detturnos($DetTurnoID,$TurnoID,$DiaID,$Entrada,$Salida,$EntradaMD,$SalidaMD,$Descanso){

$this->DetTurnoID=$DetTurnoID;
$this->TurnoID=$TurnoID;
$this->DiaID=$DiaID;
$this->Entrada=$Entrada;
$this->Salida=$Salida;
$this->EntradaMD=$EntradaMD;
$this->SalidaMD=$SalidaMD;
$this->Descanso=$Descanso;

}

function show_bit_detturnos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM bit_detturnos");
return $resp;
}
function add_detturnos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO bit_detturnos (DetTurnoID,TurnoID,DiaID,Entrada,Salida,EntradaMD,SalidaMD,Descanso) VALUES ('$this->DetTurnoID' ,'$this->TurnoID' ,'$this->DiaID' ,'$this->Entrada' ,'$this->Salida' ,'$this->EntradaMD' ,'$this->SalidaMD' ,'$this->Descanso' ) ");
return $resp;
}
function mod_bit_detturnos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE bit_detturnos SET DetTurnoID='$this->DetTurnoID', TurnoID='$this->TurnoID', DiaID='$this->DiaID', Entrada='$this->Entrada', Salida='$this->Salida', EntradaMD='$this->EntradaMD', SalidaMD='$this->SalidaMD', Descanso='$this->Descanso' WHERE DetTurnoID = '$this->DetTurnoID'");
return $resp;
}
function del_bit_detturnos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM bit_detturnos WHERE DetTurnoID = '$this->DetTurnoID' ");
return $resp;
}
}
?>
