<?php

include_once 'conexion.php';

class nom_catbancos{

var $BancoID;
var $Banco;
var $Cuenta;
var $Clabe;
var $Contrato;
var $FormatoAscii;
var $ClaveBanco;

function nom_catbancos($BancoID,$Banco,$Cuenta,$Clabe,$Contrato,$FormatoAscii,$ClaveBanco){

$this->BancoID=$BancoID;
$this->Banco=$Banco;
$this->Cuenta=$Cuenta;
$this->Clabe=$Clabe;
$this->Contrato=$Contrato;
$this->FormatoAscii=$FormatoAscii;
$this->ClaveBanco=$ClaveBanco;

}

function show_bancos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catbancos");
return $resp;
}
function add_nom_catbancos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catbancos (BancoID,Banco,Cuenta,Clabe,Contrato,FormatoAscii,ClaveBanco) VALUES ('$this->BancoID' ,'$this->Banco' ,'$this->Cuenta' ,'$this->Clabe' ,'$this->Contrato' ,'$this->FormatoAscii' ,'$this->ClaveBanco' ) ");
return $resp;
}
function mod_nom_catbancos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catbancos SET BancoID='$this->BancoID', Banco='$this->Banco', Cuenta='$this->Cuenta', Clabe='$this->Clabe', Contrato='$this->Contrato', FormatoAscii='$this->FormatoAscii', ClaveBanco='$this->ClaveBanco'   WHERE BancoID = '$this->BancoID'");
return $resp;
}
function del_nom_catbancos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catbancos WHERE BancoID = '$this->BancoID' ");
return $resp;
}
}
?>
