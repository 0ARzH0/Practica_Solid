<?php

include_once 'conexion.php';

class nom_catdepartamentos{

var $DepartamentoID;
var $Departamento;
var $Creo;
var $FechaCreo;
var $Modifico;
var $FechaModifico;

function nom_catdepartamentos($DepartamentoID,$Departamento,$Creo,$FechaCreo,$Modifico,$FechaModifico){

$this->DepartamentoID=$DepartamentoID;
$this->Departamento=$Departamento;
$this->Creo=$Creo;
$this->FechaCreo=$FechaCreo;
$this->Modifico=$Modifico;
$this->FechaModifico=$FechaModifico;

}
function get_departamento(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catdepartamentos WHERE DepartamentoID = '$this->DepartamentoID' ");
return $resp;
}
function show_nom_catdepartamentos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catdepartamentos");
return $resp;
}
function add_nom_catdepartamentos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catdepartamentos (DepartamentoID,Departamento,Creo,FechaCreo,Modifico,FechaModifico) VALUES ('$this->DepartamentoID' ,'$this->Departamento' ,'$this->Creo' ,'$this->FechaCreo' ,'$this->Modifico' ,'$this->FechaModifico') ");
return $resp;
}
function mod_nom_catdepartamentos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catdepartamentos SET DepartamentoID='$this->DepartamentoID', Departamento='$this->Departamento', Creo='$this->Creo', FechaCreo='$this->FechaCreo', Modifico='$this->Modifico', FechaModifico='$this->FechaModifico' WHERE DepartamentoID = '$this->DepartamentoID'");
return $resp;
}
function del_nom_catdepartamentos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catdepartamentos WHERE DepartamentoID = '$this->DepartamentoID' ");
return $resp;
}
}
?>
