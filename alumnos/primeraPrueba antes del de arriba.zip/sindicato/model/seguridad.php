<?php 
$permiso_negado = 0;
$ver = $_SESSION['Verificar'];
$TipoUsuario = @$_SESSION['TipoUsuario'];
$archivo = explode("/",$_SERVER["REQUEST_URI"]);
$nom_archivo =  explode(".", $archivo[3]);
if(!file_exists("../".$archivo[2]."/".$nom_archivo[0].".php")){
#error de pagina no encontrada
}else{
/*validar que puede ver cada usuario*/
if($TipoUsuario == 1 && $nom_archivo[0]=='admin_incidencias'){
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='editarempleado') {
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='menu') {
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='modal') {
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='ordenacionconceptos') {
$permiso_negado++;
}elseif ($TipoUsuario == 2 && $nom_archivo[0]=='ordenacionconceptos') {
$permiso_negado++;
}elseif ($TipoUsuario == 3 && $nom_archivo[0]=='ordenacionconceptos') {
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='verdiasfestivos') {
$permiso_negado++;
}elseif ($TipoUsuario == 2 && $nom_archivo[0]=='verdiasfestivos') {
$permiso_negado++;
}elseif ($TipoUsuario == 3 && $nom_archivo[0]=='verdiasfestivos') {
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='verempleados') {
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='verpermisos') {
$permiso_negado++;
}elseif ($TipoUsuario == 2 && $nom_archivo[0]=='verpermisos') {
$permiso_negado++;
}elseif ($TipoUsuario == 3 && $nom_archivo[0]=='verpermisos') {
$permiso_negado++;
}elseif ($TipoUsuario == 1 && $nom_archivo[0]=='verturnos') {
$permiso_negado++;
}elseif ($ver == null){
$permiso_negado++;	
}

if($permiso_negado>0){
$permiso_negado;	
#no tiene permisos para acceder a esta pagina
session_destroy();	
header("Location:../views/login.php?msj=23");	
}

}

?>