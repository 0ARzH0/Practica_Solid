<?php

include_once 'conexion.php';

class nom_catintegrados{

var $AgrupacionID;
var $AnioInicial;
var $AnioFinal;
var $PrimaVac;
var $Aguinaldo;
var $PTU;
var $Vacaciones;
var $Adicionales;

function nom_catintegrados($AgrupacionID,$AnioInicial,$AnioFinal,$PrimaVac,$Aguinaldo,$PTU,$Vacaciones,$Adicionales){

$this->AgrupacionID=$AgrupacionID;
$this->AnioInicial=$AnioInicial;
$this->AnioFinal=$AnioFinal;
$this->PrimaVac=$PrimaVac;
$this->Aguinaldo=$Aguinaldo;
$this->PTU=$PTU;
$this->Vacaciones=$Vacaciones;
$this->Adicionales=$Adicionales;

}
function get_dias_vac_agr(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM nom_catintegrados WHERE AgrupacionID='$this->AgrupacionID'");
return $resp;
}
function show_nom_catintegrados(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catintegrados");
return $resp;
}
function add_nom_catintegrados(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catintegrados (AgrupacionID,AnioInicial,AnioFinal,PrimaVac,Aguinaldo,PTU,Vacaciones,Adicionales) VALUES ('$this->AgrupacionID' ,'$this->AnioInicial' ,'$this->AnioFinal' ,'$this->PrimaVac' ,'$this->Aguinaldo' ,'$this->PTU' ,'$this->Vacaciones' ,'$this->Adicionales' ) ");
return $resp;
}
function mod_nom_catintegrados(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catintegrados SET AgrupacionID='$this->AgrupacionID', AnioInicial='$this->AnioInicial', AnioFinal='$this->AnioFinal', PrimaVac='$this->PrimaVac', Aguinaldo='$this->Aguinaldo', PTU='$this->PTU', Vacaciones='$this->Vacaciones', Adicionales='$this->Adicionales' WHERE AgrupacionID = '$this->AgrupacionID'");
return $resp;
}
function del_nom_catintegrados(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catintegrados WHERE AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
}
?>
