<?php 
include_once 'nom_captura.php';
include_once 'seg_catpermisos.php';
include_once 'nom_catempleados.php';
include_once 'nom_catintegrados.php';
include_once 'vistas.php';
include_once 'nom_catnominas.php';
include_once "nom_catdepartamentos.php";
include_once "nom_catareas.php";
include_once "nom_catagrupaciones.php";

function grid_captura($UsuarioID,$AgrupacionID,$TipoNominaID,$AreaID,$DepartamentoID,$BusquedaAvazada){
#Parametros
$Arreglo_Empl_adv = array();
$Arreglo_Empl = array();
$Arreglo_Conc = array();
$Arreglo_Busqueda = array();
$AgrupacionID_ini = "";
$AreaID_ini = "";
$TipoNominaID_ini = "";

#conceptos
$cont_conc = 0;
if($BusquedaAvazada > 0){
$nom_captura = new nom_captura($AgrupacionID,$AreaID,"","");  
}else{
#busqueda default
$Movimiento = "LIMIT 1";    
$grid_funciones = new grid_funciones("","",$UsuarioID,"","","","",$Movimiento);
$r = $grid_funciones->get_empleados_user();
foreach ($r as $d) {
$AgrupacionID_ini = $d['AgrupacionID'];
$AreaID_ini = $d['AreaID'];
$TipoNominaID_ini = $d['TipoNominaID'];
}   
$nom_captura = new nom_captura($AgrupacionID_ini,$AreaID_ini,"","");
}
$r = $nom_captura->get_conceptos();
foreach ($r as $d) {
    $Arreglo_Conc[$cont_conc] = array(
    "ConceptoID" => $d['ConceptoID'],  
    "Concepto" => $d['Concepto'],
    "Importe" => $d['Importe'],
    "Unidades" => $d['Unidades'],
    "Saldos" => $d['Saldos']);
    $cont_conc++;    
}

#busqueda global
$cont_bus = 0;
$grid_funciones = new grid_funciones("","",$UsuarioID,"","","","","");
$r = $grid_funciones->get_empleados_user();
foreach ($r as $d) {

    $Arreglo_Busqueda[$cont_bus] = array(
    $d['TipoNominaID'],
    $d['AreaID'],
    $d['DepartamentoID'],
    $d['AgrupacionID']);
    $cont_bus ++;
    
}
$cont_empl = 0;
$cont_empl_adv = 0;
if($BusquedaAvazada > 0){
$grid_funciones = new grid_funciones($AgrupacionID,$TipoNominaID,$UsuarioID,$AreaID,$DepartamentoID,"","","");
$r = $grid_funciones->get_empleados_user();
foreach ($r as $d) {

    $Arreglo_Empl_adv[$cont_empl_adv] = array(
    "Codigo" => $d['Codigo'],
    "Empleado" => utf8_encode($d['Empleado']),
    "Departamento" => utf8_encode($d['Departamento']),
    "TipoNomina" => $d['TipoNomina'],
    "TipoNominaID" => $d['TipoNominaID'],
    "PeriodoID" => $d['PeriodoID'],
    "FechaInicial" => $d['FechaInicial'],
    "FechaFinal" => $d['FechaFinal'],
    "Ejercicio" => $d['Ejercicio'],
    "AgrupacionID" => $d['AgrupacionID'],
    "Agrupacion" => utf8_encode($d['Agrupacion']),
    "Bloqueado" => $d['Bloqueado']);
    $cont_empl_adv ++;
}
}else{
#empleados
$grid_funciones = new grid_funciones($AgrupacionID_ini,$TipoNominaID_ini,$UsuarioID,"","","","","");
$r = $grid_funciones->get_empleados_user();
foreach ($r as $d) {

    $Arreglo_Empl[$cont_empl] = array(
    "Codigo" => $d['Codigo'],
    "Empleado" => utf8_encode($d['Empleado']),
    "Departamento" => utf8_encode($d['Departamento']),
    "TipoNomina" => $d['TipoNomina'],
    "TipoNominaID" => $d['TipoNominaID'],
    "PeriodoID" => $d['PeriodoID'],
    "FechaInicial" => $d['FechaInicial'],
    "FechaFinal" => $d['FechaFinal'],
    "Ejercicio" => $d['Ejercicio'],
    "AgrupacionID" => $d['AgrupacionID'],
    "Agrupacion" => utf8_encode($d['Agrupacion']),
    "Bloqueado" => $d['Bloqueado']);
    $cont_empl ++;
}    
}

#arreglo para las busquedas
for ($i=0; $i < count($Arreglo_Busqueda) ; $i++) {
@$tiposdenomina[$i] =  $Arreglo_Busqueda[$i][0];
}
#limpiamos y reindexamos los indices
@$id_tiponominas = array_values(array_unique($tiposdenomina)); 

#return de arreglos
$ArregloTotal = array($Arreglo_Conc,$Arreglo_Empl,$id_tiponominas,$Arreglo_Empl_adv);
return $ArregloTotal;
}

/*function formato_reportes($UsuarioID,$AgrupacionID,$TipoNominaID,$AreaID,$SucursalID,$DepartamentoID,$FechaInicial,$FechaFinal,$Movimiento,$TipoReporte){
$cont_rep = 0;
$Arreglo_Reporte = array(); 
$grid_funciones_plus = new grid_funciones_plus($AgrupacionID,$TipoNominaID,$UsuarioID,$AreaID,$SucursalID,$DepartamentoID,$FechaInicial,$FechaFinal,$Movimiento);
if($TipoReporte == 2 || $TipoReporte == 3){
$r1 = $grid_funciones_plus->reporte_alta_baja();
foreach ($r1 as $d1) {
    $Arreglo_Reporte[$cont_rep] = array(
    $d1['Codigo'],
    $d1['Empleado'],
    $d1['Departamento'],
    $d1['Area'],
    $d1['Puesto'],
    $d1['Fecha'],
    $d1['Movimiento'],
    $d1['FechaInicial'],
    $d1['FechaFinal'],
    $d1['Agrupacion']
    );
    $cont_rep ++;
}
}elseif($TipoReporte==1){
$r1 = $grid_funciones_plus->reporte_activo();
foreach ($r1 as $d1) {
    $Arreglo_Reporte[$cont_rep] = array(
    $d1['Codigo'],
    $d1['Empleado'],
    $d1['Departamento'],
    $d1['Area'],
    $d1['Puesto'],
    $d1['FechaIngreso'],
    $d1['FechaInicial'],
    $d1['FechaFinal'],
    $d1['Agrupacion']
    );
    $cont_rep ++;
}
}
return $Arreglo_Reporte;
}*/


function val_vac_empl($Codigo){
$nom_catempleados = new nom_catempleados($Codigo,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
$r = $nom_catempleados->get_empl_cod();
foreach ($r as $d) { 
$Codigo = $d['Codigo'];
$Empleado = utf8_encode($d['Empleado']);
$Puesto = utf8_encode($d['Puesto']);
$Telefono = $d['Telefono'];
$FechaIngreso = $d['FechaIngreso'];
$FechaIngresoEmpl = $d['FechaIngreso'];   
$AgrupacionIDEmpl = $d['AgrupacionID'];
$AreaID = $d['AreaID'];
}
$dias_vacaciones_tot = 0;
$VacacionesGozadas = 0;
$datetime1 = new DateTime($FechaIngresoEmpl);
$datetime2 = new DateTime(date('Y-m-d'));
$interval = $datetime1->diff($datetime2);
$dias = $interval->format('%a');
$Antiguedad = round(($dias/365),0, PHP_ROUND_HALF_DOWN);

$nom_catintegrados = new nom_catintegrados($AgrupacionIDEmpl,"","","","","","","");
$r = $nom_catintegrados->get_dias_vac_agr();
foreach ($r as $d) {
if($d['AnioFinal'] < $Antiguedad){  
$dias_vacaciones_tot  = $dias_vacaciones_tot + $d['Vacaciones'];
} 
} 
/*busqueda de todas las vacaciones ya tenidas*/
$nom_vacaciones = new nom_vacaciones("",$Codigo,"","","","","","","",0);
$r = $nom_vacaciones->get_vac_goz();
foreach ($r as $d) {
$VacacionesGozadas = $VacacionesGozadas + $d['NumeroDias'];
}
$VacacionesPorGozar = $dias_vacaciones_tot - $VacacionesGozadas;
    
return array("Codigo"=>$Codigo,
             "Empleado"=>$Empleado,
             "Puesto"=>$Puesto,
             "AreaID"=>$AreaID,
             "Telefono"=>$Telefono,
             "FechaIngreso"=>$FechaIngreso,
             "VacacionesPorGozar"=>$VacacionesPorGozar,
             "VacacionesGozadas"=>$VacacionesGozadas);  
}

function nom_filtros($AgrupacionID,$TipoNominaID,$AreaID,$DepartamentoID){

/*Para la  busqueda avanzada*/
$nom_catagrupaciones = new nom_catagrupaciones($AgrupacionID,"","","","","","","","","","","","","","","","","");
$r_agrupacion = $nom_catagrupaciones->get_agrupacion();
$nom_catnominas= new nom_catnominas($TipoNominaID,"");
$r_nomina = $nom_catnominas->get_tiponomina();
$nom_catareas = new nom_catareas($AreaID,"","","","","");
$r_area = $nom_catareas -> get_area();
$nom_catdepartamentos= new nom_catdepartamentos($DepartamentoID,"","","","","");
$r_depto = $nom_catdepartamentos->get_departamento();

foreach ($r_agrupacion as $d) { $Agrupacion = $d['Agrupacion'];  } 
foreach ($r_nomina as $d) { $TipoNomina = $d['TipoNomina'];  } 
foreach ($r_area as $d) {  $Area = $d['Area'];  } 
foreach ($r_depto as $d) {  $Departamento = $d['Departamento'];  } 

return array("Agrupacion" =>@$Agrupacion,
             "TipoNomina" =>@$TipoNomina,
             "Area" =>@$Area,
             "Departamento" =>@$Departamento);    
}


function busquedas_select($UsuarioID,$TipoNominaID){

/*$AgrupacionID 'QWdydXBhY2lvbklE';
$TipoNominaID 'VGlwb05vbWluYUlE';
$AreaID 'QXJlYUlE';
$DepartamentoID 'RGVwYXJ0YW1lbnRvSUQ=';*/

$vistas = new vistas($UsuarioID,"","","","","","");
$r = $vistas->get_agrupaciones_user();
$r2 = $vistas->get_departamentos_user();
$r1 = $vistas->get_areas_user();

$busquedas = '
  <div class="form-group">
   <div class="col-sm-2 col-sm-offset-1">
      <label class="control-label">Agrupación</label>
        <select id="AgrupacionID" name="QWdydXBhY2lvbklE" class="form-control" >';
         foreach ($r as $d) {
          $busquedas = $busquedas.'<option  value=" '.base64_encode($d['AgrupacionID']).' ">'.$d['Agrupacion'].'</option>';  
          }        
$busquedas = $busquedas.'
        </select> 
     </div> 
     <div class="col-sm-2">
     <label class="control-label">Tipo de Nómina</label>
        <select name="VGlwb05vbWluYUlE" class="form-control">';
        for ($i=0; $i < count($TipoNominaID) ; $i++) { 
         $nom_catnominas=new nom_catnominas($TipoNominaID[$i],"");
          $r=$nom_catnominas->get_tiponomina();
          foreach ($r as $d) {
          $busquedas = $busquedas.'<option value=" '.base64_encode($d['TipoNominaID']).'">'.$d['TipoNomina'].'</option>';
          }
        }
$busquedas = $busquedas.'
        </select> 
     </div> 
    <div class="col-sm-2"> 
       <label class="control-label">Área</label>
       <div id="ver_areas">
         <select id="AreaID" name="QXJlYUlE" class="form-control" >
          <option selected value="0">--TODOS--</option>';
        foreach ($r1 as $d) {
         $busquedas = $busquedas.'<option value=" '.base64_encode($d['AreaID']).' ">'.$d['Area'].'</option>';
         }
$busquedas = $busquedas.'</select></div>
      </div> 
     <div class="col-sm-2">    
        <label class="control-label">Departamento</label>
        <div id="ver_deptos"> 
         <select name="RGVwYXJ0YW1lbnRvSUQ=" class="form-control">
         <option selected value="0" >--TODOS--</option>';
        foreach ($r2 as $d) { 
        $busquedas = $busquedas.'<option value=" '.base64_encode($d['DepartamentoID']).' ">'.$d['Departamento'].'</option> ';
           }
$busquedas = $busquedas.'</select></div>    
     </div>';

return $busquedas;
}

function get_datos_empleado($Codigo){
$datos_empl = array();
$nom_catempleados = new nom_catempleados($Codigo,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
$r = $nom_catempleados->get_empl_cod_plus();
/*$r1=$nom_catempleados->get_ult_empl();
foreach ($r1 as $c) {  $Codigo_nvo=$c['Codigo']+1; }*/
foreach ($r as $d) {
$datos_empl = array("Codigo" => $d['Codigo'],
                    "EmpresaID" => $d['EmpresaID'],
                    "Telefono" => $d['Telefono'],
                    "Empleado" => utf8_encode($d['Empleado']),
                    "Area" => utf8_encode($d['Area']),
                    "FechaNacimiento" => $d['FechaNacimiento'],
                    "Departamento" => utf8_encode($d['Departamento']),
                    "Curp" => $d['Curp'],
                    "Puesto" => utf8_encode($d['Puesto']),
                    "Imss" => $d['Imss'],
                    "MovID" => $d['MovID'],
                    "AgrupacionID" => $d['AgrupacionID'],
                    "AreaID" => $d['AreaID'],
                    "DepartamentoID" => $d['DepartamentoID'],
                    "PuestoID" => $d['PuestoID'],
                    "PeriodoID" => $d['PeriodoID'],
                    "Ejercicio" => $d['Ejercicio'],
                    "Fotografia" => $d['Fotografia'],
                    "ApellidoPaterno" => $d['ApellidoPaterno'],
                    "ApellidoMaterno" => $d['ApellidoMaterno'],
                    "Nombre" => $d['Nombre'],
                    "Domicilio" => $d['Domicilio'],
                    "Colonia" => $d['Colonia'],
                    "Telefono" => $d['Telefono'],
                    "Municipio" => $d['Municipio'],
                    "EstadoID" => $d['EstadoID'],
                    "EstadoCivil" => $d['EstadoCivil'],
                    "Sexo" => $d['Sexo'],
                    "Sueldo" => $d['Sueldo'],
                    "FechaIngreso" => $d['FechaIngreso'],
                    "Rfc" => $d['Rfc'],
                    "DatosInfonavitID" => $d['DatosInfonavitID'],
                    "EmpresaID" => $d['EmpresaID'],
                    "CodigoNominaID" => $d['CodigoNominaID'],
                    "Estatus" => $d['Estatus'],
                    "TipoNominaID" => $d['TipoNominaID'],
                    "CodigoPostal" => $d['CodigoPostal'],
                    "CentroCostos" => $d['CentroCostos'],
                    "BancoID" => $d['BancoID'],
                    "NumCuenta" => $d['NumCuenta'],
                    "NumTarjeta" => $d['NumTarjeta'],
                    "ClaveInterbancaria" => $d['ClaveInterbancaria'],
                    "TurnoID" => $d['TurnoID'],
                    "RelojID" => $d['RelojID'],
                    "CodigoRelojID" => $d['CodigoRelojID'],
                    "RegistraES" => $d['RegistraES']);  
}

return $datos_empl;

}
?>