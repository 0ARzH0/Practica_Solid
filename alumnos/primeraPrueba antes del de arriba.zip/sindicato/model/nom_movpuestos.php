<?php

include_once 'conexion.php';

class nom_movpuestos{

var $MovID;
var $AgrupacionID;
var $AreaID;
var $DepartamentoID;
var $PuestoID;
var $CantAutorizada;

function nom_movpuestos($MovID,$AgrupacionID,$AreaID,$DepartamentoID,$PuestoID,$CantAutorizada){

$this->MovID=$MovID;
$this->AgrupacionID=$AgrupacionID;
$this->AreaID=$AreaID;
$this->DepartamentoID=$DepartamentoID;
$this->PuestoID=$PuestoID;
$this->CantAutorizada=$CantAutorizada;

}
function get_puestos_empl(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT mp.*,p.Puesto FROM nom_movpuestos mp 
INNER JOIN nom_catpuestos p ON mp.PuestoID = p.PuestoID
WHERE  AgrupacionID = '$this->AgrupacionID' AND AreaID = '$this->AreaID' AND DepartamentoID='$this->DepartamentoID' ");
return $resp;	
}
function get_movid(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_movpuestos WHERE AgrupacionID = '$this->AgrupacionID' AND AreaID = '$this->AreaID' AND DepartamentoID='$this->DepartamentoID' AND PuestoID = '$this->PuestoID' ");
return $resp;	
}
function show_nom_movpuestos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_movpuestos");
return $resp;
}
function add_nom_movpuestos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_movpuestos (MovID,AgrupacionID,AreaID,DepartamentoID,PuestoID,CantAutorizada) VALUES ('$this->MovID' ,'$this->AgrupacionID' ,'$this->AreaID' ,'$this->DepartamentoID' ,'$this->PuestoID' ,'$this->CantAutorizada' ) ");
return $resp;
}
function mod_nom_movpuestos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_movpuestos SET  AgrupacionID='$this->AgrupacionID', AreaID='$this->AreaID', DepartamentoID='$this->DepartamentoID', PuestoID='$this->PuestoID', CantAutorizada='$this->CantAutorizada'   WHERE MovID = '$this->MovID'");
return $resp;
}
function del_nom_movpuestos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_movpuestos WHERE MovID = '$this->MovID' ");
return $resp;
}
}
?>
