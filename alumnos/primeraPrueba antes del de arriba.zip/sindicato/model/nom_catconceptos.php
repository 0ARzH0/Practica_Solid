<?php

include_once 'conexion.php';

class nom_catconceptos{

var $EmpresaID;
var $ConceptoID;
var $Concepto;
var $TipoConceptoID;
var $PercepcionDed;
var $Importe;
var $Unidades;
var $Saldos;
var $Incremento;
var $Decremento;
var $Especie;
var $Imprimir;
var $Automatico;
var $Parametro1;
var $Parametro2;
var $CuentaCargo;
var $ImpuestoEstatal;
var $periodoTablaIsrID;
var $Observaciones;
var $Formula;
var $ImprimeSaldos;
var $ConceptoSatID;

function nom_catconceptos($EmpresaID,$ConceptoID,$Concepto,$TipoConceptoID,$PercepcionDed,$Importe,$Unidades,$Saldos,$Incremento,$Decremento,$Especie,$Imprimir,$Automatico,$Parametro1,$Parametro2,$CuentaCargo,$ImpuestoEstatal,$periodoTablaIsrID,$Observaciones,$Formula,$ImprimeSaldos,$ConceptoSatID){

$this->EmpresaID=$EmpresaID;
$this->ConceptoID=$ConceptoID;
$this->Concepto=$Concepto;
$this->TipoConceptoID=$TipoConceptoID;
$this->PercepcionDed=$PercepcionDed;
$this->Importe=$Importe;
$this->Unidades=$Unidades;
$this->Saldos=$Saldos;
$this->Incremento=$Incremento;
$this->Decremento=$Decremento;
$this->Especie=$Especie;
$this->Imprimir=$Imprimir;
$this->Automatico=$Automatico;
$this->Parametro1=$Parametro1;
$this->Parametro2=$Parametro2;
$this->CuentaCargo=$CuentaCargo;
$this->ImpuestoEstatal=$ImpuestoEstatal;
$this->periodoTablaIsrID=$periodoTablaIsrID;
$this->Observaciones=$Observaciones;
$this->Formula=$Formula;
$this->ImprimeSaldos=$ImprimeSaldos;
$this->ConceptoSatID=$ConceptoSatID;

}
function bus_conceptos_glob(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catconceptos WHERE  Concepto LIKE '%$this->Concepto%' ORDER BY Concepto ASC LIMIT 20");
return $resp;	
}
function bus_conceptos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catconceptos WHERE EmpresaID = '$this->EmpresaID' AND Concepto LIKE '%$this->Concepto%' ORDER BY Concepto ASC LIMIT 20");
return $resp;		
}
function get_concepto(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catconceptos WHERE ConceptoID = '$this->ConceptoID' ");
return $resp;
}
function show_nom_catconceptos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catconceptos");
return $resp;
}
function add_nom_catconceptos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catconceptos (EmpresaID,ConceptoID,Concepto,TipoConceptoID,PercepcionDed,Importe,Unidades,Saldos,Incremento,Decremento,Especie,Imprimir,Automatico,Parametro1,Parametro2,CuentaCargo,ImpuestoEstatal,periodoTablaIsrID,Observaciones,Formula,ImprimeSaldos,ConceptoSatID) VALUES ('$this->EmpresaID' ,'$this->ConceptoID' ,'$this->Concepto' ,'$this->TipoConceptoID' ,'$this->PercepcionDed' ,'$this->Importe' ,'$this->Unidades' ,'$this->Saldos' ,'$this->Incremento' ,'$this->Decremento' ,'$this->Especie' ,'$this->Imprimir' ,'$this->Automatico' ,'$this->Parametro1' ,'$this->Parametro2' ,'$this->CuentaCargo' ,'$this->ImpuestoEstatal' ,'$this->periodoTablaIsrID' ,'$this->Observaciones' ,'$this->Formula' ,'$this->ImprimeSaldos' ,'$this->ConceptoSatID' ) ");
return $resp;
}
function mod_nom_catconceptos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catconceptos SET EmpresaID='$this->EmpresaID', ConceptoID='$this->ConceptoID', Concepto='$this->Concepto', TipoConceptoID='$this->TipoConceptoID', PercepcionDed='$this->PercepcionDed', Importe='$this->Importe', Unidades='$this->Unidades', Saldos='$this->Saldos', Incremento='$this->Incremento', Decremento='$this->Decremento', Especie='$this->Especie', Imprimir='$this->Imprimir', Automatico='$this->Automatico', Parametro1='$this->Parametro1', Parametro2='$this->Parametro2', CuentaCargo='$this->CuentaCargo', ImpuestoEstatal='$this->ImpuestoEstatal', periodoTablaIsrID='$this->periodoTablaIsrID', Observaciones='$this->Observaciones', Formula='$this->Formula', ImprimeSaldos='$this->ImprimeSaldos', ConceptoSatID='$this->ConceptoSatID'   WHERE EmpresaID = '$this->EmpresaID'");
return $resp;
}
function del_nom_catconceptos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catconceptos WHERE EmpresaID = '$this->EmpresaID' ");
return $resp;
}
}
?>
