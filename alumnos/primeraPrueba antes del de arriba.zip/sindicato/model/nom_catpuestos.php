<?php

include_once 'conexion.php';

class nom_catpuestos{

var $PuestoID;
var $Puesto;
var $SueldoDiario;
var $Creo;
var $FechaCreo;
var $Modifico;
var $FechaModifico;

function nom_catpuestos($PuestoID,$Puesto,$SueldoDiario,$Creo,$FechaCreo,$Modifico,$FechaModifico){

$this->PuestoID=$PuestoID;
$this->Puesto=$Puesto;
$this->SueldoDiario=$SueldoDiario;
$this->Creo=$Creo;
$this->FechaCreo=$FechaCreo;
$this->Modifico=$Modifico;
$this->FechaModifico=$FechaModifico;

}

function show_nom_catpuestos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catpuestos");
return $resp;
}
function add_nom_catpuestos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catpuestos (PuestoID,Puesto,SueldoDiario,Creo,FechaCreo,Modifico,FechaModifico) VALUES ('$this->PuestoID' ,'$this->Puesto' ,'$this->SueldoDiario' ,'$this->Creo' ,'$this->FechaCreo' ,'$this->Modifico' ,'$this->FechaModifico') ");
return $resp;
}
function mod_nom_catpuestos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catpuestos SET PuestoID='$this->PuestoID', Puesto='$this->Puesto', SueldoDiario='$this->SueldoDiario', Creo='$this->Creo', FechaCreo='$this->FechaCreo', Modifico='$this->Modifico', FechaModifico='$this->FechaModifico'  WHERE PuestoID = '$this->PuestoID'");
return $resp;
}
function del_nom_catpuestos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catpuestos WHERE PuestoID = '$this->PuestoID' ");
return $resp;
}
}
?>
