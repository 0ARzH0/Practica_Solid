<?php 
class nom_catestados{

var $EstadoID;
var $Pais;
var $NombreCorto;
var $Estado;
var $CPInf;
var $CPSup;

function nom_catestados($EstadoID,$Pais,$NombreCorto,$Estado,$CPInf,$CPSup){

$this->EstadoID=$EstadoID;
$this->Pais=$Pais;
$this->NombreCorto=$NombreCorto;
$this->Estado=$Estado;
$this->CPInf=$CPInf;
$this->CPSup=$CPSup;

}

function show_estados(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta('SELECT * FROM nom_catestados');
return $resp;
}
}
?>
