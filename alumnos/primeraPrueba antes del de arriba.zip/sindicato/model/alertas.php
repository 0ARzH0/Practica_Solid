<?php 
function alertas($msj){
        #mensajes de procesos que se hicieron correctamente
		if ($msj<20) {
			$alert = "success";
			$icon = "check";

			if ($msj==1) {
				$msj_alert = " El Concepto se ha agregado Correctamente!";
			}elseif ($msj==2) {
				$msj_alert = " El Concepto se ha eliminado Correctamente!";
			}elseif ($msj==3) {
				$msj_alert = " La Fotografia del empleado se ha Subido Correctamente!";
			}elseif ($msj==4) {
				$msj_alert = " Las Vacaciones se han agregado Correctamente!";
			}elseif ($msj==5) {
				$msj_alert = " La Incapacidad se han agregado Correctamente!";
			}elseif ($msj==6) {
				$msj_alert = " El Comprobante se ha subido Correctamente!";
			}elseif ($msj==7) {
				$msj_alert = " El Turno se ha agregado Correctamente!";
			}elseif ($msj==8) {
				$msj_alert = " El Empleado se ha agregado Correctamente!";
			}elseif ($msj==9) {
				$msj_alert = " El Empleado se ha modificado Correctamente!";
			}elseif ($msj==10) {
				$msj_alert = " Usuario agregado con éxito!";
			}elseif ($msj==11) {
				$msj_alert = " Usuario modificado exitosamente!";
			}elseif ($msj==12) {
				$msj_alert = " Permiso agregado corréctamente!";
			}else{
				$alert = "warning";
				$icon = "exclamation-triangle";
				$msj_alert = " mensaje no encontrado";
			}
		#mensajes de datos repetidos o validaciones	rebotadas
		}elseif($msj>20 && $msj<40) {
			$alert = "warning";
			$icon = "exclamation-triangle";
			if($msj == 21){
			$msj_alert = " El concepto ya existe en la Agrupacion y el Area seleccionadas!";
			}elseif ($msj == 22) {
			$msj_alert = " Usuario Incorrecto!";
			}elseif ($msj == 23) {
			$msj_alert = " Contraseña Incorrecta!";
			}elseif ($msj == 24) {
			$msj_alert = " No tiene permiso para Acceder a esta Página!"; #este no lo muevas
			}elseif ($msj == 25) {
			$msj_alert = " El usuario no se pudo agregar";
			}elseif ($msj == 26) {
			$msj_alert = " Usuario existente";
			}elseif ($msj == 27) {
			$msj_alert = " Ocurrió un problema al agregar el concepto.";
			}elseif ($msj == 28) {
			$msj_alert = " Ocurrió un problema al agregar la incapacidad al empleado.";
			}elseif ($msj == 29) {
			$msj_alert = " Ocurrió un problema al agregar las vacaciones del empleado.";
			}elseif ($msj == 30) {
			$msj_alert = " Ocurrió un problema al subir el archivo.";
			}elseif ($msj == 31) {
			$msj_alert = " Ocurrió un problema al subir la foto.";
			}elseif ($msj == 32) {
			$msj_alert = " Ya se le ha agregado permisos a este empleado.";
			}elseif ($msj == 33) {
			$msj_alert = " El RFC ya existe";
			}elseif ($msj == 34) {
			$msj_alert = " El CURP ya existe";
			}else{
				$alert = "warning";
				$icon = "exclamation-triangle";
				$msj_alert = " mensaje no encontrado";
			}
		#mensajes de procesos q no se hicieron o q salieron mal	
		}elseif ($msj>40 && $msj<60) {
            $alert  = "danger";
			$icon = "exclamation-circle";
            if ($msj==41) {
			$msj_alert = " Ocurrio un Error!";
			}elseif ($msj==42) {
			$msj_alert = " Error al conectar con la Base de Datos!";
			}elseif ($msj==43) {
			$msj_alert = " Usuario Incorrecto!";
			}elseif ($msj==44) {
			$msj_alert = " Contraseña Incorrecta!";
			}elseif ($msj==45) {
			$msj_alert = " Error de Tipo de Usuario!";
			}elseif ($msj==46) {
			$msj_alert = " Ocurrio un Error al intentar Agregar la Vacacion!";
			}elseif ($msj==47) {
			$msj_alert = " Error al agregar el empleado, verificar datos.";
			}elseif ($msj==48) {
			$msj_alert = " Error al modificar empleado, verificar datos.";
			}elseif ($msj==49) {
			$msj_alert = " EL usuario no tiene los mismos permisos.";
			}elseif ($msj==50) {
			$msj_alert = " Error, no se encontro tipo de usuario.";
			}elseif ($msj==51) {
			$msj_alert = " Error, favor de ingresar los datos correctamente.";
			}else{
				$alert = "warning";
				$icon = "exclamation-triangle";
				$msj_alert = " mensaje no encontrado";
			}
			
		}else{
			$alert = "warning";
			$icon = "exclamation-triangle";
			$msj_alert = " mensaje no encontrado";
		}
		return array('alert' => $alert, 'icon' => $icon, 'msj_alert' => $msj_alert);
	}	
?>