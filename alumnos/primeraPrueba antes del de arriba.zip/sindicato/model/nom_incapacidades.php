<?php

include_once 'conexion.php';

class nom_incapacidades{

var $IncapacidadID;
var $Codigo;
var $SerieFolio;
var $TipoIncapacidad;
var $RamoSeguro;
var $DiasAutorizados;
var $ApartirDel;
var $Comprobante;
var $UnidadAdscripcion;

function nom_incapacidades($IncapacidadID,$Codigo,$SerieFolio,$TipoIncapacidad,$RamoSeguro,$DiasAutorizados,$ApartirDel,$Comprobante,$UnidadAdscripcion){

$this->IncapacidadID=$IncapacidadID;
$this->Codigo=$Codigo;
$this->SerieFolio=$SerieFolio;
$this->TipoIncapacidad=$TipoIncapacidad;
$this->RamoSeguro=$RamoSeguro;
$this->DiasAutorizados=$DiasAutorizados;
$this->ApartirDel=$ApartirDel;
$this->Comprobante=$Comprobante;
$this->UnidadAdscripcion=$UnidadAdscripcion;

}
function get_incapacidad(){
    $conexion=new conexion();
    $resp=$conexion->ejecutarconsulta("SELECT * FROM nom_incapacidades WHERE IncapacidadID='$this->IncapacidadID'");
    return $resp;
}
function add_comprobante(){
    $conexion=new conexion();
    $resp=$conexion->ejecutarconsulta("UPDATE  nom_incapacidades SET Comprobante ='$this->Comprobante' WHERE  IncapacidadID = '$this->IncapacidadID' AND EmpleadoID='$this->EmpleadoID' AND EmpresaID='$this->EmpresaID'");
    return $resp;
}
function get_incapacidades_empl(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_incapacidades WHERE Codigo = '$this->Codigo' ");
return $resp;
}
function add_incapacidad(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_incapacidades (Codigo,SerieFolio,TipoIncapacidad,RamoSeguro,DiasAutorizados,ApartirDel,Comprobante,UnidadAdscripcion) VALUES ('$this->Codigo' ,'$this->SerieFolio' ,'$this->TipoIncapacidad' ,'$this->RamoSeguro' ,'$this->DiasAutorizados' ,'$this->ApartirDel' ,'$this->Comprobante','$this->UnidadAdscripcion') ");
return $resp;
}
/*function mod_nom_incapacidades(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_incapacidades SET Codigo='$this->Codigo', SerieFolio='$this->SerieFolio', TipoIncapacidad='$this->TipoIncapacidad', RamoSeguro='$this->RamoSeguro', DiasAutorizados='$this->DiasAutorizados', ApartirDel='$this->ApartirDel', Comprobante='$this->Comprobante',UnidadAdscripcion='$this->UnidadAdscripcion'   WHERE IncapacidadID = '$this->IncapacidadID'");
return $resp;
}
function del_nom_incapacidades(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_incapacidades WHERE IncapacidadID = '$this->IncapacidadID' ");
return $resp;
}*/
}
?>
