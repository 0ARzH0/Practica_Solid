<?php

include_once 'conexion.php';

class nom_catempleados{

var $Codigo;
var $ApellidoPaterno;
var $ApellidoMaterno;
var $Nombre;
var $MovID;
var $FechaNacimiento;
var $Domicilio;
var $Colonia;
var $Telefono;
var $Municipio;
var $EstadoID;
var $EstadoCivil;
var $Sexo;
var $Sueldo;
var $FechaIngreso;
var $Curp;
var $Rfc;
var $Imss;
var $DatosInfonavitID;
var $EmpresaID;
var $CodigoNominaID;
var $Estatus;
var $TipoNominaID;
var $CodigoPostal;
var $Fotografia;
var $CentroCostos;
var $BancoID;
var $NumCuenta;
var $NumTarjeta;
var $ClaveInterbancaria;
var $TurnoID;
var $RelojID;
var $CodigoRelojID;
var $RegistraES;

function nom_catempleados($Codigo,$ApellidoPaterno,$ApellidoMaterno,$Nombre,$MovID,$FechaNacimiento,$Domicilio,$Colonia,$Telefono,$Municipio,$EstadoID,$EstadoCivil,$Sexo,$Sueldo,$FechaIngreso,$Curp,$Rfc,$Imss,$DatosInfonavitID,$EmpresaID,$CodigoNominaID,$Estatus,$TipoNominaID,$CodigoPostal,$Fotografia,$CentroCostos,$BancoID,$NumCuenta,$NumTarjeta,$ClaveInterbancaria,$TurnoID,$RelojID,$CodigoRelojID,$RegistraES){

$this->Codigo=$Codigo;
$this->ApellidoPaterno=$ApellidoPaterno;
$this->ApellidoMaterno=$ApellidoMaterno;
$this->Nombre=$Nombre;
$this->MovID=$MovID;
$this->FechaNacimiento=$FechaNacimiento;
$this->Domicilio=$Domicilio;
$this->Colonia=$Colonia;
$this->Telefono=$Telefono;
$this->Municipio=$Municipio;
$this->EstadoID=$EstadoID;
$this->EstadoCivil=$EstadoCivil;
$this->Sexo=$Sexo;
$this->Sueldo=$Sueldo;
$this->FechaIngreso=$FechaIngreso;
$this->Curp=$Curp;
$this->Rfc=$Rfc;
$this->Imss=$Imss;
$this->DatosInfonavitID=$DatosInfonavitID;
$this->EmpresaID=$EmpresaID;
$this->CodigoNominaID=$CodigoNominaID;
$this->Estatus=$Estatus;
$this->TipoNominaID=$TipoNominaID;
$this->CodigoPostal=$CodigoPostal;
$this->Fotografia=$Fotografia;
$this->CentroCostos=$CentroCostos;
$this->BancoID=$BancoID;
$this->NumCuenta=$NumCuenta;
$this->NumTarjeta=$NumTarjeta;
$this->ClaveInterbancaria=$ClaveInterbancaria;
$this->TurnoID=$TurnoID;
$this->RelojID=$RelojID;
$this->CodigoRelojID=$CodigoRelojID;
$this->RegistraES=$RegistraES;

}
function get_empl_cod_simple(){
	$conexion=new conexion();
	$resp=$conexion->ejecutarconsulta("SELECT * FROM nom_catempleados WHERE  Codigo = '$this->Codigo' AND EmpresaID = '$this->EmpresaID' ");
    return $resp;
}
function get_empl_codnomID(){
	$conexion=new conexion();
	$resp=$conexion->ejecutarconsulta("SELECT * FROM nom_catempleados WHERE  CodigoNominaID = '$this->CodigoNominaID' AND EmpresaID = '$this->EmpresaID' ");
    return $resp;
}
function get_empl_rfc(){
	$conexion=new conexion();
	$resp=$conexion->ejecutarconsulta("SELECT * FROM nom_catempleados WHERE  Rfc = '$this->Rfc' AND EmpresaID = '$this->EmpresaID'");
    return $resp;
}
function get_empleado_cod_agr(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT e.FechaIngreso,mp.AgrupacionID FROM nom_catempleados e 
INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID AND e.Codigo = mp.Codigo
WHERE e.Codigo = '$this->Codigo' ");
return $resp;
}
function get_ult_empl(){
$conexion= new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catempleados ORDER BY Codigo DESC LIMIT 1");
return $resp;
}
function get_empleado_curp(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catempleados WHERE Curp = '$this->Curp' ");
return $resp;
}
function get_empleado_rfc(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catempleados WHERE Rfc = '$this->Rfc' ");
return $resp;
}
function get_empleado_turno(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT e.Codigo,CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado,p.Puesto,e.Telefono,mp.AgrupacionID,e.FechaIngreso FROM nom_catempleados e
INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
INNER JOIN nom_catpuestos p ON mp.PuestoID = p.PuestoID
WHERE e.Codigo = '$this->Codigo' ");
return $resp;
}
function get_empl_cod(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT e.Codigo,CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado,p.Puesto,e.Telefono,e.FechaIngreso,mp.* FROM nom_catempleados e
INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID 
INNER JOIN nom_catpuestos p ON mp.PuestoID = p.PuestoID
WHERE e.Codigo = '$this->Codigo' ");
return $resp;
}
function get_empl_cod_plus(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT e.*,CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado,p.Puesto,d.Departamento,a.Area,pe.PeriodoID,pe.Ejercicio,mp.*  FROM nom_catempleados e
INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
INNER JOIN nom_catareas a ON mp.AreaID = a.AreaID 
INNER JOIN nom_catperiodos pe ON e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1
INNER JOIN nom_catpuestos p ON mp.PuestoID = p.PuestoID
WHERE e.Codigo = '$this->Codigo' ");
return $resp;
}
function add_foto_empl(){
    $conexion=new conexion();
    $resp=$conexion->ejecutarconsulta("UPDATE nom_catempleados SET Fotografia = '$this->Fotografia' WHERE Codigo = '$this->Codigo'");
    return $resp;
}
function add_empleado(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catempleados (Codigo,ApellidoPaterno,ApellidoMaterno,Nombre,MovID,FechaNacimiento,Domicilio,Colonia,Telefono,Municipio,EstadoID,EstadoCivil,Sexo,Sueldo,FechaIngreso,Curp,Rfc,Imss,DatosInfonavitID,EmpresaID,CodigoNominaID,Estatus,TipoNominaID,CodigoPostal,Fotografia,CentroCostos,BancoID,NumCuenta,NumTarjeta,ClaveInterbancaria,TurnoID,RelojID,CodigoRelojID,RegistraES) VALUES ('$this->Codigo' ,'$this->ApellidoPaterno' ,'$this->ApellidoMaterno' ,'$this->Nombre' ,'$this->MovID' ,'$this->FechaNacimiento' ,'$this->Domicilio' ,'$this->Colonia' ,'$this->Telefono' ,'$this->Municipio' ,'$this->EstadoID' ,'$this->EstadoCivil' ,'$this->Sexo' ,'$this->Sueldo' ,'$this->FechaIngreso' ,'$this->Curp' ,'$this->Rfc' ,'$this->Imss' ,'$this->DatosInfonavitID' ,'$this->EmpresaID' ,'$this->CodigoNominaID' ,'$this->Estatus' ,'$this->TipoNominaID' ,'$this->CodigoPostal' ,'$this->Fotografia' ,'$this->CentroCostos' ,'$this->BancoID' ,'$this->NumCuenta' ,'$this->NumTarjeta' ,'$this->ClaveInterbancaria' ,'$this->TurnoID' ,'$this->RelojID' ,'$this->CodigoRelojID' ,'$this->RegistraES' ) ");
return $resp;
}
function mod_empleado(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catempleados SET  ApellidoPaterno='$this->ApellidoPaterno', ApellidoMaterno='$this->ApellidoMaterno', Nombre='$this->Nombre', MovID='$this->MovID', FechaNacimiento='$this->FechaNacimiento', Domicilio='$this->Domicilio', Colonia='$this->Colonia', Telefono='$this->Telefono', Municipio='$this->Municipio', EstadoID='$this->EstadoID', EstadoCivil='$this->EstadoCivil', Sexo='$this->Sexo', Sueldo='$this->Sueldo', FechaIngreso='$this->FechaIngreso', Curp='$this->Curp', Rfc='$this->Rfc', Imss='$this->Imss', DatosInfonavitID='$this->DatosInfonavitID', EmpresaID='$this->EmpresaID', CodigoNominaID='$this->CodigoNominaID', Estatus='$this->Estatus', TipoNominaID='$this->TipoNominaID', CodigoPostal='$this->CodigoPostal', Fotografia='$this->Fotografia', CentroCostos='$this->CentroCostos', BancoID='$this->BancoID', NumCuenta='$this->NumCuenta', NumTarjeta='$this->NumTarjeta', ClaveInterbancaria='$this->ClaveInterbancaria', TurnoID='$this->TurnoID', RelojID='$this->RelojID', CodigoRelojID='$this->CodigoRelojID', RegistraES='$this->RegistraES'  WHERE Codigo = '$this->Codigo'");
return $resp;
}
function del_nom_catempleados(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catempleados WHERE Codigo = '$this->Codigo' ");
return $resp;
}
}

class vw_empleadosporusuario{

var $Codigo;
var $ApellidoPaterno;
var $ApellidoMaterno;
var $Nombre;
var $FechaNacimiento;
var $Domicilio;
var $Colonia;
var $Telefono;
var $Municipio;
var $EstadoID;
var $Sexo;
var $Curp;
var $Estatus;
var $CodigoPostal;
var $CodigoNominaID;
var $Empleado;
var $AgrupacionID;
var $Agrupacion;
var $DepartamentoID;
var $Departamento;
var $PuestoID;
var $Puesto;
var $AreaID;
var $Area;
var $EstadoRep;
var $UsuarioID;
var $Usuario;
var $Fotografia;
var $Antig;

function vw_empleadosporusuario($Codigo,$ApellidoPaterno,$ApellidoMaterno,$Nombre,$FechaNacimiento,$Domicilio,$Colonia,$Telefono,$Municipio,$EstadoID,$Sexo,$Curp,$Estatus,$CodigoPostal,$CodigoNominaID,$Empleado,$AgrupacionID,$Agrupacion,$DepartamentoID,$Departamento,$PuestoID,$Puesto,$AreaID,$Area,$EstadoRep,$UsuarioID,$Usuario,$Fotografia,$Antig){

$this->Codigo=$Codigo;
$this->ApellidoPaterno=$ApellidoPaterno;
$this->ApellidoMaterno=$ApellidoMaterno;
$this->Nombre=$Nombre;
$this->FechaNacimiento=$FechaNacimiento;
$this->Domicilio=$Domicilio;
$this->Colonia=$Colonia;
$this->Telefono=$Telefono;
$this->Municipio=$Municipio;
$this->EstadoID=$EstadoID;
$this->Sexo=$Sexo;
$this->Curp=$Curp;
$this->Estatus=$Estatus;
$this->CodigoPostal=$CodigoPostal;
$this->CodigoNominaID=$CodigoNominaID;
$this->Empleado=$Empleado;
$this->AgrupacionID=$AgrupacionID;
$this->Agrupacion=$Agrupacion;
$this->DepartamentoID=$DepartamentoID;
$this->Departamento=$Departamento;
$this->PuestoID=$PuestoID;
$this->Puesto=$Puesto;
$this->AreaID=$AreaID;
$this->Area=$Area;
$this->EstadoRep=$EstadoRep;
$this->UsuarioID=$UsuarioID;
$this->Usuario=$Usuario;
$this->Fotografia=$Fotografia;
$this->Antig=$Antig;

}
function bus_vw_empl_nom(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM vw_empleadosporusuario WHERE UsuarioID = '$this->UsuarioID' AND Empleado LIKE '%$this->Empleado%' ORDER BY Empleado ASC LIMIT 20 ");
return $resp;	
}
function bus_vw_empl_cod(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM vw_empleadosporusuario WHERE UsuarioID = '$this->UsuarioID' AND Codigo LIKE '%$this->Codigo%' ORDER BY Codigo ASC LIMIT 20 ");
return $resp;	
}
function add_wv_empleadosporusuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO vw_empleadosporusuario (Codigo,ApellidoPaterno,ApellidoMaterno,Nombre,FechaNacimiento,Domicilio,Colonia,Telefono,Municipio,EstadoID,Sexo,Curp,Estatus,CodigoPostal,CodigoNominaID,Empleado,AgrupacionID,Agrupacion,DepartamentoID,Departamento,PuestoID,Puesto,AreaID,Area,EstadoRep,UsuarioID,Usuario,Fotografia,Antig) VALUES ('$this->Codigo' ,'$this->ApellidoPaterno' ,'$this->ApellidoMaterno' ,'$this->Nombre' ,'$this->FechaNacimiento' ,'$this->Domicilio' ,'$this->Colonia' ,'$this->Telefono' ,'$this->Municipio' ,'$this->EstadoID' ,'$this->Sexo' ,'$this->Curp' ,'$this->Estatus' ,'$this->CodigoPostal' ,'$this->CodigoNominaID' ,'$this->Empleado' ,'$this->AgrupacionID' ,'$this->Agrupacion' ,'$this->DepartamentoID' ,'$this->Departamento' ,'$this->PuestoID' ,'$this->Puesto' ,'$this->AreaID' ,'$this->Area' ,'$this->EstadoRep' ,'$this->UsuarioID' ,'$this->Usuario' ,'$this->Fotografia' ,'$this->Antig' ) ");
return $resp;
}
function mod_wv_empleadosporusuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE vw_empleadosporusuario SET Codigo='$this->Codigo', ApellidoPaterno='$this->ApellidoPaterno', ApellidoMaterno='$this->ApellidoMaterno', Nombre='$this->Nombre', FechaNacimiento='$this->FechaNacimiento', Domicilio='$this->Domicilio', Colonia='$this->Colonia', Telefono='$this->Telefono', Municipio='$this->Municipio', EstadoID='$this->EstadoID', Sexo='$this->Sexo', Curp='$this->Curp', Estatus='$this->Estatus', CodigoPostal='$this->CodigoPostal', CodigoNominaID='$this->CodigoNominaID', Empleado='$this->Empleado', AgrupacionID='$this->AgrupacionID', Agrupacion='$this->Agrupacion', DepartamentoID='$this->DepartamentoID', Departamento='$this->Departamento', PuestoID='$this->PuestoID', Puesto='$this->Puesto', AreaID='$this->AreaID', Area='$this->Area', EstadoRep='$this->EstadoRep', UsuarioID='$this->UsuarioID', Usuario='$this->Usuario', Fotografia='$this->Fotografia', Antig='$this->Antig'   WHERE Codigo = '$this->Codigo'");
return $resp;
}
function del_wv_empleadosporusuario(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM vw_empleadosporusuario WHERE Codigo = '$this->Codigo' ");
return $resp;
}
}
?>
