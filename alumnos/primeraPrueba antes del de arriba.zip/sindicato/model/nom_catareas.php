<?php

include_once 'conexion.php';

class nom_catareas{

var $AreaID;
var $Area;
var $Creo;
var $FechaCreo;
var $Modifico;
var $FechaModifico;

function nom_catareas($AreaID,$Area,$Creo,$FechaCreo,$Modifico,$FechaModifico){

$this->AreaID=$AreaID;
$this->Area=$Area;
$this->Creo=$Creo;
$this->FechaCreo=$FechaCreo;
$this->Modifico=$Modifico;
$this->FechaModifico=$FechaModifico;

}
function get_area(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catareas WHERE AreaID = '$this->AreaID' ");
return $resp;
}
function show_nom_catareas(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catareas");
return $resp;
}
function add_nom_catareas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catareas (AreaID,Area,Creo,FechaCreo,Modifico,FechaModifico) VALUES ('$this->AreaID' ,'$this->Area' ,'$this->Creo' ,'$this->FechaCreo' ,'$this->Modifico' ,'$this->FechaModifico') ");
return $resp;
}
function mod_nom_catareas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catareas SET AreaID='$this->AreaID', Area='$this->Area', Creo='$this->Creo', FechaCreo='$this->FechaCreo', Modifico='$this->Modifico', FechaModifico='$this->FechaModifico'  WHERE AreaID = '$this->AreaID'");
return $resp;
}
function del_nom_catareas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catareas WHERE AreaID = '$this->AreaID' ");
return $resp;
}
}
?>
