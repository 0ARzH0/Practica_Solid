<?php 

class plantillas{

var $Nombre_User;
var $TipoUsuario;
var $Opcion_sel;
var $Titulo;
var $Subtitulo;

function plantillas($Nombre_User,$TipoUsuario,$Opcion_sel,$Titulo,$Subtitulo){

$this->Nombre_User=$Nombre_User;
$this->TipoUsuario=$TipoUsuario;
$this->Opcion_sel=$Opcion_sel;
$this->Titulo=$Titulo;
$this->Subtitulo=$Subtitulo;

}
function cabecera(){

$cabecera_html = '
    <!DOCTYPE html>
    <html lang="en">
     
    <head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">

    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!--  <title>'.$this->Titulo.'</title> -->
    <title>Sindicato</title>

    <link href="../components/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../components/bootstrap/css/plugins/morris.css" rel="stylesheet">
    <link href="../components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="../components/jquery/jquery-ui.css">
    <link href="https://fonts.googleapis.com/css?family=Sansita" rel="stylesheet">
    <link rel="shortcut icon" href="../img/icono.ico">
    <link href="../css/estilo.css" rel="stylesheet">

    </head>';

return $cabecera_html;
}
function nav_bar(){

if($this->Opcion_sel == 1): #opcion 1 de la barra  
@$op1 = 'active';
elseif($this->Opcion_sel == 2):#opcion 2 de la barra  
@$op2 = 'active';
elseif($this->Opcion_sel == 3):  
@$op3 = 'active';
elseif($this->Opcion_sel == 4):
@$op4 = 'active'; 
elseif($this->Opcion_sel == 5):
@$op5 = 'active';
elseif($this->Opcion_sel == 6):
@$op6 = 'active';
elseif($this->Opcion_sel == 7):
@$op7 = 'active';
endif;

$nav_bar = "
 <nav class='navbar  navbar-fixed-top'>
  <div class='container-fluid'>
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class='navbar-header'>
      <button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#bs-example-navbar-collapse-1' aria-expanded='false'>
        <span class='sr-only'>Toggle navigation</span>
        <span class='icon-bar'></span>
        <span class='icon-bar'></span>
        <span class='icon-bar'></span>
      </button>";
$Reportes = "<li class='dropdown ".@$op4."'>
          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='fa fa-file-word-o'></span>&nbsp Reportes <span class='caret'></span></a>
          <ul class='dropdown-menu'>
          <li><a href='../views/verreportes.php?Tiporeporte=1' ><span class='fa fa-file-pdf-o'></span>&nbspReporte Empleados activo</a></li>
          <li><a href='../views/verreportes.php?Tiporeporte=2' ><span class='fa fa-file-pdf-o'></span>&nbspReporte Baja de empleados</a></li>
          <li><a href='../views/verreportes.php?Tiporeporte=3' ><span class='fa fa-file-pdf-o'></span>&nbspReporte Altas de empleados</a></li>
          <li><a href='../views/verreportes.php?Tiporeporte=4' ><span class='fa fa-file-pdf-o'></span>&nbspReporte concentrados</a></li>
          <li><a href='../views/verreportes.php?Tiporeporte=5' ><span class='fa fa-file-pdf-o'></span>&nbspReporte de incapacidades</a></li>
          <li><a href='../views/verreportes.php?Tiporeporte=6' ><span class='fa fa-file-pdf-o'></span>&nbspReporte de vacaciones</a></li>
          </ul>
        </li>";  
 $Perfil = "<ul class='nav navbar-nav navbar-right'>
        <li class='dropdown ".@$op5."'>
          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><i class='fa fa-user-circle'></i> &nbsp ".$this->Nombre_User."<span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='../views/perfil.php'><i class='fa fa-fw fa-user'></i> Perfil</a></li>
            <li class='divider'></li>
            <li><a href='#' id='cerrarsesion'><i class='fa fa-fw fa-power-off'></i> Salir</a></li>
          </ul>
        </li>
      </ul>";    
 $Procesos = "<li class='dropdown ".@$op3."'>
          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='fa fa-cog'></span>&nbsp Procesos <span class='caret'></span></a>
          <ul class='dropdown-menu'>
          <li><a href='../views/grid_captura.php'><span class='fa fa-table'></span>&nbsp Incidencias</a></li>
            <li><a href='../views/vervacaciones.php'><span class='fa fa-plane'></span>&nbsp Vacaciones</a></li>
            <li><a href='../views/verincapacidades.php'><span class='fa fa-medkit'></span>&nbsp Incapacidades</a></li>
          </ul>
        </li>";                    
 if($this->TipoUsuario == 4){
 $nav_bar = $nav_bar."<a class='navbar-brand' href='../views/menu.php'><img src='../img/logo.png' width='50px' height='35px'></a>
    </div>
    <div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1'>
      <ul class='nav navbar-nav'>
        <li class=' ".@$op1."'><a href='../views/menu.php'><span class='fa fa-home'></span>&nbsp Inicio</a></li>
         <li class='dropdown ".@$op2."'>
          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='fa fa-th-large'></span>&nbsp Catalogos<span class='caret'></span></a>
          <ul class='dropdown-menu'>
          <li><a href='../views/verdiasfestivos.php'><i class='fa fa-birthday-cake'></i> Dias Festivos</a></li>
            <li><a href='../views/verturnos.php'><span class='fa fa-clock-o'></span>&nbsp Turnos</a></li>
          </ul>
        </li>
        <li class=' ".@$op6."'><a href='../views/verpermisos.php'><span class='fa fa-unlock-alt'></span>&nbsp Permisos</a></li>
        <li class=' ".@$op7."'><a href='../views/ordenacionconceptos.php'><span class='fa fa-list-ol'></span>&nbsp Ordenacion Conceptos</a></li> 
        </ul>".$Perfil."
      </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
";
 }elseif($this->TipoUsuario ==3||$this->TipoUsuario==2){
    $nav_bar = $nav_bar."<a class='navbar-brand' href='../views/menu.php'><img src='../img/logo.png' width='50px' height='35px'></a>
    </div>
    <div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1'>
      <ul class='nav navbar-nav'>
        <li class='".@$op1."'><a href='../views/menu.php'><span class='fa fa-home'></span>&nbsp Inicio</a></li>
         <li class='dropdown ".@$op2."'>
          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='fa fa-th-large'></span>&nbsp Catalogos<span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='../views/verturnos.php'><span class='fa fa-clock-o'></span>&nbsp Turnos</a></li>
            <li><a href='../views/verempleados.php'><span class='fa fa-users'></span>&nbsp Empleados</a></li>
          </ul>
        </li>".$Procesos."".$Reportes."
        <li class='dropdown'>
          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='fa fa-wrench'></span>&nbsp Herramientas <span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='#' data-toggle='modal' data-target='#modal_importancion'><span class='fa fa-upload'></span>&nbsp Importación</a></li>
            <li><a href='../importaciones/formato_concepto.xlsm' ><span class='fa fa-download'></span>&nbsp Descargar Formato</a></li>
          </ul>
        </li>
      </ul>".$Perfil."
      </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class='modal fade' id='modal_importancion' tabindex='-1' role='dialog' aria-labelledby='myModalLabel'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header text-center'>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
        <h4 class='modal-title' id='myModalLabel'><span class='fa fa-upload'></span>&nbsp Importación </h4>
      </div>
      <div class='modal-body text-center'>
      <form method='POST' action='../controller/op_subeYlee.php' enctype='multipart/form-data'>
      <div class='form-group'>
        <input type='hidden' name='MAX_FILE_SIZE' value='30000' />
         <label for='' class='control-label'>Ingresa el archivo:</label>
        <input name='archivo' type='file' class='form-control' accept='.txt' />
      </div>
      <div class='form-group'>
        <button class='btn btn-success'>Enviar &nbsp<span class='fa fa-plane'></span></button>
      </div>
    </form>
      </div>
    </div>
  </div>
</div>

";
  }elseif($this->TipoUsuario==1){
 $nav_bar = $nav_bar."<a class='navbar-brand' href='../views/grid_captura_user.php'><img src='../img/logo.png' width='50px' height='35px'></a>
    </div>
    <div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1'>
      <ul class='nav navbar-nav'>
      <li class='".@$op1."'><a href='../views/grid_captura_user.php'><span class='fa fa-home'></span>&nbsp Inicio</a></li>
      <li class='dropdown ".@$op3."'>
          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'><span class='fa fa-cog'></span>&nbsp Procesos <span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='../views/vervacaciones.php'><span class='fa fa-plane'></span>&nbsp Vacaciones</a></li>
            <li><a href='../views/verincapacidades.php'><span class='fa fa-medkit'></span>&nbsp Incapacidades</a></li>
          </ul>
        </li>".$Reportes."</ul>  ".$Perfil."  
      </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
";
}
return $nav_bar;
}
}

?>