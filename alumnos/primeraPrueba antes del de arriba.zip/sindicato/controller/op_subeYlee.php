<?php 
session_start();
include_once "../model/nom_detmovnom.php";
include_once "../model/nom_catempleados.php";
include_once "../model/nom_catperiodos.php";

$nom_detmovnom = new nom_detmovnom("","","","","","","","","","","","","","","","",""); 
$r = $nom_detmovnom->ver_ultimos_10();
$UsuarioID=$_SESSION['UsuarioID'];
$cont=0;
$c = 0;

#filtro
$sql = "SELECT e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado, d.Departamento, a.Agrupacion,e.FechaIngreso,ar.Area,pu.Puesto,pe.FechaInicial,pe.FechaFinal, pe.PeriodoID AS Periodo
				    FROM nom_catempleados e 
				    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
				    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
				    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID
				    INNER JOIN nom_catperiodos pe ON e.TipoNominaID = pe.TipoNominaID AND pe.Actual = '1'
				    INNER JOIN nom_catagrupaciones a ON a.AgrupacionID = mp.AgrupacionID
				    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND p.UsuarioID = $UsuarioID
				    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
				    INNER JOIN nom_catpuestos pu ON mp.PuestoID =  pu.PuestoID";

/*Bitacora de errores*/
$errores="Sucesos inesperados o errores: ".chr(13).chr(10);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Importación</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">	
</head>
<body class="text-center">
	<?php
		$rutaEnServidor = "../archivos";
		@$rutaTemporal=$_FILES['archivo']['tmp_name'];
		@$nombreImagen=$_FILES['archivo']['name'];
		@$archivo=$rutaEnServidor.'/'.$nombreImagen;
		move_uploaded_file($rutaTemporal, $archivo);

		if (file_exists($archivo)) {
		$fp = fopen($archivo, "r");
		while(!feof($fp)) {

			$linea = fgets($fp);

			if (strlen($linea)>0) {
				@$movimiento= explode("|", $linea);
				@$tipo=intval(preg_replace('/[^0-9]+/', '', $movimiento[0]), 10);
				@$Codigo=ereg_replace("[^A-Za-z0-9]", "", $movimiento[1]);
				echo "Valor de busqueda: ".$Codigo."<br>";


				@$EmpresaID=intval(preg_replace('/[^0-9]+/', '', $movimiento[2]), 10);;
				@$ConceptoID=$movimiento[3];
				@$Unidades=$movimiento[4];
				@$Importe=$movimiento[5];
				@$Saldo=$movimiento[6];
				@$fechamov=date("Y-m-d H:i:s");
				@$anio=date("Y");
				@$TipoNominaID="";

				if ($tipo==1) {
					$conexion = new conexion();
					$sql_cod = $sql." WHERE e.Estatus = 'A' AND e.Codigo = $Codigo ORDER BY e.Codigo ASC";
				    $resp = $conexion->ejecutarconsulta($sql_cod);
				    if (mysqli_num_rows($resp)>1|mysqli_num_rows($resp)==1) {
				    	
				    	$nom_catempleados = new nom_catempleados($Codigo,"","","","","","","","","","","","","","","","","","",$EmpresaID,"","","","","","","","","","","","","","");
						$r1 = $nom_catempleados->get_empl_cod_simple();
						foreach ($r1 as $d1) { 
		                $TipoNominaID=$d1['TipoNominaID'];
		                $Empleado=$d1['Nombre']." ".$d1['ApellidoPaterno']." ".$d1['ApellidoMaterno'];
						}
						$c++;
						echo "Codigo: ".$Codigo."<br>";
						echo "Empleado: ".$Empleado."<br>";
						echo "Empresa: ".$EmpresaID."<br>";
						echo "Concepto: ".$ConceptoID."<br>";
						echo "Unidades: ".$Unidades."<br>";
						echo "Importe: ".$Importe."<br>";
						echo "Saldo: ".$Saldo."<br>";
						echo "Fecha: ".$fechamov."<br>";
						echo "Año: ".$anio."<br>";
						echo "Tipo de nomina: ".$TipoNominaID."<br>"."<br>";

						$nom_catperiodos=new nom_catperiodos($TipoNominaID,"","",'1',"","","","","","","","","","","","","","");
						$e=$nom_catperiodos->get_ejercicio();
						foreach ($e as $s) {
							$Periodo=$s['PeriodoID'];
							$Ejercicio=$s['Ejercicio'];
						}

						#Validar existencia de empresa y concepto
						$sql2="SELECT * FROM nom_catconceptos WHERE ConceptoID = $ConceptoID";
						$sql3="SELECT * FROM nom_catempresas WHERE EmpresaID = $EmpresaID";
						$resp3 = $conexion->ejecutarconsulta($sql3);
						if (mysqli_num_rows($resp3)==1) {
							$resp2 = $conexion->ejecutarconsulta($sql2);
							if (mysqli_num_rows($resp3)==1) {
								#Alta de del movimiento
								$nom_detmovnom= new nom_detmovnom("",$Codigo,$ConceptoID,$TipoNominaID,$Periodo,$Ejercicio,$Unidades,$Importe,$Saldo,"","","","","",$fechamov,"","");
								$mvtos=$nom_detmovnom->get_concepto_empl_uni();
								if (mysqli_num_rows($mvtos)==0) {
									$nom_detmovnom->add_movimiento_conc();
								}else{$errores=$errores.chr(13).chr(10)."El empleado con código (".$Codigo.") ya tiene movimientos registrados";}
							}else{$errores=$errores.chr(13).chr(10)."El concepto (".$ConceptoID.") no existe";}
						}else{
							$errores=$errores.chr(13).chr(10)."La empresa (".$EmpresaID.") no existe";
						}



				    }else{
				    	$errores=$errores.chr(13).chr(10)."El empleado con código (".$Codigo.") no te corresponde o se encontro mas de una coincidencia";
				    }
					
				}

				elseif ($tipo==2) {
					$conexion = new conexion();
					$sql_codnom = $sql." WHERE e.Estatus = 'A' AND e.CodigoNominaID = $Codigo AND e.EmpresaID=$EmpresaID";
				    $resp = $conexion->ejecutarconsulta($sql_codnom);
				    if (mysqli_num_rows($resp)>1|mysqli_num_rows($resp)==1) {
				    	
				    	$nom_catempleados = new nom_catempleados("","","","","","","","","","","","","","","","","","","",$EmpresaID,$Codigo,"","","","","","","","","","","","","");
						$r1 = $nom_catempleados->get_empl_codnomID();
						foreach ($r1 as $d1) {
						$codigoUnico=$d1['Codigo']; 
		                $TipoNominaID=$d1['TipoNominaID'];
		                $Empleado=$d1['Nombre']." ".$d1['ApellidoPaterno']." ".$d1['ApellidoMaterno'];
						}
						$c++;
						echo "Codigo: ".$codigoUnico."<br>";
						echo "Empleado: ".$Empleado."<br>";
						echo "Empresa: ".$EmpresaID."<br>";
						echo "Concepto: ".$ConceptoID."<br>";
						echo "Unidades: ".$Unidades."<br>";
						echo "Importe: ".$Importe."<br>";
						echo "Saldo: ".$Saldo."<br>";
						echo "Fecha: ".$fechamov."<br>";
						echo "Año: ".$anio."<br>";
						echo "Tipo de nomina: ".$TipoNominaID."<br>"."<br>";

						$nom_catperiodos=new nom_catperiodos($TipoNominaID,"","",'1',"","","","","","","","","","","","","","");
						$e=$nom_catperiodos->get_ejercicio();
						foreach ($e as $s) {
							$Periodo=$s['PeriodoID'];
							$Ejercicio=$s['Ejercicio'];
						}

						#Validar existencia de empresa y concepto
						$sql2="SELECT * FROM nom_catconceptos WHERE ConceptoID = $ConceptoID";
						$sql3="SELECT * FROM nom_catempresas WHERE EmpresaID = $EmpresaID";
						$resp3 = $conexion->ejecutarconsulta($sql3);
						if (mysqli_num_rows($resp3)==1) {
							$resp2 = $conexion->ejecutarconsulta($sql2);
							if (mysqli_num_rows($resp3)==1) {
								#Alta de del movimiento
								$nom_detmovnom= new nom_detmovnom("",$codigoUnico,$ConceptoID,$TipoNominaID,$Periodo,$Ejercicio,$Unidades,$Importe,$Saldo,"","","","","",$fechamov,"","");
								$mvtos=$nom_detmovnom->get_concepto_empl_uni();
								if (mysqli_num_rows($mvtos)==0) {
									$nom_detmovnom->add_movimiento_conc();
								}else{$errores=$errores.chr(13).chr(10)."El empleado con código de nomina (".$Codigo.") ya tiene movimientos registrados";}
							}else{$errores=$errores.chr(13).chr(10)."El concepto (".$ConceptoID.") no existe";}
						}else{
							$errores=$errores.chr(13).chr(10)."La empresa (".$EmpresaID.") no existe";
						}



				    }else{
				    	$errores=$errores.chr(13).chr(10)."El empleado con codigo de nomina (".$Codigo.") no te corresponde o se encontro mas de una coincidencia";
				    }
					
				}

				elseif ($tipo==3) {
					$conexion = new conexion();
					$sql_rfc = $sql." WHERE e.Estatus = 'A' AND e.Rfc = '$Codigo'";
				    $resp = $conexion->ejecutarconsulta($sql_rfc);
				    if (mysqli_num_rows($resp)>1|mysqli_num_rows($resp)==1) {
				    	
				    	$nom_catempleados = new nom_catempleados("","","","","","","","","","","","","","","","",$Codigo,"","",$EmpresaID,"","","","","","","","","","","","","","");
						$r1 = $nom_catempleados->get_empl_rfc();
						foreach ($r1 as $d1) {
						$codigoUnico=$d1['Codigo']; 
		                $TipoNominaID=$d1['TipoNominaID'];
		                $Empleado=$d1['Nombre']." ".$d1['ApellidoPaterno']." ".$d1['ApellidoMaterno'];
						}
						$c++;
						echo "Codigo: ".$codigoUnico."<br>";
						echo "Empleado: ".$Empleado."<br>";
						echo "Empresa: ".$EmpresaID."<br>";
						echo "Concepto: ".$ConceptoID."<br>";
						echo "Unidades: ".$Unidades."<br>";
						echo "Importe: ".$Importe."<br>";
						echo "Saldo: ".$Saldo."<br>";
						echo "Fecha: ".$fechamov."<br>";
						echo "Año: ".$anio."<br>";
						echo "Tipo de nomina: ".$TipoNominaID."<br>"."<br>";

						$nom_catperiodos=new nom_catperiodos($TipoNominaID,"","",'1',"","","","","","","","","","","","","","");
						$e=$nom_catperiodos->get_ejercicio();
						foreach ($e as $s) {
							$Periodo=$s['PeriodoID'];
							$Ejercicio=$s['Ejercicio'];
						}

						#Validar existencia de empresa y concepto
						$sql2="SELECT * FROM nom_catconceptos WHERE ConceptoID = $ConceptoID";
						$sql3="SELECT * FROM nom_catempresas WHERE EmpresaID = $EmpresaID";
						$resp3 = $conexion->ejecutarconsulta($sql3);
						if (mysqli_num_rows($resp3)==1) {
							$resp2 = $conexion->ejecutarconsulta($sql2);
							if (mysqli_num_rows($resp3)==1) {
								#Alta de del movimiento
								$nom_detmovnom= new nom_detmovnom("",$codigoUnico,$ConceptoID,$TipoNominaID,$Periodo,$Ejercicio,$Unidades,$Importe,$Saldo,"","","","","",$fechamov,"","");
								$mvtos=$nom_detmovnom->get_concepto_empl_uni();
								if (mysqli_num_rows($mvtos)==0) {
									$nom_detmovnom->add_movimiento_conc();
								}else{$errores=$errores.chr(13).chr(10)."El empleado con Rfc (".$Codigo.") ya tiene movimientos registrados";}
							}else{$errores=$errores.chr(13).chr(10)."El concepto (".$ConceptoID.") no existe";}
						}else{
							$errores=$errores.chr(13).chr(10)."La empresa (".$EmpresaID.") no existe";
						}



				    }else{
				    	$errores=$errores.chr(13).chr(10)."El empleado con Rfc (".$Codigo.") no te corresponde o se encontro mas de una coincidencia";
				    }
					
				}


				else{
					echo "<br> No se encontro criterio de busqueda <br>";
					$errores=$errores.chr(13).chr(10)."No se encontro criterio de busqueda para el tipo (".$tipo.")";
				}		
			}		
		}
		
		fclose($fp);
		}else{
		echo "el archivo no existe";
		}
		/*eliminar archivo txt*/
         
         /*print_r($EmpleadosDatos);*/
		if (unlink($archivo)) {
		 echo "el archivo se ha eliminado correctamente";
		 }else{
		 	echo "hubo un error al eliminar el archivo ".$archivo;
		 } 

		/*Crear reporte de errores*/
		$tiempo=date("Y-m-d_H-i-s");
		$nombre_archivo = "../archivos/Errores_".$tiempo.".txt";
		$archivo = fopen($nombre_archivo, "a");
		fwrite($archivo,$errores);
		fclose($archivo); 
	?>
<section class="container-fluid" style="margin-top: 20px;">
	<section class="col_lg-12">
		<!-- <section class="col-lg-10 col-lg-offset-1">
			<table class="table table-bordered ">
			    <thead style="background-color: #98CE0D; color: white;">
			        <tr >
			            <th style="text-align: center">EmpleadoID</th>
			            <th style="text-align: center">ConceptoID</th>
			            <th style="text-align: center">Unidades</th>
			            <th style="text-align: center">Importe</th>
			            <th style="text-align: center">Saldo</th>
			            <th style="text-align: center">Fecha</th>
			        </tr>
			    </thead>
			    <tbody>
			        <?php 
			         foreach ($r as $d) { ?>
			         <tr>
			             <td><?php echo $d['EmpleadoID']; ?></td>
			             <td><?php echo $d['ConceptoID']; ?></td>
			             <td><?php echo $d['Unidades']; ?></td>
			             <td><?php echo $d['Importe']; ?></td>
			             <td><?php echo $d['Saldo']; ?></td>
			             <td><?php echo $d['fechamov']; ?></td>
			         </tr>   
			        <?php  } ?>
			    </tbody>
			</table>
		</section> -->
		<a href="<?php echo $nombre_archivo; ?>">descargar: <?php echo $nombre_archivo; ?></a>
	</section>
</section>
	
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</html>