<?php

include_once '../model/nom_movpuestos.php';

$op=$_REQUEST['opcion'];

@$MovID = $_REQUEST['MovID'];
@$AgrupacionID = $_REQUEST['AgrupacionID'];
@$AreaID = $_REQUEST['AreaID'];
@$DepartamentoID = $_REQUEST['DepartamentoID'];
@$PuestoID = $_REQUEST['PuestoID'];
@$CantAutorizada = $_REQUEST['CantAutorizada'];

$nom_movpuestos = new nom_movpuestos($MovID,$AgrupacionID,$AreaID,$DepartamentoID,$PuestoID,$CantAutorizada);

$nom_movpuestos_gen = new nom_movpuestos('','','','','','','');

switch($op){

     case 'mostrar_puestos_empl': ?>
     <select class="form-control" name="PuestoID">
     	<?php $r = $nom_movpuestos->get_puestos_empl();
        foreach ($r as $d) { ?>
        	<option value="<?php echo $d['PuestoID']; ?>"><?php echo $d['Puesto']; ?></option>
        <?php } 	 ?>
     </select>
    <?php 
     break;

    default:
    break;
   }
?>
