<?php

include_once '../model/nom_catagrupaciones.php';

$op=$_REQUEST['opcion'];

@$AgrupacionID = $_REQUEST['AgrupacionID'];
@$Agrupacion = $_REQUEST['Agrupacion'];
@$RFC = $_REQUEST['RFC'];
@$Comision = $_REQUEST['Comision'];
@$SegmentoNegocios = $_REQUEST['SegmentoNegocios'];
@$CostoSocial = $_REQUEST['CostoSocial'];
@$Creo = $_REQUEST['Creo'];
@$FechaCreo = $_REQUEST['FechaCreo'];
@$Modifico = $_REQUEST['Modifico'];
@$FechaModifico = $_REQUEST['FechaModifico'];
@$NombreCorto = $_REQUEST['NombreCorto'];
@$EmpresaContratoID = $_REQUEST['EmpresaContratoID'];
@$SDI_Antig = $_REQUEST['SDI_Antig'];
@$SDI_Inicial = $_REQUEST['SDI_Inicial'];
@$ClienteFacID = $_REQUEST['ClienteFacID'];
@$SubsidioEmpleo = $_REQUEST['SubsidioEmpleo'];
@$FormaCobranza = $_REQUEST['FormaCobranza'];

$nom_catagrupaciones = new nom_catagrupaciones($AgrupacionID,$Agrupacion,$RFC,$Comision,$SegmentoNegocios,$CostoSocial,$Creo,$FechaCreo,$Modifico,$FechaModifico,$NombreCorto,$EmpresaContratoID,$SDI_Antig,$SDI_Inicial,$ClienteFacID,$SubsidioEmpleo,$FormaCobranza);

$nom_catagrupaciones_gen = new nom_catagrupaciones('','','','','','','','','','','','','','','','','');

switch($op){

     case 'buscar_agrupaciones':
     $r=$nom_catagrupaciones->bus_agrupaciones();
     foreach($r as $d){
     $data[] = array("label" => $d['Agrupacion'],
                    "value" => $d['AgrupacionID']);
     }
     echo json_encode($data);
     break;

    default:
     break;
     }
?>
