<?php

include_once '../model/wv_empleadosporusuario.php';

$op=$_REQUEST['opcion'];

@$Codigo = $_REQUEST['Codigo'];
@$ApellidoPaterno = $_REQUEST['ApellidoPaterno'];
@$ApellidoMaterno = $_REQUEST['ApellidoMaterno'];
@$Nombre = $_REQUEST['Nombre'];
@$FechaNacimiento = $_REQUEST['FechaNacimiento'];
@$Domicilio = $_REQUEST['Domicilio'];
@$Colonia = $_REQUEST['Colonia'];
@$Telefono = $_REQUEST['Telefono'];
@$Municipio = $_REQUEST['Municipio'];
@$EstadoID = $_REQUEST['EstadoID'];
@$Sexo = $_REQUEST['Sexo'];
@$Curp = $_REQUEST['Curp'];
@$Estatus = $_REQUEST['Estatus'];
@$CodigoPostal = $_REQUEST['CodigoPostal'];
@$CodigoNominaID = $_REQUEST['CodigoNominaID'];
@$Empleado = $_REQUEST['Empleado'];
@$AgrupacionID = $_REQUEST['AgrupacionID'];
@$Agrupacion = $_REQUEST['Agrupacion'];
@$DepartamentoID = $_REQUEST['DepartamentoID'];
@$Departamento = $_REQUEST['Departamento'];
@$PuestoID = $_REQUEST['PuestoID'];
@$Puesto = $_REQUEST['Puesto'];
@$AreaID = $_REQUEST['AreaID'];
@$Area = $_REQUEST['Area'];
@$EstadoRep = $_REQUEST['EstadoRep'];
@$UsuarioID = $_REQUEST['UsuarioID'];
@$Usuario = $_REQUEST['Usuario'];
@$Fotografia = $_REQUEST['Fotografia'];
@$Antig = $_REQUEST['Antig'];

$wv_empleadosporusuario = new wv_empleadosporusuario($Codigo,$ApellidoPaterno,$ApellidoMaterno,$Nombre,$FechaNacimiento,$Domicilio,$Colonia,$Telefono,$Municipio,$EstadoID,$Sexo,$Curp,$Estatus,$CodigoPostal,$CodigoNominaID,$Empleado,$AgrupacionID,$Agrupacion,$DepartamentoID,$Departamento,$PuestoID,$Puesto,$AreaID,$Area,$EstadoRep,$UsuarioID,$Usuario,$Fotografia,$Antig);

$wv_empleadosporusuario_gen = new wv_empleadosporusuario('','','','','','','','','','','','','','','','','','','','','','','','','','','','','');

switch($op){
    case 'agregar':

     break;
    default:

     break;
     }
?>
