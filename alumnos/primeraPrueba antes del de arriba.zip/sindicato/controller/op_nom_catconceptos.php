<?php

include_once '../model/nom_catconceptos.php';

$op=$_REQUEST['opcion'];

@$EmpresaID = $_REQUEST['EmpresaID'];
@$ConceptoID = $_REQUEST['ConceptoID'];
@$Concepto = $_REQUEST['Concepto'];
@$TipoConceptoID = $_REQUEST['TipoConceptoID'];
@$PercepcionDed = $_REQUEST['PercepcionDed'];
@$Importe = $_REQUEST['Importe'];
@$Unidades = $_REQUEST['Unidades'];
@$Saldos = $_REQUEST['Saldos'];
@$Incremento = $_REQUEST['Incremento'];
@$Decremento = $_REQUEST['Decremento'];
@$Especie = $_REQUEST['Especie'];
@$Imprimir = $_REQUEST['Imprimir'];
@$Automatico = $_REQUEST['Automatico'];
@$Parametro1 = $_REQUEST['Parametro1'];
@$Parametro2 = $_REQUEST['Parametro2'];
@$CuentaCargo = $_REQUEST['CuentaCargo'];
@$ImpuestoEstatal = $_REQUEST['ImpuestoEstatal'];
@$periodoTablaIsrID = $_REQUEST['periodoTablaIsrID'];
@$Observaciones = $_REQUEST['Observaciones'];
@$Formula = $_REQUEST['Formula'];
@$ImprimeSaldos = $_REQUEST['ImprimeSaldos'];
@$ConceptoSatID = $_REQUEST['ConceptoSatID'];

$nom_catconceptos = new nom_catconceptos($EmpresaID,$ConceptoID,$Concepto,$TipoConceptoID,$PercepcionDed,$Importe,$Unidades,$Saldos,$Incremento,$Decremento,$Especie,$Imprimir,$Automatico,$Parametro1,$Parametro2,$CuentaCargo,$ImpuestoEstatal,$periodoTablaIsrID,$Observaciones,$Formula,$ImprimeSaldos,$ConceptoSatID);

$nom_catconceptos_gen = new nom_catconceptos('','','','','','','','','','','','','','','','','','','','','','');

switch($op){

     case 'buscarconcepto_global':
     $r=$nom_catconceptos->bus_conceptos_glob();
     foreach($r as $d){
     $data[] = array("label" => utf8_encode($d['Concepto']),
                    "value" => $d['ConceptoID']);
     }
     echo json_encode($data);
     break;

     case 'buscarconceptos':
     $r=$nom_catconceptos->bus_conceptos();
     foreach($r as $d){
     $data[] = array("label" => utf8_encode($d['Concepto']),
                    "value" => $d['ConceptoID']);
     }
     echo json_encode($data);
     break;

     case 'seleccionarconcepto': 
    $campos = ""; 
     $r=$nom_catconceptos->get_concepto();
     foreach ($r as $d) {
     if($d['Importe']==1){
     $campos = $campos."
      <div class='form-group'>
	 <label class='control-label'>Importe: </label>	
	 <input type='number' class='form-control' name='Importe' placeholder='Ingrese el Importe...' required>	
	 </div>";
     }if($d['Unidades']==1){
     $campos = $campos."<div class='form-group'>
     <label class='control-label'>Unidades: </label>	
	 <input type='number' class='form-control' name='Unidades' placeholder='Ingrese las Unidades...' required>	
      </div>";
      }if($d['Saldos']==1){
	 $campos = $campos."
     <div class='form-group'>
     <label class='control-label'>Saldos: </label>	
	 <input type='number' class='form-control' name='Saldos' placeholder='Ingrese el Saldo...' required>	
     </div>";
     }
     
     echo $campos."
     <div class='form-group col-sm-12 text-center'>
     <button class='btn btn-success' name='opcion' value='agregarconceptoempl'><span class='fa fa-plus'></span>&nbsp Agregar Concepto</button>	
     </div>";
	 }
     break;

    default:
     break;
     }
?>
