<?php

include_once '../model/seg_catpermisos.php';

$op=$_REQUEST['opcion'];

@$PermisoID = $_REQUEST['PermisoID'];
@$AgrupacionID = $_REQUEST['AgrupacionID'];
@$UsuarioID = $_REQUEST['UsuarioID'];
@$AreaID = $_REQUEST['AreaID'];
@$DepartamentoID = $_REQUEST['DepartamentoID'];

$seg_catpermisos = new seg_catpermisos($PermisoID,$AgrupacionID,$UsuarioID,$AreaID,$DepartamentoID);

$seg_catpermisos_gen = new seg_catpermisos('','','','','');

switch($op){
    case 'agregarpermiso':
    $v = $seg_catpermisos->val_permisos();
    if(mysqli_num_rows($v)>0){
    header("Location:../views/verpermisos.php?msj=3");	
    }else{
    $r = $seg_catpermisos->add_permiso();
    if($r){
    header("Location:../views/verpermisos.php?msj=1"); 
    }else{
    header("Location:../views/verpermisos.php?msj=2");
    }	
    }
    break;

    default:
    break;
    }
?>
