<?php 

include_once '../model/vistas.php';

$op=$_REQUEST['opcion'];

@$UsuarioID = $_REQUEST['UsuarioID'];
if(@$_REQUEST['AgrupacionID'] > 0){
@$AgrupacionID = $_REQUEST['AgrupacionID'];
}else{
@$AgrupacionID = base64_decode($_REQUEST['AgrupacionID']);    
}
@$Agrupacion = $_REQUEST['Agrupacion'];
if(@$_REQUEST['AreaID'] > 0){
@$AreaID = $_REQUEST['AreaID'];
}else{
@$AreaID = base64_decode($_REQUEST['AreaID']);    
}
@$Area = $_REQUEST['Area'];
if(@$_REQUEST['DepartamentoID'] > 0){
@$DepartamentoID = $_REQUEST['DepartamentoID'];
}else{
@$DepartamentoID = base64_decode($_REQUEST['DepartamentoID']);    
}
@$Departamento = $_REQUEST['Departamento'];

$vistas = new vistas($UsuarioID,$AgrupacionID,$Agrupacion,$AreaID,$Area,$DepartamentoID,$Departamento);
$vistas_gen  = new vistas("","","","","","","");

switch ($op) {

     case 'areasporagrupacion':
     $r = $vistas->get_areaxagrup_user(); ?>
     <select id="AreaID" class="form-control AreaID" name="AreaID">
     <?php foreach ($r as $d) { ?>
     <option value="<?php echo $d['AreaID']; ?>"><?php echo $d['Area']; ?></option>
     <?php } ?>    
     </select>
     <script type="text/javascript">
     $("#AreaID").on("change click",function(e){
     e.preventDefault();   
     $( "#ver_deptos" ).load( "../controller/op_vistas.php",
     {AgrupacionID:$("#AgrupacionID").val(),UsuarioID:$("#UsuarioID").val(),AreaID:$("#AreaID").val(),opcion:"deptosporarea"});
     });   
     </script>
     <?php
     break;

     case 'areasporagrupacion_grid':
     $r = $vistas->get_areaxagrup_user(); ?>
     <select id="AreaID" class="form-control" name="QXJlYUlE">
     <option value="0">--TODOS--</option>
     <?php foreach ($r as $d) {
     echo "<option value='".base64_encode($d['AreaID'])."'>".$d['Area']."</option>";
     } ?>    
     </select>
     <script type="text/javascript">
     $("#AreaID").on("change click",function(e){
     e.preventDefault();   
     $( "#ver_deptos" ).load( "../controller/op_vistas.php",
     {AgrupacionID:$("#AgrupacionID").val(),UsuarioID:$("#UsuarioID").val(),AreaID:$("#AreaID").val(),opcion:"deptosporarea_grid"});
     });   
     </script>
     <?php
     break;

     case 'deptosporarea_grid':
     $r = $vistas->get_deptoxarea_user(); ?>
     <select id="DepartamentoID" class="form-control DepartamentoID" name="RGVwYXJ0YW1lbnRvSUQ=">
     <option value="0">--TODOS--</option>
     <?php foreach ($r as $d) {
     echo "<option value='".base64_encode($d['DepartamentoID'])."'>".$d['Departamento']."</option>";
     } ?>    
     </select>
     <?php
     break;

     case 'deptosporarea':
     $r = $vistas->get_deptoxarea_user(); ?>
     <select id="DepartamentoID" class="form-control DepartamentoID" name="DepartamentoID">
     <?php foreach ($r as $d) { ?>
     <option value="<?php echo $d['DepartamentoID']; ?>"><?php echo $d['Departamento']; ?></option>
     <?php } ?>    
     </select>
     <script type="text/javascript">
     $("#DepartamentoID").on("chaneg click",function(e){
     e.preventDefault();
     $( "#ver_puestos" ).load( "../controller/op_nom_movpuestos.php",
     {AgrupacionID:$("#AgrupacionID").val(),UsuarioID:$("#UsuarioID").val(),AreaID:$("#AreaID").val(),DepartamentoID:$("#DepartamentoID").val(),opcion:"mostrar_puestos_empl"});
     });     
     </script>
     <?php
     break;

	 case 'buscar_areas':
	 $r=$vistas->bus_areasporagrup(); ?>
     <select id="seleccionar_area" class="form-control" name="AreaID">
     <?php foreach ($r as $d) { ?>
     <option value="<?php echo $d['AreaID']; ?>"><?php echo $d['Area']; ?></option>
     <?php } ?>    
     </select>
     <script type="text/javascript">
       $("#seleccionar_area").on("click",function(e){
        e.preventDefault(); 
        $.ajax({
        type:'POST',
        url:'../controller/op_vistas.php',
        data:{AreaID:$(this).val(),AgrupacionID:$("#AgrupacionID").val(),opcion:"mostrar_conceptos"},
        success: function(info){
        $("#mostrar_conceptos").val('');  
        $("#mostrar_conceptos").html(info);
        }
       });
       });	
     </script>
     <?php
	 break;

	case 'buscar_deptos':
     $r=$vistas->bus_deptoporagrup(); ?>
     <select class="form-control" name="DepartamentoID">
     <?php foreach ($r as $d) { ?>
     <option value="<?php echo $d['DepartamentoID']; ?>"><?php echo $d['Departamento']; ?></option>
     <?php } ?>    
     </select> <?php
    break;

    case 'mostrar_conceptos':
     $r=$vistas->get_conceptos();
       $cont=1; foreach ($r as $d) { ?>
           <tr>
             <td><?php echo $cont; ?></td>
             <td><?php echo $d['ConceptoID']; ?></td>
             <td><?php echo $d['Concepto']; ?></td>
             <td><?php echo $d['Ordenacion']; ?></td>
             <td>
             <a href="#" data-toggle="tooltip" data-placement="bottom" title="Eliminar Concepto" ><span class="fa fa-trash"></span></a>    
             </td>
           </tr> 
    <script src="../js/general.js"></script>       
    <?php $cont++; }  
     break;
	
	default:
	break;
}
?>