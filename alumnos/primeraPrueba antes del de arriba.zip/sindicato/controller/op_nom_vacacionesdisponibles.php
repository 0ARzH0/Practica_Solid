<?php

include_once '../model/nom_vacacionesdisponibles.php';

$op=$_REQUEST['opcion'];

@$RegistroVacID = $_REQUEST['RegistroVacID'];
@$Codigo = $_REQUEST['Codigo'];
@$CantidadDisponible = $_REQUEST['CantidadDisponible'];
@$UltimoAnio = $_REQUEST['UltimoAnio'];
@$VacacionesPorGozar = $_REQUEST['VacacionesPorGozar'];
@$VacacionesGozadas = $_REQUEST['VacacionesGozadas'];
@$RegistroVacID = $_REQUEST['RegistroVacID'];
@$Codigo = $_REQUEST['Codigo'];
@$Codigo = $_REQUEST['Codigo'];

$nom_vacacionesdisponibles = new nom_vacacionesdisponibles($RegistroVacID,$Codigo,$CantidadDisponible,$UltimoAnio,$VacacionesPorGozar,$VacacionesGozadas,$RegistroVacID,$Codigo,$Codigo);

$nom_vacacionesdisponibles_gen = new nom_vacacionesdisponibles('','','','','','','','','');

switch($op){
    case 'agregar':

     break;
    default:

     break;
     }
?>
