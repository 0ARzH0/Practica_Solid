<?php

include_once '../model/nom_incapacidades.php';

$op=$_REQUEST['opcion'];

@$IncapacidadID = $_REQUEST['IncapacidadID'];
@$Codigo = $_REQUEST['Codigo'];
@$SerieFolio = $_REQUEST['SerieFolio'];
@$TipoIncapacidad = $_REQUEST['TipoIncapacidad'];
@$RamoSeguro = $_REQUEST['RamoSeguro'];
@$DiasAutorizados = $_REQUEST['DiasAutorizados'];
@$ApartirDel = $_REQUEST['ApartirDel'];
@$Comprobante = $_REQUEST['Comprobante'];
@$UnidadAdscripcion = $_REQUEST['UnidadAdscripcion'];
$msj = 0;

$rutaEnServidor='../fotos/comp_incapacidad';
@$rutaTemporal=$_FILES['archivo']['tmp_name'];
@$nombrearchivo=$_FILES['archivo']['name'];
@$nombrearchivo_nvo = "E".str_pad($EmpleadoID, 5, "0", STR_PAD_LEFT)."".strtoupper($SerieFolio).".jpg";
@$Comprobante=$rutaEnServidor.'/'.$nombrearchivo;
move_uploaded_file($rutaTemporal, $Comprobante);
@$Comprobante_nvo=$rutaEnServidor.'/'.$nombrearchivo_nvo;

$nom_incapacidades = new nom_incapacidades($IncapacidadID,$Codigo,$SerieFolio,$TipoIncapacidad,$RamoSeguro,$DiasAutorizados,$ApartirDel,$Comprobante_nvo,$UnidadAdscripcion);

$nom_incapacidades_gen = new nom_incapacidades('','','','','','','','','');

switch($op){

	case 'subirformatoinc':
    if (file_exists($Comprobante)){
	rename ("../fotos/comp_incapacidad/".$nombrearchivo, "../fotos/comp_incapacidad/".$nombrearchivo_nvo);
	}else{	
	move_uploaded_file($rutaTemporal, $Comprobante);	
	}
	if($nom_incapacidades->add_comprobante()){ $msj = 1; }else{ $msj = 41; }
	header("Location:../views/verincapacidades.php?msj=".$msj);
	break;

    case 'agregarincapacidad':
	if($nom_incapacidades->add_incapacidad()){ $msj = 1; }else{ $msj = 41; }
	header("Location:../views/verincapacidades.php?msj=".$msj);
    break;

    default:
    break;
    }
?>
