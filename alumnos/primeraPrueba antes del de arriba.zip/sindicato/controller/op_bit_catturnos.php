<?php

include_once '../model/bit_catturnos.php';
include_once '../model/bit_detturnos.php';

$op=$_REQUEST['opcion'];

@$TurnoID = $_REQUEST['TurnoID'];
@$AgrupacionID = $_REQUEST['AgrupacionID'];
@$Turno = $_REQUEST['Turno'];
@$TurnoCortado = $_REQUEST['TurnoCortado'];
@$RotaTurnoID = $_REQUEST['RotaTurnoID'];
@$TraslapaTurno = $_REQUEST['TraslapaTurno'];
@$UsuarioID = $_REQUEST['UsuarioID'];
@$FechaCreo = date("Y-m-d");
@$UsuarioModID = $_REQUEST['UsuarioModID'];
@$FechaMod = $_REQUEST['FechaMod'];
@$Tolerancia = $_REQUEST['Tolerancia'];

/*bit_detturnos*/
@$DetTurnoID = $_REQUEST['DetTurnoID'];
@$DiaID = $_REQUEST['DiaID'];
@$Entrada = $_REQUEST['Entrada'];
@$Salida = $_REQUEST['Salida'];
@$EntradaMD = $_REQUEST['EntradaMD'];
@$SalidaMD = $_REQUEST['SalidaMD'];
@$Descanso = $_REQUEST['Descanso'];

$bit_catturnos = new bit_catturnos($TurnoID,$AgrupacionID,$Turno,$TurnoCortado,$RotaTurnoID,$TraslapaTurno,$UsuarioID,$FechaCreo,$UsuarioModID,$FechaMod,$Tolerancia);

$bit_catturnos_gen = new bit_catturnos('','','','','','','','','','','');

$bit_detturnos = new bit_detturnos($DetTurnoID,$TurnoID,$DiaID,$Entrada,$Salida,$EntradaMD,$SalidaMD,$Descanso);

$bit_detturnos_gen = new bit_detturnos('','','','','','','','');

switch($op){

    case 'agregarturnos':
    $diasdescanso = json_decode($_POST['diasdescansojson'], true);
    $entradas = json_decode($_POST['entradasjson'], true);
    $salidas = json_decode($_POST['salidasjson'], true);
    $entradasMD = json_decode($_POST['entradasMDjson'], true);
    $salidasMD = json_decode($_POST['salidasMDjson'], true);
    
    $bit_catturnos->add_catturnos();

    $r = $bit_catturnos->get_ult_turnoid();
    foreach ($r as $d) { $TurnoID = $d['TurnoID']; }
    $DiaID = 1;
    for ($i=0; $i < count($diasdescanso) ; $i++) { 
    if($TurnoCortado > 0){
    $bit_detturnos = new bit_detturnos("",$TurnoID,$DiaID,$entradas[$i],$salidas[$i],$entradasMD[$i],$salidasMD[$i],$diasdescanso[$i]);
    $bit_detturnos->add_detturnos();	
    }else{	
    $bit_detturnos = new bit_detturnos("",$TurnoID,$DiaID,$entradas[$i],$salidas[$i],"","",$diasdescanso[$i]);
    $bit_detturnos->add_detturnos();
    }
    $DiaID++;   
    }
    break;

    case 'buscar_turnos_agr':
    $r = $bit_catturnos->get_turnos_agr();?>
    <select id="TurnoID" class="form-control" name="TurnoID">
     <?php foreach ($r as $d) { ?>
     <option value="<?php echo $d['TurnoID']; ?>"><?php echo $d['Turno']; ?></option>
     <?php } ?>   
    </select>
    <script type="text/javascript">
    $("#TurnoID").on("click",function(){
    $( "#ver_turnosagr" ).load( "../controller/op_bit_catturnos.php", {UsuarioID:$("#UsuarioID_Aux").val(),AgrupacionID:$("#AgrupacionID").val(),opcion:"buscar_turnos_agr"});
    });    
    </script>
     <?php
    break;

    default:
     break;
     }
?>
