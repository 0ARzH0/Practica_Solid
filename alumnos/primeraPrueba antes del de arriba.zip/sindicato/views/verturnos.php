<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once "../model/alertas.php";
include_once '../model/vistas.php';
include_once '../model/bit_catturnos.php';

/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$TipoUsuario = $_SESSION['TipoUsuario'];

$vistas =  new vistas($UsuarioID,"","","","","","");
$r = $vistas->get_agrupaciones_user();

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,2,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>

<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">

<div class="row">
<div class="col-lg-12">
<h1 class="page-header"><span class="fa fa-clock-o"></span>&nbsp Turnos</h1>
</div>
</div>

<section class="col-lg-12 ">

<?php if(@$_GET['msj']>0){ ?>
    <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
    </div>
    <?php } ?>

<div>
<ul class="nav nav-pills nav-justified" id="tabContent" >
    <li class="active"><a href="#agregar" data-toggle="tab">AGREGAR TURNO</a></li>
   <!--  <li><a href="#modificar" data-toggle="tab">MODIFICAR TURNO</a></li> -->
</ul>
<br>
<div class="tab-content" >
  <div class="tab-pane active" id="agregar">
  <div class="row">
<form id="form_add" class="form-horizontal" action="#" method="POST" >
   <input type="hidden" name="UsuarioID" value="<?php echo $UsuarioID; ?>">
   <input type="hidden" name="FechaMod" value="<?php echo date("Y-m-d"); ?>">
     <div class="form-group">
      <label class="control-label col-sm-1 col-sm-offset-1">Agrupaciones:</label> 
       <div class="col-sm-2">
        <select id="AgrupacionID_add" class="form-control" name="AgrupacionID" >
          <?php  foreach ($r as $d) {
          echo "<option value='".$d['AgrupacionID']."'>".$d['Agrupacion']."</option>";
           } ?>
        </select>
       </div>
          <label class="control-label col-sm-1">Turno:</label>
           <div class="col-sm-6">
          <input type="text" class="form-control" name="Turno" placeholder="Ingrese una descripcion del turno.." required>
          </div>
        </div> 
       <div class="form-group">
        <label class="checkbox-inline col-sm-2 col-sm-offset-2">
         <input type="checkbox" name="TraslapaTurno" value="1">Traslapa turno
       </label>
       <label class="checkbox-inline col-sm-2">
         <input id="turnocortado" type="checkbox" name="TurnoCortado" value="1">Turno cortado
       </label>
       <label class="checkbox-inline col-sm-2">
         <input id="rotaturno" type="checkbox" name="RotaTurno" value="1">Rota turno
       </label> 
        <div id="verturnos" class="col-sm-2" style="display: none;">
         <select  id="RotaTurnoID" name="RotaTurnoID" class="form-control">
            <?php  foreach ($r as $d) {
              $bit_catturnos = new bit_catturnos('',$d['AgrupacionID'],'','','','','','','','','');
              $t = $bit_catturnos->get_turnos_agr();
              foreach ($t as $dt) { ?>
              <option value="<?php echo $dt['TurnoID']; ?>"><?php echo $dt['Turno']; ?></option> 
             <?php }  } ?>
         </select>
       </div>
       </div>
<div class="col-lg-10 col-lg-offset-1">

<div class="col-sm-12 text-center">
<div class="col-sm-4 col-sm-offset-3 ">
<label class="control-label">Horario Normal</label>
</div>
<div class="col-sm-4 horarioMD" style="margin-left: 2%;">
<label class="control-label">Horario de Medio dia</label>
</div>
</div>
<div class="col-sm-12 text-center">
<div class="col-sm-2 col-sm-offset-1 text-right">
<label class="control-label" >Dias de Descanso</label>
</div>
<div class="col-sm-2">
<label class="control-label">Entrada</label>
</div>
<div class="col-sm-2">
<label class="control-label">Salida</label>
</div>
<div class="col-sm-2 horarioMD" style="margin-left: 2%;">
<label class="control-label">Entrada</label>
</div>
<div class="col-sm-2 horarioMD">
<label class="control-label">Salida</label>
</div>
</div>


<ul class="list-group col-sm-2 text-center" >
  <li class="list-group-item">Lunes</li>
  <li class="list-group-item">Martes</li>
  <li class="list-group-item">Miercoles</li>
  <li class="list-group-item">Jueves</li>
  <li class="list-group-item">Viernes</li>
  <li class="list-group-item">Sabado</li>
  <li class="list-group-item">Domingo</li>
</ul>


<ul class="list-group col-sm-1 text-center">
  <li class="list-group-item">
    <input type="checkbox" class="diasdescanso" name="Descanso" value="7">
  </li>
  <li class="list-group-item">
    <input type="checkbox" class="diasdescanso" name="Descanso" value="1">
  </li>
    <li class="list-group-item">
    <input type="checkbox" class="diasdescanso" name="Descanso" value="2">
  </li>
    <li class="list-group-item">
    <input type="checkbox" class="diasdescanso" name="Descanso" value="3">
  </li>
    <li class="list-group-item">
    <input type="checkbox" class="diasdescanso" name="Descanso" value="4">
  </li>
    <li class="list-group-item">
    <input type="checkbox" class="diasdescanso" name="Descanso" value="5">
  </li>
    <li class="list-group-item">
    <input type="checkbox" class="diasdescanso" name="Descanso" value="6">
  </li>
</ul>

<!-- Horario Normal -->
<div class="col-sm-2">
<div class="form-group">
  <input type="time" class="form-control entradas" name="Entrada" required>
</div>
<div class="form-group">
  <input type="time" class="form-control entradas" name="Entrada" required>
</div>
<div class="form-group">
  <input type="time" class="form-control entradas" name="Entrada" required>
</div>
<div class="form-group">
  <input type="time" class="form-control entradas" name="Entrada" required>
</div>
<div class="form-group">
  <input type="time" class="form-control entradas" name="Entrada" required>
</div>
<div class="form-group">
  <input type="time" class="form-control entradas" name="Entrada" required>
</div>
<div class="form-group">
  <input type="time" class="form-control entradas" name="Entrada" required>
</div>
</div>
<div class="col-sm-2" style="margin-left: 1%;">
<div class="form-group">
  <input type="time" class="form-control salidas" name="Salida" required>
</div>
<div class="form-group">
  <input type="time" class="form-control salidas" name="Salida" required>
</div>
<div class="form-group">
  <input type="time" class="form-control salidas" name="Salida" required>
</div>
<div class="form-group">
  <input type="time" class="form-control salidas" name="Salida" required>
</div>
<div class="form-group">
  <input type="time" class="form-control salidas" name="Salida" required>
</div>
<div class="form-group">
  <input type="time" class="form-control salidas" name="Salida" required>
</div>
<div class="form-group">
  <input type="time" class="form-control salidas" name="Salida" required>
</div>
</div>
<!-- Fin de Horario normal -->

<!-- Horario de medio dia -->
<div class="col-sm-2 horarioMD" style="margin-left: 2%; display: none;">
<div class="form-group">
  <input type="time" class="form-control entradasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control entradasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control entradasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control entradasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control entradasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control entradasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control entradasMD HMD" name="" >
</div>
</div>

<div class="col-sm-2 horarioMD" style="margin-left: 1%; display: none;">
<div class="form-group">
  <input type="time" class="form-control salidasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control salidasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control salidasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control salidasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control salidasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control salidasMD HMD" name="" >
</div>
<div class="form-group">
  <input type="time" class="form-control salidasMD HMD" name="" >
</div>
</div>
<!-- fin de horario de medio dia -->
<div class="col-sm-12 text-center">
 <div class="form-group">
  <button id="btn_guardar" class="btn btn-success" name="opcion" value=""><span class="fa fa-plus"></span>&nbsp Agregar Turno</button>
</div> 
</div>

</div> 
</form>
    </div>
    </div>
<!-- <div class="tab-pane" id="modificar">
<div class="row">
<form class="form-horizontal" action="#" method="POST">
    <input type="hidden" name="UsuarioModID" value="<?php echo $UsuarioID; ?>">
     <div class="form-group">
      <label class="control-label col-sm-1 col-sm-offset-1">Agrupaciones:</label> 
       <div class="col-sm-2">
        <select class="form-control" name="" >
          <?php  foreach ($r as $d) { ?>
             <option value="<?php echo $d['AgrupacionID']; ?>"><?php echo $d['Agrupacion']; ?></option>
          <?php } ?>
        </select>
       </div>
          <label class="control-label col-sm-1">Turno:</label>
           <div class="col-sm-6">
          <input type="text" class="form-control" name="Turno" placeholder="Ingrese una descripcion del turno.." required>
          </div>
        </div> 
       <div class="form-group">
        <label class="checkbox-inline col-sm-2 col-sm-offset-2">
         <input type="checkbox" name="inlineRadioOptions" value="option1">Traslapa turno
       </label>
       <label class="checkbox-inline col-sm-2">
         <input id="turnocortado" type="checkbox" name="inlineRadioOptions" value="option2">Turno contado
       </label>
       <label class="checkbox-inline col-sm-2">
         <input id="rotaturno" type="checkbox" name="inlineRadioOptions" value="option3">Rota turno
       </label> 
        <div class="col-sm-2" style="display: none;">
         <select id="verturnos" name="" class="form-control">
           
         </select>
       </div>
       </div>
    </form>   
</div>
</div> -->

</section>

</section>
</section>

</body>

<?php 
include_once "footer.php";
?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
    <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
    <script src="../js/turnos.js"></script>
</html>