<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once "../model/nom_incapacidades.php";
include_once "../model/nom_catempleados.php";
include_once "../model/grid.php";
include_once "../model/alertas.php";

/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
$TipoUsuario = $_SESSION['TipoUsuario'];
@$Codigo = $_POST['Codigo'];
$datos_empl = array();

if(!empty($Codigo)){
$datos_empl = get_datos_empleado($Codigo);
}

$nom_incapacidades = new nom_incapacidades("",$Codigo,"","","","","","","");
$r = $nom_incapacidades->get_incapacidades_empl();

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,3,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>
<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">

<div class="row">
    <div class="col-lg-12">
    <h1 class="page-header"><span class="fa fa-medkit"></span>&nbsp Incapacidades</h1>
    <?php if(@$_GET['msj']>0){ ?>
    <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
    </div>
    <?php } ?>
     </div>
</div>
<section class="col-lg-12">

<div class="col-lg-8 col-lg-offset-2">
    <form class="form-horizontal" action="verincapacidades.php" method="POST">
    <input type="hidden" id="UsuarioID" name="UsuarioID" value="<?php echo $UsuarioID;?>">
    <input type="hidden" class="Codigo" name="Codigo">
     <div class="form-group">
       <label class="control-label col-sm-2">Buscar Empleado:</label>
       <div class="col-sm-10">
        <div class="input-group">
         <input type="text" id="buscar_empl_nom" class="form-control text-uppercase" name="Empleado" placeholder="Ingrese el nombre del Empleado...">
         <span class="input-group-btn">
          <button class="btn btn-default" name="opcion" value="validarvacacionesdeempleado"><span class="fa fa-search"></span>&nbsp Buscar!</button>
         </span>
        </div>   
       </div>
   </div> 
  </form>
</div>


<form  action="../controller/op_nom_incapacidades.php" method="POST">
<input type="hidden" name="Codigo" value="<?php  echo $EmpleadoID; ?>">
      <div class="col-md-3 col-md-offset-9">       
          <div class="form-group">
            <label class="control-label">Serie Folio</label>
             <input type="text" class="form-control" maxlength="8" minlength="8" name="SerieFolio" placeholder="XXXXXXXX" required>
          </div>
        </div> 
               <div class="form-group col-md-4">
            <label class="control-label">Cedula de identificación</label>
            <input type="text" id="Codigo" name="Codigo" class="form-control" value="<?php  echo @$datos_empl['Codigo']; ?>" placeholder="Cedula de identificacion" required readonly>
          </div>
         <div class="form-group col-md-4" >
              <label class="control-label">Nombre </label>
              <input type="text" name="Nombre" class="form-control" value="<?php echo @$datos_empl['Empleado']; ?>" placeholder="Nombre del Empleado" readonly required>
          </div>      
           <div class="form-group col-md-4">
            <label class="control-label">Puesto</label>
            <input type="text" name="Puesto" class="form-control" value="<?php echo @$datos_empl['Puesto']; ?>" placeholder="Puesto del Empleado" required readonly>
          </div>
        <div class="form-group col-md-4">
          <label class="control-label">Unidad de Adscripción </label>
            <input type="text" name="UnidadAdscripcion" class="form-control" value="<?php echo @$datos_empl['AreaID']; ?>" placeholder="Unidad de Adscripción" readonly required>
        </div>
        <div class="form-group col-md-4">
          <label class="control-label" type="tel">Telefono </label>
            <input type="number" name="Telefono" class="form-control" value="<?php echo @$datos_empl['Telefono']; ?>" placeholder="Telefono del Empleado" readonly>
        </div>       
           <div class="form-group col-md-4">
            <label class="control-label">Fecha de ingreso</label>
            <input type="date" name="FechaIngreso" class="form-control" value="<?php echo @$datos_empl['FechaIngreso']; ?>" readonly>
          </div>        
        <div class="form-group col-lg-6">
           <label class="control-label">Tipo de Incapacidad:</label>    
             <select class="form-control" name="TipoIncapacidad" required>
                <option value="Inicial">Inicial</option>
                <option value="Subsecuente">Subsecuente</option>
             </select>  
         </div>
        <div class="form-group col-lg-6">
           <label class="control-label">Ramo de Seguro:</label>    
             <select class="form-control" name="RamoSeguro" required>
               <option value="Enfermedad general">Enfermedad general</option>
               <option value="Riesgo de trabajo">Riesgo de trabajo</option>
               <option value="Maternidad">Maternidad</option>
             </select>  
         </div>
         <div class="form-group col-lg-6">
             <label class="control-label">Dias Autorizados:</label>
             <input type="number" class="form-control" name="DiasAutorizados" required>  
         </div>
         <div class="form-group col-lg-6">
             <label class="control-label">Apartir del:</label>
               <input type="date" class="form-control" name="ApartirDel" required>  
         </div>
         <div class="form-group col-lg-12 text-center">
           <button class="btn btn-success" name="opcion" value="agregarincapacidad"><span class="fa fa-plus"></span>&nbsp Agregar Incapacidad</button>
         </div>
</form>

</section>

    <table class="table table-bordered ">
    <thead class="color_tabla">
        <tr>
            <th>Serie/Folio</th>
            <th>Tipo de Incapacidad</th>
            <th>Ramo del Seguro</th>
            <th>Dias autorizados</th>
            <th>A partir del</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php 
         foreach ($r as $d) { ?>
         <tr>
             <td><?php echo $d['SerieFolio']; ?></td>
             <td><?php echo $d['TipoIncapacidad']; ?></td>
             <td><?php echo $d['RamoSeguro']; ?></td>
             <td><?php echo $d['DiasAutorizados']; ?></td>
             <td><?php echo $d['ApartirDel']; ?></td>
             <td>
             <a href="#" class="descargar_formato" dir="<?php echo $d['IncapacidadID']; ?>" target="_black" data-toggle="tooltip" data-placement="bottom" title="Descargar Formato"><span class="glyphicon glyphicon-print" ></span></a>
             <a href="#" class="subir_formato" name="<?php echo $d['SerieFolio']; ?>" dir="<?php echo $d['IncapacidadID']; ?>" data-toggle="modal" data-target="#subir_formato_inc" title="Subir Formato" ><span class="glyphicon glyphicon-cloud-upload" ></span></a>    
             </td>
         </tr>   
        <?php  } ?>
    </tbody>
</table>


</section>  
</section>

<!-- Modal -->
<div class="modal fade" id="subir_formato_inc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content text-center">
      <div class="modal-header" style="background-color: #292c2f;color: #9ec502;font-size: 20px;text-align: center;">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><span class="glyphicon glyphicon-cloud-upload"></span>&nbsp Formato de Incidencia</h4>
      </div>
      <div class="modal-body">

  <form action="../controller/op_nom_incapacidades.php" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="EmpleadoID" class="form-control" value="<?php  echo $EmpleadoID ?>">
  <input type="hidden" name="EmpresaID" class="form-control" value="<?php  echo $EmpresaID ?>">
  <input type="hidden" id="IncapacidadIDSel" name="IncapacidadID" >
  <input type="hidden" id="SerieFolioSel" name="SerieFolio" >
  <div class="form-group">
        <label class="control-label">Formato</label>
        <input type="file" class="form-control" name="archivo" accept="image/jpeg" placeholder="Seleccione un archivo con extencion JPG">
      </div>
      <div class="form-group">
          <button class="btn bnt-success" name="opcion" value="subirformatoinc">Subir &nbsp <span class="glyphicon glyphicon-send"></span></button>
      </div>
  </form>
      </div>
      <div class="modal-footer" style="border-radius: 0px 0px 3px 3px;background-color: #292c2f;color: white;">
        <a class="btn btn-danger btn-md" role="button" data-dismiss="modal">
        <span class="glyphicon glyphicon-off" aria-hidden="true"></span> Cerrar </a>
      </div>
      
    </div>
  </div>
</div>
</body>

<?php 
include_once "footer.php";
?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
        <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
     <script src="../js/general.js"></script>
     <script type="text/javascript">
$(".subir_formato").on("click",function(e){
e.preventDefault();
IncapacidadID = $(this).attr("dir");
SerieFolio = $(this).attr("name");
$("#IncapacidadIDSel").val(IncapacidadID);
$("#SerieFolioSel").val(SerieFolio);
});
$(".descargar_formato").on("click",function(e){
e.preventDefault();
IncapacidadID = $(this).attr("dir");
window.open ('../reportes/formatoincapacidad.php?IncapacidadID='+IncapacidadID);
});
setTimeout(function() { $(".msj").fadeOut(500); },3000);
     </script>
    
</html>