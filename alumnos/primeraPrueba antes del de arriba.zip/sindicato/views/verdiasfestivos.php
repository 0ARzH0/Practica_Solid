<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";

$bit_catdiasfestivos = new bit_catdiasfestivos('','','');
$r = $bit_catdiasfestivos->show_diasfestivos();
/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$TipoUsuario = $_SESSION['TipoUsuario'];

$anio = date("Y");
$Fecha_ini = $anio."-01-01";
$Fecha_fin = $anio."-12-31";
?>
<!DOCTYPE html>
<html lang="es" class="no-js"> 

    <head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
        
        <title>Dias Festivos</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- CSS -->
    <link href="../components/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="../components/jquery/jquery-ui.css">
    <link href="../css/estilo.css" rel="stylesheet">
         

    </head>
 <body>
<?php 
$html_header = navegacion($Nombre,2);
echo $html_header;
?>

<section class="container-fluid">
<section class="col-lg-12">
<div class="row" style="margin-top: 2%;">
<div class="col-lg-12">
<h1 class="page-header"><span class="fa fa-birthday-cake"></span>&nbsp Dias Festivos</h1>
</div>
</div>
<!-- datos del empleado -->
<section class="col-lg-10 col-lg-offset-1 datos_user " style="margin-bottom: 2%;">
<form id="form_festivos" class="form-horizontal" action="" method="POST">
<div class="form-group">
	<label class="control-label col-sm-3">Fecha:</label>
  <div class="col-sm-8">
    <input type="date" class="form-control" name="Fecha" min="<?php echo $Fecha_ini; ?>" max="<?php echo $Fecha_fin; ?>" required>
  </div>    
</div>	
<div class="form-group">
	<label class="control-label col-sm-3">Descripcion:</label>
  <div class="col-sm-8">
  <textarea class="form-control" name="DiaFestivo" placeholder="Ingrese sus notas..." required></textarea>
  </div>
</div>	
<div class="form-group text-center">
  <button class="btn btn-success" name="option" value="agregar"><span class="fa fa-plus"></span>&nbsp Agregar</button>
</div>
<div class="col-lg-12 text-center" id="status"></div> 
</form>
</section>

<table class="table table-condensed table-hover" >
	<thead>
		<tr  bgcolor="#9FD024" style="font-size: 12px;">
			<th>No.</th>
			<th>Fecha</th>
			<th>Descripcion</th>
      <th></th>
		</tr>
	</thead>
<tbody>
<?php  
$cont = 1;
foreach ($r as $d) { ?>
  <tr class="dia_empl">
       <td><?php echo $cont; ?></td>
       <td><?php echo $d['Fecha']; ?></td>
       <td><?php echo $d['DiaFestivo']; ?></td>
       <td>
        <a href="#"><span class="fa fa-trash"></span></a>
        <a href="#"><span class="fa fa-pencil"></span></a> 
       </td>
  </tr>
<?php $cont++; } ?>
</tbody>
</table>

</section>
</section>

<?php 
include_once "footer.php";
?>

</body>
    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
    <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/scripts.js"></script>
    <script type="text/javascript">
    
    $("#form_festivos").submit(function(e){
    e.preventDefault();
    archivo_php = "../controller/op_bit_catdiasfestivos.php";
    opcion = "agregardiasfestivos";  
    var datos = $("#form_festivos").serializeArray();
    msj_success = "Se ha Agregado Correctamente!";
    ajax(archivo_php,opcion,datos,msj_success);
    
    });

  
    </script>
</html>