<?php
ob_start();
include_once "../model/seg_catusuarios.php";
include_once "../model/plantillas.php";
include_once "../model/alertas.php";

$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Cabecera*/
$plantillas = new plantillas("","","","Gestor Misuper","");
echo $plantillas->cabecera();
?>

    <header class="col-lg-12">
    <a href="http://www.factor9.com.mx/index.php" target="_blank"><img src="../img/logodos.png" ></a>
    </header>   

    <body class="body_login">

    <section class="container-fluid">
    <section class="row contenedor_login">
      <section class="col-lg-12">
        
        <article class="col-lg-8 col-lg-offset-2 margen text-center">
          <article class="col-lg-4 border_right">
            <img src="../img/profile.png"  width="187px">
          </article>
          <article class="col-lg-8 ">
          <form  action="../controller/op_seg_catusuarios.php" method="POST">
          <div class="form-group">
            <input type="text" class="form-control input_1" name="Usuario" placeholder="Ingrese su usuario.." >
          </div>
          <div class="form-group">
          <input type="password" class="form-control input_1" name="Password" placeholder="Ingrese su contraseña..">
          </div>
          <div class="form-group">
          <button class="btn btn-block btn_1" name="opcion" value="iniciar">ENTRAR</button>
          </div>             
         </form>
          </article>
        </article>
        <article class="col-lg-8 col-lg-offset-2 text-center">
           <?php if(@$_GET['msj']>0){ ?>
          <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible  fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
           <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
          </div>
          <?php } ?>
        </article>

          <div class="col-lg-4 col-lg-offset-4 col-md-12 col-xs-12  text-center">
           <a  href="http://online.fliphtml5.com/leat/fsoa/" class="manual" target="_blank"><span class="fa fa-book"></span>&nbsp MANUAL</a>
          </div>

         <div class="col-lg-6 col-lg-offset-3 col-md-12 alert alert-info text-center" role="alert" style="margin-top: 1%;""><span class="glyphicon glyphicon-info-sign" ></span>&nbsp  PARA UN MEJOR FUNCIONAMIENTO DE PREFERENCIA ENTRAR USANDO <img src="../img/chrome_logo.png" width="20px" height="20px"> GOOGLE CHROME !</div> 
           
      </section>
     </section>
   </section>

   </body>

<!-- Empieza el footer -->
<?php 
include_once "footer.php";
 ?>
<!-- Termina el footer -->

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
</html>
<?php ob_end_flush(); ?>
                
               