<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once '../model/vistas.php';
include_once "../model/nom_catnominas.php";
include_once "../model/nom_catempresas.php";
include_once "../model/nom_catestados.php";
include_once "../model/nom_catbancos.php";
include_once "../model/nom_bajas.php";
include_once "../model/grid.php";
include_once "../model/alertas.php";
include_once "../model/bit_catturnos.php";
include_once "../model/nom_catempleados.php";


/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
@$Codigo = $_POST['Codigo'];
@$bus_act = $_POST['bus_act'];
$TipoUsuario = $_SESSION['TipoUsuario'];
$datos_empl=array(); 
$Codigo_nvo = 0;
$MovID = 0;
$datos_empl = get_datos_empleado($Codigo);
$nom_bajas = new nom_bajas('',$Codigo,'','','','');
$vistas = new vistas($UsuarioID,"","","","","","");
$nom_catestados = new nom_catestados('','','','','','');
$nom_catempresas= new nom_catempresas('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
$nom_catbancos = new nom_catbancos('','','','','','','');
$nom_catnominas =  new nom_catnominas("","");
$bit_catturnos = new bit_catturnos('','','','','','','','','','','');
$nom_catempleados = new nom_catempleados($Codigo,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
$r1=$nom_catempleados->get_ult_empl();
foreach ($r1 as $c) {  $Codigo_nvo=$c['Codigo']+1; }
/*cabecera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,2,"Mi Super","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();

?>
<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">

<div class='row'>
<div class='col-lg-12'>
<h1 class='page-header'><span class='fa fa-users'></span>&nbsp Empleados</h1>
</div>
</div>

     <?php if(@$_GET['msj']>0){ ?>
    <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
    </div>
    <?php } ?>

<!-- div de empleados -->
<section>
  <!-- enncabesado de busquedas -->
  <div class="col-lg-12" >
  <div class="col-lg-1 text-center">
  <?php if(file_exists(@$datos_empl['Fotografia'])){
   echo '<img src=" '.$datos_empl['Fotografia'].' " class="img-rounded" width="100px">';
  }else{ ?>
   <img src="../img/foto_default.jpg" class="img-rounded" width="100px">
  <?php } ?>
  </div>
  <div class="col-lg-11">
  <form action="../views/verempleados.php" method="POST">
  <div class='form-group col-lg-4'>
    <label class='control-label'>Codigo:</label>
    <input type="hidden" class="Codigo" name="Codigo">
    <div class="input-group">
      <input type='number' id="buscar_empl_cod" class='form-control'   placeholder='Ingrese el Codigo' required>
      <span class="input-group-btn">
        <button class="btn btn-default" name="bus_act" value="1" type="submit">Buscar!</button>
      </span>
    </div>
  </div>
  </form>
  <form action="../views/verempleados.php" method="POST">
  <div class='form-group col-lg-8'>
  <input type="hidden" class="Codigo" name="Codigo">
    <label class='control-label'>Nombre:</label>
    <div class="input-group">
      <input type='text' id="buscar_empl_nom" class='form-control text-uppercase'  name='Nombre' placeholder='Ingrese el Nombre' required>
      <span class="input-group-btn">
        <button class="btn btn-default" name="bus_act" value="1" type="submit">Buscar!</button>
      </span>
    </div>
  </div>
  </form>
  </div>
  </div>
</section>

<!-- empiezan los tabs -->
<ul class="nav nav-tabs nav-justified" id="tabContent" >
    <li class="active"><a href="#datos" data-toggle="tab">Datos</a></li>
    <li><a href="#documentos" data-toggle="tab">Documentos</a></li>
    <li><a href="#contratacion" data-toggle="tab">Contratacion</a></li>
    <li><a href="#bajas" data-toggle="tab">Bajas</a></li>
</ul>

<!-- contenido de  cada tab -->
<form action='../controller/op_nom_catempleados.php' method='POST'>
<input type="hidden"  name="Codigo" value="<?php if(@$bus_act == 1){ echo @$datos_empl['Codigo']; }else{ echo $Codigo_nvo; } ?>">
<input type="hidden"  name="MovID" value="<?php if(@$bus_act == 1){ echo @$datos_empl['MovID']; }else{ echo $MovID; }?>">
<input type="hidden" id="UsuarioID" value="<?php echo $UsuarioID; ?>">
<div class="tab-content" >
  <div class="tab-pane active" id="datos">
  <div class="row"  style="margin-top: 1%;">

<section class="col-lg-8">

  <div class='form-group col-lg-12 text-center'>
    <label>Codigo:</label>
    <label class="label-danger" style="font-size: 20px; color: white; width: 100%; padding: 1%;"><?php echo @$datos_empl['Codigo']; ?></label>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Codigo de Nomina:</label>
    <input type='number' class='form-control text-uppercase'  name='CodigoNominaID' placeholder='Ingrese el Codigo Nomina' value="<?php echo @$datos_empl['CodigoNominaID']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Apellido Paterno:</label>
    <input type='text' class='form-control text-uppercase'  name='ApellidoPaterno' placeholder='Ingrese el Apellido Paterno' value="<?php echo @$datos_empl['ApellidoPaterno']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Apellido Materno:</label>
    <input type='text' class='form-control text-uppercase'  name='ApellidoMaterno' placeholder='Ingrese el Apellido Materno' value="<?php echo @$datos_empl['ApellidoMaterno']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Nombre(s):</label>
    <input type='text' class='form-control text-uppercase'  name='Nombre' placeholder='Ingrese el Nombre(s)' value="<?php echo @$datos_empl['Nombre']; ?>" required>
  </div> 

  <div class='form-group col-lg-4'>
    <label class='control-label'>Fecha de Nacimiento:</label>
    <input type="hidden" id="FechaActual" value="<?php echo date('Y-m-d'); ?>">
    <input type='date' id="FechaNacimiento" class='form-control'  name='FechaNacimiento' value="<?php echo $datos_empl['FechaNacimiento']; ?>" required>
  </div>

<!-- solo de vista se llene aut -->
  <div class='form-group col-lg-4'>
    <label class='control-label'>Edad:</label>
    <input id="Edad" type='number'  class='form-control'  name='Edad' placeholder='Ingrese el Edad'  required>
  </div>

   <div class='form-group col-lg-4'>
    <label class='control-label'>Domicilio:</label>
    <input type='text' class='form-control'  name='Domicilio' placeholder='Ingrese el Domicilio' value="<?php echo @$datos_empl['Domicilio']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Colonia:</label>
    <input type='text' class='form-control text-uppercase'  name='Colonia' placeholder='Ingrese el Colonia' value="<?php echo @$datos_empl['Colonia']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Estado:</label>
    <select id="EstadoEmpl" class="form-control" name="Estatus">
    <option value="A" <?php if(@$datos_empl['Estatus']=='A'){ echo "selected"; } ?> >Activo</option>
    <option value="B" <?php if(@$datos_empl['Estatus']=='B'){ echo "selected"; } ?> >Baja</option>
    <option value="E" <?php if(@$datos_empl['Estatus']=='E'){ echo "selected"; } ?> >Eventual</option>
    <option value="S" <?php if(@$datos_empl['Estatus']=='S'){ echo "selected"; } ?> >Suspendido</option>
    </select>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Codigo Postal:</label>
    <input type='number' class='form-control text-uppercase'  name='CodigoPostal' placeholder='Ingrese el Codigo Postal' value="<?php echo @$datos_empl['CodigoPostal']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Telefono:</label>
    <input type='text' class='form-control'  name='Telefono' placeholder='Ingrese el Telefono' value="<?php echo @$datos_empl['Telefono']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Municipio:</label>
    <input type='text' class='form-control text-uppercase'  name='Municipio' placeholder='Ingrese el Municipio' value="<?php echo @$datos_empl['Municipio']; ?>" required>
  </div>
 
 <!-- sacar del catalogo de estados -->
  <div class='form-group col-lg-4'>
    <label class='control-label'>Estado:</label>
   <select class="form-control" name="EstadoID">
     <?php 
      $r = $nom_catestados->show_estados();
      foreach ($r as $d) { ?>
      <option value="<?php echo $d['EstadoID']; ?>" <?php if(@$datos_empl['EstadoID']==$d['EstadoID']){ echo "selected"; } ?> ><?php echo $d['Estado']; ?></option>
      <?php  } ?>
   </select>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>EstadoCivil:</label>
    <select class="form-control" name="EstadoCivil" required>
      <option value="Casado" <?php if(@$datos_empl['EstadoCivil']=='Casado'){ echo "selected"; } ?> >Casado</option>
      <option value="Divorciado" <?php if(@$datos_empl['EstadoCivil']=='Divorciado'){ echo "selected"; } ?>>Divorciado</option>
      <option value="Union Libre" <?php if(@$datos_empl['EstadoCivil']=='Union Libre'){ echo "selected"; } ?>>Union Libre</option>
      <option value="Soltero"  <?php if(@$datos_empl['EstadoCivil']=='Soltero'){ echo "selected"; } ?> >Soltero</option>
    </select>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Sexo:</label>
    <select class="form-control" name="Sexo" required>
    <option value="Hombre" <?php if(@$datos_empl['Sexo']=='Hombre'){ echo "selected"; } ?> >HOMBRE</option>
    <option value="Mujer" <?php if(@$datos_empl['Sexo']=='Mujer'){ echo "selected"; } ?> >MUJER</option>
    </select>
  </div>

   <div class='form-group col-lg-4'>
    <label class='control-label'>Fecha de Ingreso:</label>
    <input type='date' class='form-control'  name='FechaIngreso' placeholder='Ingrese el FechaIngreso' value="<?php echo @$datos_empl['FechaIngreso']; ?>" required>
  </div> 
</section>
<section class="col-lg-4" style="border-left: 1px black solid;">
  <!-- sueldos -->

  <div class='form-group'>
    <label class='control-label'>Sueldo:</label>
    <div class="input-group">
    <span class="input-group-addon" >$</span>
     <input type='number' class='form-control'  name='Sueldo' placeholder='Ingrese el Sueldo' value="<?php echo @$datos_empl['Sueldo']; ?>" required>
   </div>
  </div>

<!--   <div class='form-group'>
    <label class='control-label'>Fotografia:</label>
     <input type='file' class='form-control'  name='imagen'>
  </div> -->

</section>

  </div>
 </div>
 <div class="tab-pane" id="documentos">
  <div class="row" style="margin-top: 1%;">

  <div class='form-group'>
    <label class='control-label'>Curp:</label>
    <input type='text' class='form-control text-uppercase' <?php if ($bus_act==1) { echo "readonly";} ?>  name='Curp' placeholder='Ingrese el Curp' maxlength="18" value="<?php echo @$datos_empl['Curp']; ?>" required>
  </div>

  <div class='form-group'>
    <label class='control-label'>RFC:</label>
    <input type='text' class='form-control text-uppercase' <?php if ($bus_act==1) { echo "readonly";} ?>  name='Rfc' placeholder='Ingrese el Rfc' maxlength="13" value="<?php echo @$datos_empl['Rfc']; ?>" required>
  </div>

  <div class='form-group'>
    <label class='control-label'>Imss:</label>
    <input type='text' class='form-control text-uppercase'  name='Imss' placeholder='Ingrese el Imss' maxlength="11" value="<?php echo @$datos_empl['Imss']; ?>" required>
  </div>

  </div>
 </div>
   <div class="tab-pane" id="contratacion">
  <div class="row" style="margin-top: 1%;">

  <div class='form-group col-lg-4'>
    <label class="control-label">Empresa:</label>
    <select name="EmpresaID" class="form-control" >
     <?php  $r=$nom_catempresas->show_empresas();
     foreach ($r as $d) {  ?>
     <option value="<?php echo $d['EmpresaID']; ?>" <?php if(@$datos_empl['EmpresaID']==$d['EmpresaID']){ echo "selected"; } ?> ><?php echo $d['Empresa']; ?></option> 
    <?php } ?>  
    </select>
  </div>

  <div class='form-group col-lg-4'>
    <label class="control-label">Agrupacion:</label>
    <select id="AgrupacionID" name="AgrupacionID" class="form-control" >
    <?php  $r=$vistas->get_agrupaciones_user();
     foreach ($r as $d) { ?>
    <option value="<?php echo $d['AgrupacionID']; ?>" <?php if(@$datos_empl['AgrupacionID']==$d['AgrupacionID']){ echo "selected"; } ?> ><?php echo $d['Agrupacion']; ?></option>  
     <?php   }  ?>
    </select>
  </div>

  <div class='form-group col-lg-4'>
    <label class="control-label">Área:</label>
    <div id="ver_areas" >
    <select class="form-control AreaID" id="AreaID" name='AreaID'>
      <option><?php echo @$datos_empl['Area']; ?></option>
    </select>
    </div>
  </div>

 <div class='form-group col-lg-4'>
  <label class="control-label">Departamento:</label> 
    <div id="ver_deptos" >
    <select class="form-control DepartamentoID" id="DepartamentoID" name='DepartamentoID'>
      <option><?php echo @$datos_empl['Departamento']; ?></option>
    </select>
    </div>  
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Puesto:</label>
    <div id="ver_puestos" >
    <select class="form-control PuestoID" id="PuestoID" name='PuestoID'>
      <option><?php echo @$datos_empl['Puesto']; ?></option>
    </select>
    </div>
  </div>

 <div class='form-group col-lg-4'>
  <label class="control-label">Tipo de Nómina</label>
  <select name="TipoNominaID" class="form-control">
    <?php $r=$nom_catnominas->show_catnominas();
      foreach ($r as $d) { ?>
    <option value="<?php echo $d['TipoNominaID']; ?>" <?php if(@$datos_empl['TipoNominaID']==$d['TipoNominaID']){ echo "selected"; } ?>><?php echo $d['TipoNomina']; ?></option>  
    <?php  } ?>
  </select> 
 </div>

   <div class='form-group col-lg-4'>
    <label class='control-label'>Turno:</label>
    <div id="ver_turnosagr">
    <select class="form-control" id="TurnoID" name='TurnoID'>
   <?php $r = $bit_catturnos->show_turnos();
     foreach ($r as $d) { ?>
      <option value="<?php echo $d['TurnoID']; ?>" <?php if(@$datos_empl['TurnoID']==$d['TurnoID']){ echo "selected"; } ?> ><?php echo $d['Turno']; ?></option>
     <?php }  ?>
    </select>
    </div>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Centro Costos:</label>
    <input type='text' class='form-control'  name='CentroCostos' placeholder='Ingrese el Centro Costos' value="<?php echo @$datos_empl['CentroCostos']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Bancos:</label>
   <select class="form-control" name="BancoID">
     <?php 
     $r = $nom_catbancos->show_bancos();
     foreach ($r as $d) { ?>
      <option value="<?php echo $d['BancoID']; ?>" <?php if(@$datos_empl['BancoID']==$d['BancoID']){ echo "selected"; } ?> ><?php echo $d['Banco']; ?></option>
     <?php }  ?>
   </select>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Numero de Cuenta:</label>
    <input type='text' class='form-control'  name='NumCuenta' placeholder='Ingrese el Numero de Cuenta' maxlength="11" value="<?php echo @$datos_empl['NumCuenta']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Numero de Tarjeta:</label>
    <input type='text' class='form-control'  name='NumTarjeta' placeholder='Ingrese el Numero de Tarjeta' maxlength="16"  value="<?php echo @$datos_empl['NumTarjeta']; ?>" required>
  </div>

  <div class='form-group col-lg-4'>
    <label class='control-label'>Clave Interbancaria:</label>
    <input type='text' class='form-control text-uppercase'  name='ClaveInterbancaria' placeholder='Ingrese la Clave Interbancaria' maxlength="18"  value="<?php echo @$datos_empl['ClaveInterbancaria']; ?>" required>
  </div>

  </div>
 </div>
  <div class="tab-pane" id="bajas">
  <div class="row" style="margin-top: 1%;">

  <div class='form-group col-lg-6'>
    <label class='control-label'>Fecha Baja:</label>
    <input type='date' class='form-control bajas'  name='FechaBaja'>
  </div>

  <div class='form-group col-lg-6'>
    <label class='control-label'>Motivo de Baja:</label>
    <select class="form-control bajas" name="MotivoBaja">
      <option value="D">D</option>
    </select>
  </div>

  <div class='form-group col-lg-12'>
    <label class='control-label'>Motivo:</label>
    <textarea class="form-control bajas" name="Motivo" placeholder="Ingrese el Motivo"></textarea>
  </div>



  <table class="table">
    <thead class="color_tabla">
      <tr>
        <th>Fecha Alta</th>
        <th>Fecha Baja</th>
        <th>Motivo</th>
        <th>Motivo Baja</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $r = $nom_bajas->get_bajas_empl();
    foreach ($r as $d) { ?>
    <tr>
      <td><?php echo $d['FechaAlta']; ?></td>
      <td><?php echo $d['FechaBaja']; ?></td>
      <td><?php echo $d['Motivo']; ?></td>
      <td><?php echo $d['MotivoBaja']; ?></td>
    </tr>
    <?php }  ?>
    </tbody>
  </table>
  </div>
 </div>
</div>  

<?php if($TipoUsuario != 2){ ?>
  <div class='form-group col-lg-12 text-center'>
  <label class='control-label'>&nbsp</label>
  <?php if ($bus_act==1) { ?>
    <button class="btn btn-warning" name="opcion" value="modificarempleado">Modificar Empleado &nbsp<span class="fa fa-pencil"></span></button>
  <?php } else {?>
  <button class="btn btn-success" name="opcion" value="agregarempleado">Agregar Empleado &nbsp<span class="fa fa-plus"></span></button>
   <?php }?>
  </div>
<?php } ?>

</form>


</section>
</section>

</body>

<?php 
include_once "footer.php";
?>

    <script src='../components/jquery/jquery.js'></script>
    <script src='../components/jquery/jquery.min.js'></script>
    <script src='../components/jquery/jquery-ui.js'></script>
    <!-- Bootstrap js -->
    <script src='../components/bootstrap/js/bootstrap.min.js'></script>
    <script src='../components/bootstrap/js/bootbox.min.js'></script>
    <script src="../js/general.js"></script>
    <script type="text/javascript">    

    $("#AgrupacionID").on("click change",function(e){
    e.preventDefault();
    $( "#ver_areas" ).load( "../controller/op_vistas.php",
    {AgrupacionID:$("#AgrupacionID").val(),UsuarioID:$("#UsuarioID").val(),opcion:"areasporagrupacion"});
    });

    $("#EstadoEmpl").click(function(){
    if($("#EstadoEmpl").val()=='B'){
    $(".bajas").attr("required","");
    }else{
    $(".bajas").removeAttr("required");
    }
    });
    
     function getNumeroDeNits(){
     var f1 = $('#FechaNacimiento').val();
     var f2 = $('#FechaActual').val();
     var aFecha1 = f1.split('-'); 
     var aFecha2 = f2.split('-'); 
     var fFecha1 = Date.UTC(aFecha1[0],aFecha1[1]-1,aFecha1[2]); 
     var fFecha2 = Date.UTC(aFecha2[0],aFecha2[1]-1,aFecha2[2]); 
     var dif = fFecha2 - fFecha1;
     var dias = Math.floor(dif / (1000 * 60 * 60 * 24)); 
     return dias;
     }
   
    $(document).on("ready",function(){
    NumDias = getNumeroDeNits();
    edad = NumDias/365;
    $("#Edad").val(parseInt(edad));  
    });

    $("#FechaNacimiento").change(function(){
    NumDias = getNumeroDeNits();
    edad = NumDias/365;
    $("#Edad").val(parseInt(edad));
    });
    
    $("#TurnoID").on("click",function(){
    $( "#ver_turnosagr" ).load( "../controller/op_bit_catturnos.php", {UsuarioID:$("#UsuarioID_Aux").val(),AgrupacionID:$("#AgrupacionID").val(),opcion:"buscar_turnos_agr"});
    });
    </script>
</html>
