<?php
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once "../model/seg_catusuarios.php";
include_once "../model/alertas.php";

/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
$TipoUsuario = $_SESSION['TipoUsuario'];

$seg_catusuarios = new seg_catusuarios($UsuarioID,$Nombre,$Usuario,$Password,$TipoUsuario);
$r = $seg_catusuarios->get_usuario();

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,5,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>
<section class="container-fluid">
 <section class="col-lg-10 col-lg-offset-1 contenedor margen_tit">
      <div class="row">
            <div class="col-lg-12">
          <h1 class="page-header">
          <span class="fa fa-user"></span>&nbsp Perfil <small>(<?php echo $Nombre ?>)</small>
          </h1>
         <?php if(@$_GET['msj']>0){ ?>
          <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
           <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
          </div>
          <?php } ?>
            </div>
        </div>

<section class="col-lg-12 datos_user">
    <article class="col-lg-8 ">
   <?php foreach ($r as $d) { ?>
     <form class="form-horizontal" action="../controller/op_seg_catusuarios.php" method="POST" >
       <input type="hidden" name="UsuarioID" value="<?php echo $d['UsuarioID']; ?>">
        <div class="form-group">
            <label class="col-sm-3 control-label">NOMBRE:</label>
            <div class="col-sm-7">
                <input type="text" class="form-control edit_datos" name="Nombre" value="<?php echo $d['Nombre']; ?>" readonly>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">USUARIO:</label>
            <div class="col-sm-7">
                <input type="text" class="form-control edit_datos" name="Usuario" value="<?php echo $d['Usuario']; ?>" readonly>
            </div>
        </div>
      <div class="form-group">
           <label  class="control-label col-sm-3" >CONTRASEÑA:</label>
            <div class="col-sm-7">
             <div class="input-group"> 
               <input id="pass1" type="password" class="form-control pass_nueva pass_ver" minlength="8" style="display: none;" > 
               <input id="pass_actual" type="password" name="Password" class="form-control" value="<?php echo $d['Password']; ?>" readonly > 
               <span class="input-group-addon">
              <input type="checkbox" id="mod_password" data-toggle="tooltip" data-placement="bottom" title="Modificar Contraseña">
              </span>
            </div>
           </div>
      </div>
      <div class="form-group pass_nueva" style="display: none;">
      <label  class="control-label col-sm-3" >CONFIRMAR CONTRASEÑA:</label>
      <div class="col-sm-7">
      <input type="password" class="form-control pass_ver"  minlength="8"  id="pass2" > 
      </div>
      </div>
      <div class="form-group">
        <div class="col-sm-4 col-sm-offset-3">
        <div class="input-group">
         <span class="input-group-addon">
          <span class="fa fa-eye"></span>
          </span>
          <input type="text" class="form-control" value="Mostrar Contraseña" readonly>
            <span class="input-group-addon">
           <input type="checkbox" id="mostrar_pass">
          </span>
         </div><!-- /input-group -->
        </div>
        <div class="col-sm-3">
        <div class="input-group">
         <span class="input-group-addon">
          <span class="fa fa-pencil"></span>
          </span>
          <input type="text" class="form-control" value="Editar datos" readonly>
            <span class="input-group-addon">
           <input type="checkbox" id="mod_datos">
          </span>
         </div><!-- /input-group -->
        </div>
      </div>
        <div class="form-group text-center">
            <div class="col-sm-12">
            <button id="btn_guardar" name ="opcion" value="modificarusuario" class="btn btn-success" style="display:none;"><span class="glyphicon glyphicon-pencil"></span>&nbsp Modificar</button>
            </div>
        </div>
    </form>
    <?php } ?>  
 </article>
 <article class="col-lg-4">
     <div class="text-center">
         <img src="../img/foto_default.jpg" class="img-circle" width="250px" height="250px">
     </div>
 </article>
</section>

    </section>   
</section>
</body>

<?php  include_once "footer.php"; ?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
        <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
</html>
<?php ob_end_flush(); ?>