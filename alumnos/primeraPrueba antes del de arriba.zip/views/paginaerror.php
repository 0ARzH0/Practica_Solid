<?php 
include_once "../model/plantillas.php";
$plantillas = new plantillas("","","","Gestor Misuper","");
echo $plantillas->cabecera();
 ?>
<body>

<section class="container">
<div class="jumbotron">
  <h1>Page Not Found Error <strong>404</strong></h1>
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
  quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
  consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
  cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
  proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
  <p class="text-center">
  <a class="btn btn-primary btn-lg" href="../views/login.php?view=login" role="button"><span class="fa fa-home"></span> Take Me Home</a>
  </p>
</div>
</section>


</body>
</html>