<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once "../model/alertas.php";

#alertas
/*@$msj = $_GET['msj']; 
@$alert = "success";
@$icon = "ok";
if ($msj == 1):
$msj_aux = "Concepto Agregado Correctamente!";
elseif ($msj == 2):
$alert = "danger";
$icon = "warning-sign";
$msj_aux = "El concepto ya existe en la Agrupacion y el Area seleccionadas!";
endif;*/

/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$TipoUsuario = $_SESSION['TipoUsuario'];

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,7,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>

<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">

<div class="row">
<div class="col-lg-12">
<h1 class="page-header"><span class="fa fa-list-ol"></span>&nbsp Ordenacion de Conceptos</h1>
</div>
</div>

     <?php if(@$_GET['msj']>0){ ?>
    <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
    </div>
    <?php } ?>

<section class="col-lg-12 datos_user " style="margin-bottom: 2%;">

<form class=" col-lg-5" action="../controller/op_nom_captura.php" method="POST">
<input type="hidden" id="UsuarioID_Aux" value="<?php echo $UsuarioID; ?>">

<div class="form-group">
<label class="control-label">Agrupacion:</label>    
<input type="hidden" id="AgrupacionID" name="AgrupacionID" >
<input type="text" id="buscar_agrupacion" class="form-control" name="Agrupacion" placeholder="Ingrese agrupacion..." required>
</div>

<div class="form-group">
<label class="control-label">Area:</label>
<div id="mostrar_areas">    
<select class="form-control" name="Area"></select>
</div>
</div>

<div class="form-group">
<label class="control-label">Buscar Concepto:</label>    
<input type="hidden"  id="ConceptoID" name="ConceptoID" >
<input type="text" id="buscar_concepto" name="Concepto" class="form-control" placeholder="Ingrese concepto..." required>
</div>

<div class="form-group">
<label class="control-label">Numero de Ordenación:</label>
<input  type="number" class="form-control" name="Ordenacion" placeholder="Ordenacion">
</div>

<div>
<button id="btn_agregar" class="btn btn-success" name="opcion" value="agregarconcepto_blobal" style="display: none;" ><span class="fa fa-plus"></span>&nbsp Agregar Concepto</button>  
</div> 

</form>

<!-- mostrar conceptos -->
<div  class="col-lg-7">
      <table class="table table-condensed table-hover">
       <thead>
         <tr class="color_tabla">
           <th>No.</th>
           <th>ConceptoID</th>
           <th>Concepto</th>
           <th>No. Ordenación</th>
           <th></th>
         </tr>
       </thead>
       <tbody id="mostrar_conceptos">
        
       </tbody>
     </table>
</div>

</section>

</section>
</section>

<?php 
include_once "footer.php";
?>

</body>
    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
    <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
    <script src="../js/permisos.js"></script>

</html>