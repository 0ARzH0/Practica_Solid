<?php 
ob_start();
@session_start();
include_once '../model/nom_detmovnom.php';
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
//include_once '../model/nom_catempleados.php';
include_once "../model/alertas.php";
include_once "../model/grid.php";
/*Alertas*/
/*@$msj = $_GET['msj'];
@$alert = "success";
@$icon = "ok";
if ($msj == 1):
$msj_aux = " El Concepto se ha Agregado Correctamente!";
elseif ($msj == 2):
$msj_aux = " El Concepto se ha Eliminado Correctamente!";
elseif ($msj == 3):
$msj_aux = " La Fotografia del Empleado se ha Subido Correctamente!";
elseif ($msj == 4):
@$alert = "danger";
@$icon = "times";
$msj_aux = " Ocurrio un Error!";
endif;*/

/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
$TipoUsuario = $_SESSION['TipoUsuario'];
@$Codigo = $_POST['Codigo'];
$datos_empl = array();

if(!empty($Codigo)){
$datos_empl = get_datos_empleado($Codigo);
}

$Nacimiento = new DateTime(@$datos_empl['FechaNacimiento']);
$Ingreso = new DateTime(@$datos_empl['FechaIngreso']); 
$FechaNacimiento = $Nacimiento->format('d/m/Y');
$FechaIngreso = $Ingreso->format('d/m/Y');

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,3,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>
<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">

<div class="row">
    <div class="col-lg-12">
    <h1 class="page-header"><span class="fa fa-user-circle"></span>&nbsp Empleado</h1>
     </div>
</div>

<section class="col-lg-12">
<div class="col-lg-8 col-lg-offset-2">
<?php if(@$_GET['msj']>0){ ?>
    <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
    </div>
    <?php } ?>
</div>
<!-- Datos del empleado -->
<article class="col-lg-10 col-lg-offset-1 datos_user">

        <div class="col-md-12 text-center">
        <?php 
        if(file_exists(@$datos_empl['Fotografia'])){ ?>
        <img src="<?php echo @$datos_empl['Fotografia']; ?>" class="img-circle" width="180px" ><br>
        <?php }else{ ?>
        <img src="../img/foto_default.jpg" class="img-circle"><br>
        <?php } ?>
        <h4>Empleado: <label class="d_empl"><?php echo @$datos_empl['Empleado']; ?></label></h4>
        </div>
        <div class="form-group col-md-4">
        <h4>Area: <label class="d_empl"><?php echo @$datos_empl['Area']; ?></label></h4>
        <h4>Fecha de Ingreso: <label class="d_empl"><?php echo @$FechaIngreso; ?></label></h4>
         <h4>Puesto: <label class="d_empl"><?php echo @$datos_empl['Puesto']; ?></label></h4>
        </div>
        <div class="form-group col-md-4">
        <h4>Departamento: <label class="d_empl"><?php echo @$datos_empl['Departamento']; ?></label></h4>
        <h4>Curp: <label class="d_empl"><?php echo @$datos_empl['Curp']; ?></label></h4>
        </div>
        <div class="form-group col-md-4">
        <h4>Fecha de Nacimiento: <label class="d_empl"><?php echo  $FechaNacimiento; ?></label></h4>
        <h4>Afiliación IMSS: <label class="d_empl"><?php echo @$datos_empl['Imss']; ?></label></h4>
        </div>

</article>
        
<!-- buttons groups -->
<article class="col-lg-8 col-lg-offset-2 text-center" style="margin-top: 2%; margin-bottom: 2%;">

<!-- formulario de busqueda de empleado -->
 <form class="form-horizontal" action="editarempleado.php" method="POST">
     <input type="hidden" id="UsuarioID" name="UsuarioID" value="<?php echo $UsuarioID;?>">
     <input type="hidden" class="Codigo" name="Codigo">
      <div class="form-group">
       <label class="control-label col-sm-2">Buscar Empleado:</label>
       <div class="col-sm-10">
        <div class="input-group">
          <input type="text" id="buscar_empl_nom" class="form-control text-uppercase" name="Empleado" placeholder="Ingrese el nombre de Empleado...">
         <span class="input-group-btn">
          <button class="btn btn-default" name="opcion" value="seleccionarempleado"><span class="fa fa-search"></span>&nbsp Buscar!</button>
         </span>
        </div>   
       </div>
   </div> 
</form>

<form action="../reportes/formatoconceptoempleado.php" target="_blank" method="POST">
<input type="hidden" name="Codigo" value="<?php  echo @$datos_empl['Codigo']; ?>">
<div class="btn-group btn-group-lg" role="group" aria-label="...">

  <button type="submit" class="btn btn-info"><span class="fa fa-print"></span>&nbsp Imprimir</button>
  <button type="button" id="btn_subir_foto" class="btn btn-primary" data-toggle="modal" data-target="#subir_foto_empl" ><span class="fa fa-camera"></span>&nbsp Subir Foto</button>

</div>
</form>
</article>        

<!-- Formulario de agregar conceptos -->
<article class="col-lg-8 col-lg-offset-2 text-center" style="margin-bottom: 2%;">
<form  class="form-horizontal" action="../controller/op_nom_detmovnom.php" method="POST">
<!-- parametros para agregar el concepto -->
<input type="hidden" id="EmpresaID" name="EmpresaID" value="<?php  echo @$datos_empl['EmpresaID']; ?>">
<input type="hidden" id="TipoNominaID" name="TipoNominaID" value="<?php  echo @$datos_empl['TipoNominaID']; ?>">
<input type="hidden" id="PeriodoID" name="PeriodoID" value="<?php  echo @$datos_empl['PeriodoID']; ?>">
<input type="hidden" name="Codigo" value="<?php  echo @$datos_empl['Codigo']; ?>">

 <div class="form-group">
   <label class="control-label col-sm-3">Buscar Concepto:</label>
    <input type="hidden" id="ConceptoID" name="ConceptoID">
   <div class="col-sm-9">
     <input id="buscar_concepto" type="text" class="form-control" name="Concepto" placeholder="Ingrese el Concepto.." required>
   </div>
 </div>
 <!-- muestra el resultado de la busqueda del concepto -->
 <div class="text-center" id="datos_concepto">
      <div class="form-group col-sm-12 text-center">
     <button class="btn btn-success" name="opcion" value="agregarconceptoempl"><span class="fa fa-plus"></span>&nbsp Agregar Concepto</button>  
     </div>
 </div> 
 </form>
</article>

<?php 
$nom_detmovnom = new nom_detmovnom("",@$datos_empl['Codigo'],"",@$datos_empl['TipoNominaID'],@$datos_empl['PeriodoID'],"","","","","","","","","","","","");
$r = $nom_detmovnom->get_concepto_empl(); 
?>

<!-- grid de conceptos del empleado  -->
<article class="col-lg-10 col-lg-offset-1">
   <table class="table table-condensed">
    <thead class="color_tabla">
        <tr>
            <th>No.</th>
            <th>ID</th>
            <th>Concepto</th>
            <th>Unidades</th>
            <th>Importe</th>
            <th>Saldo</th>
            <th>Aprobado</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
          <?php 
          $cont = 1;
          foreach ($r as $d) { ?>
          <tr>
          <td><?php echo $cont; ?></td>
          <td><?php echo $d['ConceptoID']; ?></td>
          <td><?php echo $d['Concepto']; ?></td>
          <td><?php echo $d['Unidades']; ?></td>
          <td><?php echo $d['Importe']; ?></td>
          <td><?php echo $d['Saldo']; ?></td>
          <td><?php 
          if($d['Aprobado']>0){
          echo "Si"; 
          }else{
          echo "No"; 
          }?></td>
          <td>
          <?php if($TipoUsuario >= $d['Aprobado']){ ?>
          <a  href="#" class="eliminar" dir="<?php echo $d['detmov_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Eliminar Concepto"><span class="fa fa-trash fa-2x"></span></a>
          <?php } ?>
          </td>
          </tr>
          <?php $cont++; } ?>
    </tbody>
   </table>
</article>

<!-- Modal -->
<div class="modal fade" id="subir_foto_empl" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content text-center">
      <div class="modal-header" style="background-color: #292c2f;color: #9ec502;font-size: 20px;text-align: center;">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><span class="fa fa-camera"></span>&nbsp Foto Empleado</h4>
      </div>
      <div class="modal-body">

  <form action="../controller/op_nom_catempleados.php" method="POST" enctype="multipart/form-data">
   <input type="hidden" id="Codigo" name="Codigo" value="<?php  echo $Codigo; ?>">
   <input type="hidden" name="Subir_foto" value="1">
      <div class="form-group">
        <label class="control-label">Fotografia</label>
        <input type="file" class="form-control" name="imagen" accept="image/jpeg" placeholder="Seleccione un archivo con extencion JPG" required>
      </div>
      <div class="form-group" id="msj_empl_cod"> </div>
      <div class="form-group">
          <button class="btn bnt-success" id="btn_sub" name="opcion" value="subir_foto_empl">Subir &nbsp <span class="glyphicon glyphicon-send"></span></button>
      </div>
  </form>
      </div>
      <div class="modal-footer" style="border-radius: 0px 0px 3px 3px;background-color: #292c2f;color: white;">
        <a class="btn btn-danger btn-md" role="button" data-dismiss="modal">
        <span class="glyphicon glyphicon-off" aria-hidden="true"></span> Cerrar </a>
      </div>
      
    </div>
  </div>
</div>


</section>
</section>  
</section>

</body>

<?php 
include_once "footer.php";
?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
        <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
    <script type="text/javascript">
    /*Buscar Cocneptos*/
    $(function(){
    $("#buscar_concepto").autocomplete({
    source:function(req,res){
    $.ajax({
    type:'POST',
    url:'../controller/op_nom_catconceptos.php',
    dataType:"json",
    data:{Concepto:req.term,EmpresaID:$("#EmpresaID").val(),opcion:"buscarconceptos"},
    success: function(info){
    res(info);
    }
    });
    },
    focus: function(e,ui){
    e.preventDefault();
    $(this).val(ui.item.label);
    },
    select: function(e,ui){ 
    e.preventDefault();
    $("#ConceptoID").val(ui.item.value);
    $( "#datos_concepto" ).load( "../controller/op_nom_catconceptos.php", {ConceptoID:$("#ConceptoID").val(),EmpresaID:$("#EmpresaID").val(),opcion:"seleccionarconcepto"});
    }
    });
    });

    $(".eliminar").on("click",function(e){
    e.preventDefault();  
    if(confirm("¿Realmente Desea eliminar este Concepto?")){
    detmov_id = $(this).attr("dir");
        $.ajax({
        type:'POST',
        url:'../controller/op_nom_detmovnom.php',
        data:{detmov_id:detmov_id,opcion:"eliminarconceptoempl"},
       success: function(info){
       window.location.href = "../views/editarempleado.php?msj=2";
       },
       error: function(error){
       window.location.href = "../views/editarempleado.php?msj=3";
       }
       });
    }
    });

    /*validar foto*/
    $("#btn_subir_foto").on("click",function(e){
    e.preventDefault();  
    if($("#Codigo").val().trim() === ''){
    $("#msj_empl_cod").html('<div class="alert alert-warning alert-dismissible fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>No ha Seleccionado un Empleado</div>');    
    $("#btn_sub").hide();
    }else{
    $("#btn_sub").show();  
    }
    
    });
</script>

</html>