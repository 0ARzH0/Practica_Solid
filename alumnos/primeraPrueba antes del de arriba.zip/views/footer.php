   <!-- Pie de pagina -->
    <footer>
        <section class="col-lg-12 footer">
         <article class="col-lg-4 col-md-6 col-xs-12 text-left">
           
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x fa-color"></i>
              <i class="fa fa-map-marker fa-stack-1x "></i>
            </span>
            Col.Centro Mérida, Yucatán CP97000
            <br>
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x fa-color"></i>
              <i class="fa fa-map fa-stack-1x "></i>
            </span>
            Calle 45 No.407 Local 7 x 56y Av.Paseo de Montejo
            <br>
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x fa-color"></i>
              <i class="fa fa-phone fa-stack-1x"></i>
            </span>
            (999)928-69-47
            <br>
            <span class="fa-stack fa-lg">
              <i class="fa fa-circle fa-stack-2x fa-color"></i>
              <i class="fa fa-envelope fa-stack-1x"></i>
            </span>
            <a href="http://www.factor9.com.mx"><strong>soporte@factor9.mx</strong></a>
         </article>
         <article class="col-lg-4 text-center">

         <img src="../img/logo.png" width="220px">
         <p class="footer_center">
            <a href="http://www.factor9.com.mx/" target="_blank" class="color_verde">HOME</a> -
            <a href="http://www.factor9.com.mx/empresa/factor-9.html" target="_blank" class="color_verde">OFICINAS</a> -
            <a href="http://www.factor9.com.mx/empresa/oficinas.html" target="_blank" class="color_verde">LIBRO</a> 
          </p>
          <p class="color_gris">Factor9 <span class="fa fa-copyright"></span> 2016</p>

         </article>
         <article class="col-lg-4 text-center">
             
         <p>OBJETIVOS</p>
         <p class="color_gris">
          El mundo de los negocios hoy en dia se encuentra inmerso en un entorno altamente globalizado y muy competido, el cual obliga a las organizaciones a concentrar sus esfuerzos y sobre todo la experiencia con que cuentan en las oportunidades de negocio que se les presentan. 
         </p>   

         </article>
        </section>
      <section class="col-lg-12 text-center footer_bottom">
           Desarrollado por   <a href="http://www.serteza.com/" >serteza.com.mx</a> <span class="fa fa-copyright"></span> 2017
       </section> 
    </footer>    
       
     <!-- fin de pie de pagina -->