<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once '../model/nom_catempleados.php';
//include_once '../model/bit_movincidencas.php';
include_once "../model/alertas.php";

/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
$TipoUsuario = $_SESSION['TipoUsuario'];
$Codigo = $_POST['Codigo'];
/*datos del empleado*/
$nom_catempleados = new nom_catempleados($Codigo,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
$r = $nom_catempleados->get_empleado_turno();
foreach ($r as $d) {
$Empleado = $d['Empleado'];
$Puesto = $d['Puesto'];
/*$Turno = $d['Turno'];*/
}
/*datos del empleado
$bit_movincidencas_gen = new bit_movincidencas('','','','','','','','','','','','','','','','','','','','','','','','','','','','');
$r = $bit_movincidencas_gen->get_incidencias();*/
/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,3,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>

<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">
<!-- titulo -->
<div class="row">
    <div class="col-lg-12">
    <h1 class="page-header"><span class="fa fa-server"></span>&nbsp Administrar Incidencias</h1>
     <?php if(@$_GET['msj']>0){ ?>
    <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
    </div>
    <?php } ?>
   </div>
</div>

<!-- datos del empleado -->
<section class="col-lg-10 col-lg-offset-1 datos_user" style="margin-bottom: 1%;">
<div class="col-lg-3 text-right">
<img src="../img/foto_default.jpg" class="img-circle">  
</div>  
<form class="col-lg-9">
<div class="form-group col-lg-6">
  <label class="control-label">Nombre:</label>
  <input type="text" class="form-control" name="Nombre" value="<?php echo $Empleado; ?>">
</div>  
<div class="form-group col-lg-6">
  <label class="control-label">Turno Asignado:</label>
  <input type="text" class="form-control" name="Turno" value="<?php echo @$Turno; ?>">
</div>  
<div class="form-group col-lg-6">
  <label class="control-label">Puesto:</label>
  <input type="text" class="form-control" name="" value="<?php echo $Puesto; ?>">
</div>  
<div class="form-group col-lg-3">
  <label class="control-label">Hora Entrada:</label>
  <input type="time" class="form-control" name="" >
</div>  
<div class="form-group col-lg-3">
  <label class="control-label">Hora Salida:</label>
  <input type="time" class="form-control" name="" 
</div>  
</form>
</section>

<table class="table table-condensed table-hover" >
  <thead>
    <tr class="color_tabla">
      <th>Dia</th>
      <th>Fec</th>
      <th>Ent</th>
      <th>Sal</th>
      <th>L</th>
      <th>HE</th>
      <th>R</th>
      <th>FJ</th>
      <th>FI</th>
      <th>DL</th>
      <th>V</th>
      <th>I</th>
      <th>FL</th>
      <th>Notas</th>
    </tr>
  </thead>
<tbody>
<?php 
foreach ($r as $d) {

}
 ?>
  <tr class="dia_empl">
       <td>Viernes</td>
       <td>13</td>
       <td>09:00:00 a.m</td>
       <td>06:00:00 p.m</td>
       <td><input type="checkbox" value=""></td>
       <td>.</td>
       <td>-</td>
       <td><input type="checkbox" value=""></td>
       <td><input type="checkbox" value=""></td>
       <td><input type="checkbox" value=""></td>
       <td><input type="checkbox" value=""></td>
       <td><input type="checkbox" value=""></td>
       <td><input type="checkbox" value=""></td>
       <td>Notas</td>
  </tr>
</tbody>
</table>

</section>
</section>

<!-- modal -->
<div class="modal fade" id="control_incidencias" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Incidencias</h4>
      </div>
      <div class="modal-body">
       <div class="row">
        <form>
         <div class="form-group col-lg-6">
          <label class="control-label">Nombre:</label>
          <input type="text" class="form-control"  name="Empleado" readonly>
        </div>
        <div class="form-group col-lg-3">
          <label class="control-label">Fecha:</label>
          <input type="date" class="form-control"  name="Fecha" readonly>
        </div>
        <div class="form-group col-lg-3">
          <label class="control-label">Dia:</label>
          <input type="text" class="form-control"  name="Dia" readonly>
        </div> 
        <!-- checks -->
        <div class="col-md-12">
      <div class="form-group col-lg-3">
       <label class="checkbox-inline">
        <input type="checkbox" id="inlineCheckbox1" value="option1">Laboro
       </label>
        </div> 
        <div class="form-group col-lg-3">
       <label class="checkbox-inline">
        <input type="checkbox" id="inlineCheckbox1" value="option1">Vacaciones
       </label>
        </div> 
        <div class="form-group col-lg-3">
       <label class="checkbox-inline">
        <input type="checkbox" id="inlineCheckbox1" value="option1">Festivo Laborado
       </label>
        </div> 
        <div class="form-group col-lg-3">
       <label class="checkbox-inline">
        <input type="checkbox" id="inlineCheckbox1" value="option1">Falta Justificada
       </label>
        </div> 
        <div class="form-group col-lg-3">
       <label class="checkbox-inline">
        <input type="checkbox" id="inlineCheckbox1" value="option1">Incapacidad
       </label>
        </div>  
        <div class="form-group col-lg-3">
       <label class="checkbox-inline">
        <input type="checkbox" id="inlineCheckbox1" value="option1">Falta Injustificada
       </label>
        </div> 
        <div class="form-group col-lg-3">
       <label class="checkbox-inline">
        <input type="checkbox" id="inlineCheckbox1" value="option1">Descanso Laborado
       </label>
        </div> 
     </div>   
        <!-- fin chesck -->

        <div class="form-group col-lg-6">
          <label class="control-label">Horas extra:</label>
          <input type="text" class="form-control"  name="" readonly>
        </div>
        <div class="form-group col-lg-6">
          <label class="control-label">Por Pagar:</label>
          <input type="text" class="form-control"  name="" readonly>
        </div>
        <div class="form-group col-lg-6">
          <label class="control-label">Retardos:</label>
          <input type="text" class="form-control"  name="" readonly>
        </div>
        <div class="form-group col-lg-6">
          <label class="control-label">Por Aplicar:</label>
          <input type="text" class="form-control"  name="" readonly>
        </div>
        <div class="form-group col-lg-12">
          <label class="control-label">Observaciones:</label>
           <textarea class="form-control" name="Notas" placeholder="ingrese las notas" ></textarea> 
        </div>
      </form>
      </div>
       </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

</body>

<?php 
include_once "footer.php";
?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
        <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
    <script type="text/javascript">
    $(".dia_empl").on("click",function(e){
    e.preventDefault();
     $('#control_incidencias').modal('show');
    });
    </script>
</html>