<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once "../model/nom_vacaciones.php";
include_once "../model/nom_vacacionesdisponibles.php";
include_once "../model/grid.php";
include_once "../model/alertas.php";

/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
$TipoUsuario = $_SESSION['TipoUsuario'];
@$Codigo = $_POST['Codigo'];
$datos_empl = array();

if(!empty($Codigo)){
$datos_empl = val_vac_empl($Codigo);
}
$nom_vacaciones = new nom_vacaciones("",$Codigo,"","","","","","","","");
$r = $nom_vacaciones->get_vac_empl();

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,3,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>

<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">

<div class="row">
    <div class="col-lg-12">
    <h1 class="page-header"><span class="fa fa-plane"></span>&nbsp Vacaciones</h1>
     <?php if(@$_GET['msj']>0){ ?>
    <div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
    </div>
    <?php } ?>
   </div>
</div>

<section class="col-lg-12">

<div class="col-lg-8 col-lg-offset-2">
  <form class="form-horizontal" action="vervacaciones.php" method="POST">
    <input type="hidden" id="UsuarioID" name="UsuarioID" value="<?php echo $UsuarioID;?>">
    <input type="hidden" class="Codigo" name="Codigo">
     <div class="form-group">
       <label class="control-label col-sm-2">Buscar Empleado:</label>
       <div class="col-sm-10">
        <div class="input-group">
          <input type="text" id="buscar_empl_nom" class="form-control text-uppercase" name="Empleado" placeholder="Ingrese el nombre del Empleado...">
         <span class="input-group-btn">
          <button class="btn btn-default" name="opcion" value="1"><span class="fa fa-search"></span>&nbsp Buscar!</button>
         </span>
        </div>   
       </div>
   </div> 
  </form>
</div>

<form action="../controller/op_nom_vacaciones.php" method="POST">
<input type="hidden" id="FechaActual" value="<?php echo date("Y-m-d"); ?>">

      <div class="col-md-3 col-md-offset-9">
          <div class="form-group">
            <label class="control-label">Fecha de solicitud</label>
            <input type="date" id="FechaSolicitud" name="FechaSolicitud"  class="form-control" value="<?php echo date('Y-m-d'); ?>"  required>
          </div>
        </div> 
        <div class="form-group col-md-4">
            <label class="control-label">Cedula de identificación</label>
            <input type="text" id="Codigo" name="Codigo" class="form-control" value="<?php  echo @$datos_empl['Codigo']; ?>" placeholder="Cedula de identificacion" required readonly>
          </div>
         <div class="form-group col-md-4" >
              <label class="control-label">Nombre </label>
              <input type="text" name="Nombre" class="form-control" value="<?php  echo @$datos_empl['Empleado']; ?>" placeholder="Nombre del Empleado" readonly required>
          </div>      
           <div class="form-group col-md-4">
            <label class="control-label">Puesto</label>
            <input type="text" name="Puesto" class="form-control" value="<?php echo @$datos_empl['Puesto']; ?>" placeholder="Puesto del Empleado" required readonly>
          </div>
        <div class="form-group col-md-4">
          <label class="control-label">Unidad de Adscripción </label>
            <input type="text" class="form-control"  placeholder="Unidad de Adscripción" value="<?php echo @$datos_empl['AreaID']; ?>" required readonly>
        </div>
        <div class="form-group col-md-4">
          <label class="control-label" type="tel">Telefono </label>
            <input type="tel" name="Telefono" class="form-control" value="<?php echo @$datos_empl['Telefono']; ?>" placeholder="Telefono del Empleado" required readonly="readonly">
        </div>       
           <div class="form-group col-md-4">
            <label class="control-label">Fecha de ingreso</label>
            <input type="date" name="FechaIngreso" class="form-control" value="<?php echo @$datos_empl['FechaIngreso']; ?>" required readonly>
          </div>
          <div class="form-group col-md-4">
            <label class="control-label">Vacaciones por gozar</label>
            <input type="number" name="VacacionesPorGozar" class="form-control" value="<?php echo @$datos_empl['VacacionesPorGozar']; ?>" placeholder="0" readonly>
          </div>
        <div class="form-group col-md-4">
          <label class="control-label">Vacaciones gozadas </label>
          <input type="number" name="VacacionesGozadas" class="form-control" value="<?php echo @$datos_empl['VacacionesGozadas']; ?>"  placeholder="0" readonly>
        </div>      
           <div class="form-group col-md-4">
            <label class="control-label">N° de días</label>
            <input type="number" id="NumeroDias" name="NumeroDias" class="form-control" placeholder="0" required>
          </div>
          <div class="form-group col-md-4">
            <label class="control-label">Fecha de inicio</label>
            <input type="date" id="FechaInicio" name="FechaInicio" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
          </div>
        <div class="form-group col-md-4">
          <label class="control-label">Fecha de termino </label>
            <input type="date" id="FechaTermino" name="FechaTermino" class="form-control" required>
        </div>
           <div class="form-group col-md-4">
            <label class="control-label">Fecha de regreso</label>
            <input type="date" id="FechaRegreso" name="FechaRegreso" class="form-control"  required>
          </div>
            <div class="form-group col-lg-12">
              <label class="control-label">Observaciones</label>
              <textarea class="form-control" rows="2"  placeholder="Ingrese sus Observaciones..."  name="Observaciones"></textarea>
            </div>  
           <div class="form-group col-lg-12 text-center">
            <button class="btn btn-success" name="opcion" value="agregarvacaciones"><span class="fa fa-plus"></span>&nbsp AGREGAR SOLICITUD</button>
           </div>
      </form> 

</section>

    <table class="table table-bordered ">
    <thead class="color_tabla ">
        <tr>
            <th class="text-center">Fecha de la solicitud</th>
            <th class="text-center">Numero de días</th>
            <th class="text-center">Fecha de inicio</th>
            <th class="text-center">Fecha de conclución</th>
            <th class="text-center">Fecha de regreso</th>
            <th class="text-center">Observaciones</th>
            <th class="text-center">Cancelado</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php 
         foreach ($r as $d) { ?>
         <tr class="text-center">
             <td><?php echo $d['FechaSolicitud']; ?></td>
             <td><?php echo $d['NumeroDias']; ?></td>
             <td><?php echo $d['FechaInicio']; ?></td>
             <td><?php echo $d['FechaTermino']; ?></td>
             <td><?php echo $d['FechaRegreso']; ?></td>
             <td><?php echo $d['Observaciones']; ?></td>
             <td><?php if ($d['Cancelado']==1) { echo "Si"; }else{echo "No";} ?></td>
             <td>
             <form action="../reportes/formatovacaciones.php" method="POST">
              <button class="btn btn-primary" name="SolicitudID" value="<?php echo $d['SolicitudID']; ?>" data-toggle="tooltip" data-placement="bottom" title="Descargar Formato" formtarget="_black">
              <span class="fa fa-print" ></span>
              </button>
            <a href="#" class="btn btn-info subir_formato" name="<?php echo $d['SerieFolio']; ?>" dir="<?php echo $d['SolicitudID']; ?>" data-toggle="modal" data-target="#subir_formato_vac" data-placement="bottom" title="Subir Formato">
             <span class="glyphicon glyphicon-cloud-upload" ></span>
             </a>   
             </form>
             </td>
         </tr>   
        <?php  } ?>
    </tbody>
</table>   

<!-- Modal -->
<div class="modal fade" id="subir_formato_vac" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content text-center">
      <div class="modal-header text-center" style="background-color: #292c2f;color: #9ec502;font-size: 20px;text-align: center;">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><span class="glyphicon glyphicon-cloud-upload"></span>&nbsp Formato de Vacaciones</h4>
      </div>
      <div class="modal-body">

  <form action="../controller/op_nom_vacaciones.php" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="EmpleadoID" class="form-control" value="<?php  echo $EmpleadoID ?>">
  <input type="hidden" name="EmpresaID" class="form-control" value="<?php  echo $EmpresaID ?>">
  <input type="hidden" id="SolicitudID" name="SolicitudID" >
  <div class="form-group">
        <label class="control-label">Formato</label>
        <input type="file" class="form-control" name="archivo" accept="image/jpeg" placeholder="Seleccione un archivo con extencion JPG">
      </div>
      <div class="form-group">
          <button class="btn bnt-success" name="opcion" value="subirformatovac" >Subir &nbsp <span class="glyphicon glyphicon-send"></span></button>
      </div>
  </form>
      </div>
      <div class="modal-footer" style="border-radius: 0px 0px 3px 3px;background-color: #292c2f;color: white;">
        <a class="btn btn-danger btn-md" role="button" data-dismiss="modal">
        <span class="fa fa-times" aria-hidden="true"></span> Cerrar </a>
      </div>
      
    </div>
  </div>
</div>

</section>  
</section>
</body>

 <?php 
include_once "footer.php";
 ?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
    <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
    <!-- funciones propias -->
    <script src="../js/general.js"></script> 
    <script src="../js/vacaciones.js"></script>    
</html>