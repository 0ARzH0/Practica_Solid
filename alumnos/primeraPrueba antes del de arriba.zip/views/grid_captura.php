<?php
ob_start();
@session_start();
include_once "../components/Zebra_Pagination.php";
include_once "../model/seguridad.php";
include_once '../model/nom_detmovnom.php';
include_once "../model/plantillas.php";
include_once "../model/grid.php";

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
$TipoUsuario = $_SESSION['TipoUsuario'];

$ArregloTotal = array();
$ArregloTotal = grid_captura($UsuarioID,"","","","","");
$busquedas_html = busquedas_select($UsuarioID,$ArregloTotal[2]);

/*Periodos*/
$date_de = new DateTime(@$ArregloTotal[1][0]['FechaInicial']);
$date_al = new DateTime(@$ArregloTotal[1][0]['FechaFinal']); 
$Fecha_inicial_Per = $date_de->format('d/m/Y');
$Fecha_final_Per = $date_al->format('d/m/Y');

$paginacion = new Zebra_Pagination();
$paginacion->records(count($ArregloTotal[1]));
$paginacion->records_per_page(15);
$pagina=(($paginacion->get_page()-1)*15);
@$arr_empl_pag=array_slice($ArregloTotal[1],$pagina,15);
 
/*cabecera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,3,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();

?>

<section class="container-fluid">
<section class="col-lg-12 contenedor" style="margin-top: 2.5%;">

<div class="col-lg-12">

<h1 class="text-left col-lg-10">
<span class="fa fa-calendar"></span>&nbsp <?php echo @$ArregloTotal[1][0]['TipoNomina']."<small> (Periodo del: ".$Fecha_inicial_Per." al ".$Fecha_final_Per.") (PeriodoID: ".@$ArregloTotal[1][0]['PeriodoID'].")"; ?></small>
</h1>

<div class="text-right col-lg-2">
<form action="../reportes/formatoconcepto.php" target="_blank" method="POST">
<input type="hidden" name="AgrupacionID" value="<?php echo $ArregloTotal[1][0]['AgrupacionID']; ?>">
<input type="hidden" name="TipoNominaID" value="<?php echo $ArregloTotal[1][0]['TipoNominaID']; ?>">
<div class="form-group">
<label>&nbsp</label> 
<button  class="btn btn-info col-lg-12" value="">Imprimir Empleados&nbsp<span class="fa fa-print"></span></button> 
</div>
 </form> 
</div>

</div>

<!--nombre busquedas avanzadas -->
<ol class="breadcrumb text-left col-lg-12">
  <li class="active"><h4 class="control-label"><span class="fa fa-search-plus"></span>&nbsp Busqueda Avanzada: </h4></li>
  <li><?php echo $ArregloTotal[1][0]['Agrupacion'];  ?></li>
  <li><?php echo $ArregloTotal[1][0]['TipoNomina'];  ?></li>
</ol>

<!-- Panel izquierdo -->
    <div class="social">
        <ul>
            <li class="social_save" data-toggle="tooltip" data-placement="right" title="Guardar Cambios"><a onclick="guardarcambios()" >
            <span class="fa fa-floppy-o fa-2x"></span>
            </a></li>
            <?php if ($TipoUsuario==2 || $TipoUsuario==3): ?>
            <li class="social_edit"  data-toggle="tooltip" data-placement="right" title="Editar Empleado"><a href="../views/editarempleado.php" target="_blank">
            <span class="fa fa-pencil fa-2x"></span>
            </a></li> 
            <?php endif ?>
            <li class="social_vac"  data-toggle="tooltip" data-placement="right" title="Vacaciones"><a href="../views/vervacaciones.php" target="_blank">
            <span class="fa fa-plane fa-2x"></span>
            </a></li>
            <li class="social_inc" target="_blank" data-toggle="tooltip" data-placement="right" title="Incapacidades"><a href="../views/verincapacidades.php" target="_blank">
            <span class="fa fa-medkit fa-2x"></span>
            </a></li>
        </ul>
    </div>

<!-- datos por jquery -->
   <input type="hidden" id="UsuarioID" name="UsuarioID" value="<?php echo $UsuarioID ?>">
   <input type="hidden" id="TipoNominaID" name="TipoNominaID" value="<?php echo $ArregloTotal[1][0]['TipoNominaID']; ?>">
   <input type="hidden" id="PeriodoID" name="PeriodoID" value="<?php echo $ArregloTotal[1][0]['PeriodoID']; ?>">
   <input type="hidden" id="TipoUsuario"  value="<?php echo $TipoUsuario; ?>">
   <input type="hidden" id="num_conc" value="<?php echo count($ArregloTotal[0])+1;  ?>">

<form class="form-horizontal" action="../views/grid_captura_adv.php" method="GET">
<?php 
echo $busquedas_html;
?> 
   <div class="col-sm-2">  
    <label class="control-label">&nbsp</label>   
    <button class="btn btn-success col-lg-12" name="BusquedaAvanzada" value="1"><span class="fa fa-search"></span>&nbsp Buscar</button>  
   </div>  
 </div><!-- inicio del div esta en la funcion -->
</form>


  <table class="table table-condensed table-hover" id="table_grid">
    <thead>
      <tr class="color_tabla">
        <th></th>
        <th>ID</th>
        <th>EMPLEADO</th>
        <th>DEPARTAMENTO</th>
         <?php for ($i=0; $i < count($ArregloTotal[0]) ; $i++) { ?>
          <th><?php echo $ArregloTotal[0][$i]['Concepto']; ?></th>
         <?php } ?>
      </tr>
    </thead>
    <tbody>
     <?php for ($i=0; $i < count($arr_empl_pag) ; $i++) { ?>
        <tr style="font-size: 12px;">
         <td><?php echo $i+1; ?></td>
         <td style="font-weight: bold;"><?php echo $arr_empl_pag[$i]['Codigo']; ?></td>
         <!-- mandar a admin de incidencias -->
         <form action="../views/admin_incidencias.php" method="POST">
         <input type="hidden" name="Codigo" value="<?php echo $arr_empl_pag[$i]['Codigo']; ?>">
         <td><button class="btn btn-default" formtarget="_blank" name=""><?php echo $arr_empl_pag[$i]['Empleado']; ?></button></td>
         </form>
         <td><?php echo $arr_empl_pag[$i]['Departamento']; ?></td>
         <?php for ($i1=0; $i1 < count($ArregloTotal[0]) ; $i1++) { 
         
         $nom_detmovnom = new nom_detmovnom("",$arr_empl_pag[$i]['Codigo'],$ArregloTotal[0][$i1]['ConceptoID'],$ArregloTotal[1][0]['TipoNominaID'],$ArregloTotal[1][0]['PeriodoID'],"","","","","","","","","","","","");
         $r = $nom_detmovnom->get_concepto_empl_uni();
          
           if($ArregloTotal[0][$i1]['Importe']==1){ #importe
            $value_name = "Importe";
           }elseif($ArregloTotal[0][$i1]['Unidades']==1){ #unidades
            $value_name = "Unidades";
           }
/*prueba */
           $color = "#fff";
           $attr_val = "";
           $attr_read = "";
           $class = "";
           $attr_alt = "";
           $attr_list = "";
           if($ArregloTotal[1][$i]['Bloqueado']==1){  
            #si el periodo esta bloqueado
           $attr_read = "readonly"; 
           if (mysqli_num_rows($r)>0){
           foreach ($r as $d) {
           if($d['Aprobado']==2){ $color = "#34A853"; }elseif($d['Aprobado']==3){ $color = "#EA4335";} 
           if($d[$value_name]!=0){  $attr_val = $d[$value_name]; }          
           }
           }
           }else{
           #si el periodo no esta bloqueado
           if (mysqli_num_rows($r)>0){
           foreach ($r as $d) {
           if($d['Aprobado']==2){ $color = "#34A853"; }elseif($d['Aprobado']==3){ $color = "#EA4335";} 
           if($d[$value_name]!=0){  $attr_val = $d[$value_name]; }   
           if($TipoUsuario < $d['Aprobado']){ $attr_read = "readonly"; }
           $class = "concepto";
           $attr_alt = $d['Aprobado'];
           $attr_list = $d['detmov_id'];
           }
           }else{
           $class = "concepto";  
           }
           } 
            echo "
            <td bgcolor=' ".$color." '>
            <input type='number' class='form-control ".$class." '  
            alt='".$attr_alt."'
            list='".$attr_list."'
            name='".$ArregloTotal[0][$i1]['ConceptoID']."' 
            dir='".$arr_empl_pag[$i]['Codigo']."'
            for='".$ArregloTotal[0][$i1]['Unidades']."".$ArregloTotal[0][$i1]['Importe']."'
            value='".$attr_val."'
             ".$attr_read.">
            </td>";
/*prueba */
         } 
       } ?>
    </tr>
    </tbody>       
  </table>

  <!-- paginacion -->
    <section class="col-lg-7 text-right">
    <?php  $paginacion->render(); ?>
   </section>
   <div class="alert alert-info col-lg-2 col-lg-offset-3 text-right" role="alert" style="margin-top: 12px;">
   <span class="fa fa-info-circle"></span>&nbsp Total de Registros: <?php echo  "<strong>".count($ArregloTotal[1])."</strong>"; ?>
   </div>

<!-- inicio de los modals -->

<!-- Modal guardar -->
<div class="modal fade" id="barra_proceso"  role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Guardando...</h4>
      </div>
      <div class="modal-body">
<div class="progress">
  <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
  100% Complete
  </div>
</div>
      </div>
    </div>
  </div>
</div>

<!-- Modal aprobar-->
<div class="modal fade" id="barra_proceso_2"  role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content text-center">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Aprobando...</h4>
      </div>
      <div class="modal-body">
<div class="progress">
  <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
  100% Complete
  </div>
</div>
      </div>
    </div>
  </div>
</div>

<!-- fin de los modals -->

</section>
</section>

      </div>
    </div>
  </div>
</div>

</body>

<?php 
include_once "footer.php";
?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
        <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
    <script src="../js/grid_captura.js"></script>
</html>