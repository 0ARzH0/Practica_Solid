<?php
ob_start();
@session_start();
include_once "../model/plantillas.php";
include_once "../model/seguridad.php";
/*Parametros*/
$Nombre = $_SESSION['Nombre'];
$TipoUsuario = $_SESSION['TipoUsuario'];

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,1,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>

<section class="container-fluid">
    <section class="col-lg-12 contenedor margen_tit" >
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Rotación de Empleados <!-- <small>Rotación de Empleados</small> -->
                        </h1>
                    </div>
                </div>
        <div id="myfirstchart" style="height: 20%;"></div>
    </section>   
</section>

</body>

<?php 
include_once "footer.php";
?>


    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
    <!-- Morris Charts JavaScript -->
    <script src="../components/bootstrap/js/plugins/morris/raphael.min.js"></script>
    <script src="../components/bootstrap/js/plugins/morris/morris.min.js"></script>
    <script src="../components/bootstrap/js/plugins/morris/morris-data.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
    <script type="text/javascript">
 new Morris.Line({
  // ID of the element in which to draw the chart.
  element: 'myfirstchart',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.
  data: [
    { year: '2008', value: 20 },
    { year: '2009', value: 10 },
    { year: '2010', value: 5 },
    { year: '2011', value: 5 },
    { year: '2012', value: 20 }
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'year',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Value']
});
    </script>
</html>
<?php ob_end_flush(); ?>