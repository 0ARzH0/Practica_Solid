<?php
ob_start();
@session_start();
include_once "../controller/op_seguridad.php";
include_once "header.php";
/*Parametros*/
$Nombre = $_SESSION['Nombre'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Gestor Factor 9</title>

    <link href="../components/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../css/estilo.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<?php 
$html_header = navegacion($Nombre,5);
echo $html_header;
?>
<section class="container-fluid">
    <section class="col-lg-12" style="margin-top: 5%; margin-bottom: 5%;">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Rotación de Empleados <!-- <small>Rotación de Empleados</small> -->
                        </h1>
<!--                         <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol> -->
                    </div>
                </div>
        <div id="myfirstchart" style="height: 20%;"></div>
    </section>   
</section>

 <?php 
include_once "footer.php";
 ?>

</body>
    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/scripts.js"></script>
</html>
<?php ob_end_flush(); ?>