<?php 
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/plantillas.php";
include_once '../model/nom_captura.php';
include_once "../model/seg_catpermisos.php";
include_once "../model/seg_catusuarios.php";
include_once "../model/vistas.php";
include_once "../model/alertas.php";
/*Alertas*/
$arr_alert = array();
$arr_alert = alertas(@$_GET['msj']);

/*Alertas*/
/*@$msj = $_GET['msj'];
@$alert = "success";
@$icon = "ok";
if ($msj == 1):
$msj_aux = " El Permiso se ha Agregado Correctamente!";
elseif ($msj == 2):
$alert = "danger";
$icon = "times";
$msj_aux = " Ocurrio un Error!";
elseif ($msj == 3):
$alert = "warning";
$icon = "warning-sign";
$msj_aux = " El Usuario ya tiene los mismos Permisos!";
elseif ($msj == 4):
$msj_aux = " El Usuario se Agrego Correctamente!";
elseif ($msj == 5):
$alert = "warning";
$icon = "warning-sign";
$msj_aux = " El Usuario ya exite!";
endif;*/

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$TipoUsuario = $_SESSION['TipoUsuario'];
$Usuario_Aux_Nom = "Usuario";
@$UsuarioID_Aux = $_POST['UsuarioID'];

$seg_catusuarios = new seg_catusuarios($UsuarioID_Aux,"","","","");
$r1 = $seg_catusuarios->get_usuario();
foreach ($r1 as $d) { $Usuario_Aux_Nom=$d['Usuario']; }

$seg_catpermisos = new seg_catpermisos("","",$UsuarioID_Aux,"","");
$r = $seg_catpermisos->get_agrupacion_user();

/*cabezera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,6,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>

<section class="container-fluid">
<section class="col-lg-12 contendor margen_tit">
<div class="row">
<div class="col-lg-12">
<h1 class="page-header"><span class="fa fa-unlock-alt"></span>&nbsp Permisos</h1>
</div>
</div>

<?php if(@$_GET['msj']>0){ ?>
<div class="<?php echo "alert alert-".$arr_alert['alert']; ?> alert-dismissible text-center fade in" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
<span class='<?php echo "fa fa-".$arr_alert['icon']; ?>' ></span>&nbsp <?php echo $arr_alert['msj_alert']; ?>
</div>
<?php } ?>

<!-- datos -->
<section class="col-lg-7 border_2" style="margin-right:  1%; padding: 1% 1% 1% 0%;">
  <form class="form-horizontal" action="../views/verpermisos.php" method="POST">
  <input id="UsuarioID" type="hidden" class="form-control" name="UsuarioID">
  <input id="UsuarioID_Aux" type="hidden" value="<?php echo $UsuarioID_Aux; ?>">
    <div class="form-group">
      <label class="control-label col-sm-3">Buscar Usuario:</label>
      <div class="col-sm-9">
      <div class="input-group">
      <input id="buscar_usuario" type="text" class="form-control" placeholder="Buscar Usuario...">
      <span class="input-group-btn">
        <button id="btn_bus_user" class="btn btn-default" name="usuario_bus" value="1"><span class="fa fa-search"></span>&nbsp Buscar!</button>
      </span>
      </div>
      </div>
    </div>
  </form>

<div class="col-lg-10 col-lg-offset-1">
<ol class="breadcrumb" style="background-color: #CCC; ">
  <li><span class="fa fa-user"></span>&nbsp <?php echo $Usuario_Aux_Nom; ?></li>
  <li><span class="fa fa-th"></span>&nbsp Agrupaciones</li>
  <li><span class="fa fa-th-large"></span>&nbsp Areas</li>
  <li><span class="fa fa-stop"></span>&nbsp Departamentos</li>
</ol>
</div>

<?php 
$cont_areas = 1;
foreach ($r as $d) { 
$collapse = "collapse".$d['AgrupacionID'];  ?>
<div class="col-lg-10 col-lg-offset-1">
 <a class="" role="button" data-toggle="collapse" href="#<?php echo $collapse; ?>" aria-expanded="false" aria-controls="collapseExample">
<span class="fa fa-th"></span>&nbsp <?php echo $d['Agrupacion']; ?>  
</a>
<div class="collapse" id="<?php echo $collapse; ?>">
  <div class="">
    <ol>
     <?php $vistas = new vistas($UsuarioID_Aux,$d['AgrupacionID'],"","","","","");
      $r1 = $vistas->bus_areasporagrup();
      foreach ($r1 as $d1) { ?>
      <li>
      <a role="button" data-toggle="collapse" href="#<?php echo 'collapse-a'.$cont_areas; ?>" aria-expanded="false" aria-controls="collapseExample">
       <span class="fa fa-th-large"></span>&nbsp <?php echo $d1['Area']; ?> 
      </a>
      <div class="collapse" id="<?php echo 'collapse-a'.$cont_areas; ?>">
       <div class="">
       <ol>
       <?php  $vistas2 = new vistas($UsuarioID_Aux,$d['AgrupacionID'],"",$d1['AreaID'],"","","");
      $r2 = $vistas2->get_deptoxarea_user();
      foreach ($r2 as $d2) { ?>
      <li>
      <span class="fa fa-stop"></span>&nbsp <?php echo $d2['Departamento']; ?>
      </li>
      <?php } ?>
      </ol>
      </div>
     </div>
      </li>
      <?php $cont_areas++; }  ?>
    </ol>
  </div>
</div> 
</div>
<?php } ?>

<section class="col-lg-12 text-center">
<?php if(@$UsuarioID_Aux > 0): ?>
 <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#permisos" aria-expanded="false" aria-controls="collapseExample">
<span class="fa fa-plus"></span>&nbsp Agregar Permisos
</button>
<?php endif; ?>
<div class="collapse" id="permisos">
  <div class="">
   <form action="../controller/op_seg_catpermisos.php" method="POST">
    <input type="hidden" name="UsuarioID" value="<?php echo $UsuarioID_Aux; ?>">
    <div class="form-group col-lg-3">
      <label class="control-label">Agrupacion</label>
      <input id="AgrupacionID" type="hidden" name="AgrupacionID">
      <input id="buscar_agrupacion" type="text" class="form-control" name="Agrupacion" required>
    </div>
    <div class="form-group col-lg-3">
      <label class="control-label">Áreas</label>
      <div id="mostrar_areas">
        <select id="seleccionar_area" class="form-control" name="AreaID"> </select>
      </div>
    </div> 
    <div class="form-group col-lg-3">
      <label class="control-label">Departamentos</label>
       <div id="mostrar_deptos">
        <select class="form-control" name="DepartamentoID"></select>
      </div>
    </div>
    <div class="form-group col-lg-3">
      <label class="control-label">&nbsp</label>
      <button class="btn btn-success col-sm-12" name="opcion" value="agregarpermiso">Agregar &nbsp<span class="fa fa-plus-circle"></span></button>
    </div>
   </form>
  </div>
</div> 
</section>

</section>

<section class="col-lg-4 datos_user_2" style="margin-bottom: 1%;">
<h3><span class="fa fa-user"></span>&nbsp Agregar Usuario</h3>
  <form action="../controller/op_seg_catusuarios.php" method="POST">
  <div class="form-group">
    <label class="control-label">Usuario</label>
    <input type="text" class="form-control"  name="Usuario" required>
  </div>
  <div class="form-group">
    <label class="control-label">Nombre</label>
    <input type="text" class="form-control"  name="Nombre" required>
  </div>
  <div class="form-group">
    <label class="control-label">Contraseña</label>
    <input id="pass_1" type="password" minlength="8" class="form-control pass"  name="Password" required>
  </div>
    <div class="form-group">
    <label class="control-label">Confirmar Contraseña</label>
    <input id="pass_2" type="password" minlength="8" class="form-control pass"  name="" required>
  </div>
    <div class="form-group">
    <label class="control-label">Tipo de Usuario</label>
    <select class="form-control" name="TipoUsuario">
      <option value="3">Administrador(Nivel 3)</option>
      <option value="2">Jefe de Recursos Humanos(Nivel 2)</option>
      <option value="1">Jefe de Area(Nivel 1)</option>
    </select>
  </div>
  <div class="form-group text-center">
    <button id="btn_add_user" class="btn btn-success" name="opcion" value="agregarusuario"><span class="fa fa-save"></span>&nbsp Guardar</button>
  </div>
</form>

</section>

</section>
</section>

</body>

<?php 
include_once "footer.php";
?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
    <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>
    <script src="../js/permisos.js"></script>

</html>