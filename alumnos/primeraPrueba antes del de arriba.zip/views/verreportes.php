<?php
ob_start();
@session_start();
include_once "../model/seguridad.php";
include_once "../model/seg_catpermisos.php";
include_once "../model/nom_catnominas.php";
include_once "../model/vistas.php";
include_once "../model/plantillas.php";
include_once "../model/grid.php";

/*Parametros*/
$UsuarioID = $_SESSION['UsuarioID'];
$Nombre = $_SESSION['Nombre'];
$Usuario = $_SESSION['Usuario'];
$Password = $_SESSION['Password'];
$TipoUsuario = $_SESSION['TipoUsuario'];
@$TipoReporte = $_GET['Tiporeporte'];
$action = "";
$Movimiento = "";
$Reporte = "";
$ArregloTotal = array();

$vistas = new vistas($UsuarioID,"","","","","","");
$r = $vistas->get_agrupaciones_user();
$r2 = $vistas->get_departamentos_user();
$r1 = $vistas->get_areas_user();

@$AgrupacionID = $_POST['AgrupacionID'];
@$TipoNominaID=$_POST['TipoNominaID'];
@$AreaID=$_POST['AreaID'];
@$DepartamentoID=$_POST['DepartamentoID'];
@$BusquedaAvanzada=$_POST['BusquedaAvanzada'];

#$ArregloTotal = grid_captura($UsuarioID,$AgrupacionID,$TipoNominaID,$AreaID,$DepartamentoID,$BusquedaAvanzada);
#$busquedas_html = busquedas_select($UsuarioID,$ArregloTotal[2]);

if($TipoReporte==1){ $action = "formatoactivos";  $Reporte = "Empleados Activos";
}elseif($TipoReporte==2) { $action = "formatobajas"; $Movimiento = "BAJA";  $Reporte = "Baja de Empleados";
}elseif($TipoReporte==3) { $action = "formatoaltas"; $Movimiento = "ALTA";  $Reporte = "Alta de Empleados";
}elseif($TipoReporte==4) { $action = "formatoconcentrado"; $Reporte = "Concentrados";
}elseif($TipoReporte==5) { $action = "formatoreporteincapacidades"; $Reporte = "Incapacidades";
}elseif($TipoReporte==6) { $action = "formatoreportevacaciones"; $Reporte = "Vacaciones";
} 

/*cabecera*/
$plantillas = new plantillas($Nombre,$TipoUsuario,4,"Gestor Misuper","");
echo $plantillas->cabecera();

echo "<body>";
/*barra de navegacion*/
echo $plantillas->nav_bar();
?>

<section class="container-fluid">
<section class="col-lg-12 contenedor margen_tit">

<div class="row">
<div class="col-lg-12">
<h1 class="page-header"><span class="fa fa-file-word-o"></span>&nbsp Reportes/<?php echo $Reporte; ?></h1>
</div>
</div>

<!-- panel de busquedas avanzadas -->
<section class="col-lg-12 text-center">
<h3 class="text-center">Busqueda Avanzada</h3>

<!-- datos por jquery -->
<input type="hidden" id="UsuarioID" name="UsuarioID" value="<?php echo $UsuarioID ?>">
<!-- <input type="hidden" id="TipoNominaID" name="TipoNominaID" value="<?php echo $ArregloTotal[1][0]['TipoNominaID']; ?>">
<input type="hidden" id="PeriodoID" name="PeriodoID" value="<?php echo $ArregloTotal[1][0]['PeriodoID']; ?>"> -->

<?php  echo "<form class='form-horizontal' action='../reportes/".$action.".php'  method='POST'>
    <input type='hidden' name='Movimiento' value='".$Movimiento."'>
    <input type='hidden' name='TipoReporte' value='".$TipoReporte."'>";
?>
 <div class="form-group">
   <div class="col-sm-3">
      <label class="control-label">Agrupación</label>
        <select id="AgrupacionID" name="QWdydXBhY2lvbklE" class="form-control" >
        <?php foreach ($r as $d) {
          echo '<option  value=" '.base64_encode($d['AgrupacionID']).' ">'.$d['Agrupacion'].'</option>';  
          }  ?>      
        </select> 
     </div> 
<!--      <div class="col-sm-2">
     <label class="control-label">Tipo de Nómina</label>
        <select name="VGlwb05vbWluYUlE" class="form-control">
        <option value="0">--TODOS--</option>
       <?php for ($i=0; $i < count($TipoNominaID) ; $i++) { 
         $nom_catnominas=new nom_catnominas($TipoNominaID[$i],"");
          $r=$nom_catnominas->get_tiponomina();
          foreach ($r as $d) {
          echo '<option value=" '.base64_encode($d['TipoNominaID']).'">'.$d['TipoNomina'].'</option>';
          }
        } ?>
        </select> 
     </div> --> 
     <input type="hidden" name="VGlwb05vbWluYUlE" value="<?php echo '0'; ?>">

    <div class="col-sm-3"> 
       <label class="control-label">Área</label>
       <div id="ver_areas">
         <select id="AreaID" name="QXJlYUlE" class="form-control" >
          <option selected value="0">--TODOS--</option>
        <?php foreach ($r1 as $d) {
         echo '<option value=" '.base64_encode($d['AreaID']).' ">'.$d['Area'].'</option>';
         } ?>
      </select></div>
      </div> 
     <div class="col-sm-3">    
        <label class="control-label">Departamento</label>
        <div id="ver_deptos"> 
         <select name="RGVwYXJ0YW1lbnRvSUQ=" class="form-control">
         <option selected value="0" >--TODOS--</option>
        <?php foreach ($r2 as $d) { 
        echo '<option value=" '.base64_encode($d['DepartamentoID']).' ">'.$d['Departamento'].'</option> ';
           } ?>
     </select></div>    
     </div>
   <div class="col-sm-3">  
    <label class="control-label">&nbsp</label>   
    <button class="btn btn-success col-lg-12" value="1" formtarget="_black"><span class="fa fa-search"></span>&nbsp Buscar</button>  
   </div>  
 </div><!-- inicio del div esta en la funcion -->
 <?php if($TipoReporte >= 2){ ?>
    <div class="form-group ">
        <label class="control-label col-sm-3">Fecha inicial: </label>
        <div class="col-sm-2">
            <input type="date" class="form-control" name="FechaInicial" value="<?php echo date('Y-m-d'); ?>">
        </div>
        <label class="control-label col-sm-1">Fecha final: </label>
        <div class="col-sm-2">
            <input type="date" class="form-control" name="FechaFinal" value="<?php echo date('Y-m-d'); ?>">
        </div>
    </div>
   <?php } ?>     
</form> 

</section>

</section>
</section>
</body>

<?php  include_once "footer.php"; ?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/jquery/jquery.min.js"></script>
    <script src="../components/jquery/jquery-ui.js"></script>
        <!-- Bootstrap js -->
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>
    <script src="../components/bootstrap/js/bootbox.min.js"></script>
     <!-- funciones propias -->
    <script src="../js/general.js"></script>   
    <script type="text/javascript">
    $("#AgrupacionID").on("ready click change",function(e){
    e.preventDefault();
    $( "#ver_areas" ).load( "../controller/op_vistas.php",
    {AgrupacionID:$("#AgrupacionID").val(),UsuarioID:$("#UsuarioID").val(),opcion:"areasporagrupacion_grid"});
    });
    </script>
</html> 