<?php 
include_once "../model/seg_catpermisos.php";
include_once "../model/conexion.php";
include_once '../model/nom_captura.php';
@session_start();

ob_start();
include('../components/fpdf/fpdf.php');

$UsuarioID =$_SESSION['UsuarioID'];

@$FechaInicial=$_POST['FechaInicial'];
@$FechaFinal=$_POST['FechaFinal'];
@$AgrupacionID =$_POST['AgrupacionID'];
@$AgrupacionID_adv =$_POST['AgrupacionID']."<br>";
@$AreaID = $_POST['AreaID'];
@$AreaID_adv=$_POST['AreaID']."<br>";
@$TipoNominaID=$_POST['TipoNominaID']."<br>";
@$SucursalID=$_POST['SucursalID']."<br>";
@$DepartamentoID=$_POST['DepartamentoID']."<br>";
@$BusquedaAvazada=$_POST['BusquedaAvazada']."<br>";
@$Emplea=$_POST['Codigo'];

$seg_catpermisos = new seg_catpermisos("","",$UsuarioID,"","");
$r = $seg_catpermisos->get_permisos_user();

$agrupant="";
$areaant="";
$departamentoant="";
$conexion = new conexion();
$sql = "SELECT e.CodigoNominaID,p.AgrupacionID,a.Agrupacion ,p.AreaID,e.EmpresaID, e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado, mp.DepartamentoID,d.Departamento, e.TipoNominaID, n.TipoNomina, ar.Area , pe.PeriodoID, pe.FechaInicial, pe.FechaFinal, pe.Ejercicio, co.ConceptoID, co.Concepto, dt.Importe, co.PercepcionDed, dt.Unidades, dt.Saldo
    FROM nom_catempleados e 
    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID
    INNER JOIN nom_catperiodos pe ON  e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1
    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
    INNER JOIN nom_catagrupaciones a ON mp.AgrupacionID = a.AgrupacionID
    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
    INNER JOIN nom_detmovnom dt ON e.Codigo = dt.Codigo AND dt.PeriodoID = pe.PeriodoID AND dt.Ejercicio = pe.Ejercicio
    INNER JOIN nom_catconceptos co ON dt.ConceptoID = co.ConceptoID 
    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND mp.DepartamentoID = p.DepartamentoID AND p.UsuarioID = '$UsuarioID'
    WHERE e.Estatus = 'A' AND (dt.Importe <> 0 or dt.Unidades <> 0) AND e.Codigo= '$Emplea'";
$resp = $conexion->ejecutarconsulta($sql);

foreach ($resp as $datos) {
$agrupa=$datos['Agrupacion'];
$tem2=$datos['Area'];
$depa=$datos['Departamento'];
$tipnom=$datos['TipoNomina'];

}
$cont=0;
$contant="";


$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',10);
$cont=0;
// $pdf->Image('../img/imagenes/logo-liga3.jpg',13,13,25,25,'JPG','');
$pdf->Cell(100,10,"REPORTE DE ACUMULADOS POR EMPLEADO",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(190,5,utf8_decode("Fecha de generaci��n ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID_adv>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"C"); }
    	if($AreaID_adv > 0){$pdf->Cell(40,5,$tem2,0,0,"C"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"C"); }

$pdf->SetFont('Arial','B',10);
$pdf->Ln();
$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
$pdf->Cell(30,5,"Departamento".$Emplea,0,0,"L");
		$pdf->Cell(20,5,"Tipo".$UsuarioID,0,0,"L");
		$pdf->Cell(20,5,"Concepto",0,0,"L");
		$pdf->Cell(15,5,"Codigo",0,0,"L");
		$pdf->Cell(55,5,"Empleado",0,0,"L");
		$pdf->Cell(20,5,"Unidades",0,0,"L");
		$pdf->Cell(20,5,"Importe",0,0,"L");
		$pdf->Cell(20,5,"Saldo",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
		$cont=35;
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;
foreach ($resp as $datos) {

if ($cont>280) {
	$pdf->AddPage();
$pdf->SetFont('Arial','B',10);
$cont=0;
// $pdf->Image('../img/imagenes/logo-liga3.jpg',13,13,25,25,'JPG','');
$pdf->Cell(100,10,"REPORTE DE ACUMULADOS POR EMPLEADO",0,0,"L");
$pdf->Ln();
$pdf->SetFont('Arial','B',8);
$pdf->Cell(190,5,utf8_decode("Fecha de generaci��n ").Date("d")."/".Date("m")."/".Date("Y"),0,0,"R");

	$pdf->SetFont('Arial','B',10);
	$pdf->Ln();
	if($AgrupacionID_adv>0){
	$pdf->Cell(40,5,$agrupa,0,0,"C");
	}
	if($TipoNominaID > 0){ $pdf->Cell(40,5,$tipnom,0,0,"L"); }
    	if($AreaID_adv > 0){$pdf->Cell(40,5,$tem2,0,0,"L"); }
    	if($DepartamentoID > 0){$pdf->Cell(40,5,$depa,0,0,"L"); }

$pdf->SetFont('Arial','B',10);
$pdf->Ln();
$pdf->Cell(250,5,'_________________________________________________________________________________________________',0,0,"L");
$pdf->Ln();
$pdf->Cell(30,5,"Departamento",0,0,"L");
		$pdf->Cell(20,5,"Tipo",0,0,"L");
		$pdf->Cell(20,5,"Concepto",0,0,"L");
		$pdf->Cell(15,5,"Codigo",0,0,"L");
		$pdf->Cell(55,5,"Empleado",0,0,"L");
		$pdf->Cell(20,5,"Unidades",0,0,"L");
		$pdf->Cell(20,5,"Importe",0,0,"L");
		$pdf->Cell(20,5,"Saldo",0,0,"L");
		$pdf->Ln();
		$pdf->Cell(250,5,'_______________________________________________________________________ __________________________',0,0,"L");
		$cont=35;
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;

}



	if($datos['Departamento'] != $departamentoant){ 
	if($cont==35){$pdf->Ln();}$agrupant="";
$areaant="";
	$areaant="";
	$contant="";
	$departamentoant=$datos['Departamento'];
		if($contadorVueltas>0){
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_______",0,0,"L");;
		$pdf->Ln();
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(20,5,$contadorActivos,0,0,"C");
		$pdf->Cell(20,5,$contadorAltas,0,0,"C");
		$pdf->Cell(20,5,$contadorBajas,0,0,"C");
		$pdf->Ln();
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;
		$cont=$cont+6;
	
	}
	
	
	$pdf->Ln();
$pdf->SetFont('Arial','B',10);

$pdf->Cell(50,5,$datos['Departamento'],0,0,"L");
$cont=$cont+5;
$pdf->Ln();
}
if($datos['PercepcionDed'] != $areaant){
	$areaant=$datos['PercepcionDed'];
	if($contadorVueltas>0){
	if($cont==35){$pdf->Ln();}
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_______",0,0,"L");;
		$pdf->Ln();
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(20,5,$contadorActivos,0,0,"C");
		$pdf->Cell(20,5,$contadorAltas,0,0,"C");
		$pdf->Cell(20,5,$contadorBajas,0,0,"C");
		$pdf->Ln();
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;
		$cont=$cont+6;
	
	}
	$dedper="";
	if($datos['PercepcionDed']=="D"){
		$dedper="DEDUCCIONES";
	}
		else{
		$dedper="PERCEPCION";
	}
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(30,5,"",0,0,"L");
	$pdf->Cell(50,5,$dedper,0,0,"L");
	$cont=$cont+5;
	$pdf->Ln();
}

if($datos['ConceptoID'] != $contant){
	$contant=$datos['ConceptoID'];
	if($contadorVueltas>0){
	if($cont==35){$pdf->Ln();}
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_______",0,0,"L");;
		$pdf->Ln();
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(20,5,$contadorActivos,0,0,"C");
		$pdf->Cell(20,5,$contadorAltas,0,0,"C");
		$pdf->Cell(20,5,$contadorBajas,0,0,"C");
		$pdf->Ln();
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;
		$cont=$cont+6;
	
	}
	$dedper="";
	$pdf->SetFont('Arial','B',10);
	$pdf->Cell(30,5,"",0,0,"L");
	$pdf->Cell(20,5,"",0,0,"L");
	$pdf->Cell(50,5,$datos['Concepto'],0,0,"L");
	$cont=$cont+5;
	$pdf->Ln();
}




$pdf->SetFont('Arial','',8);
	$pdf->Cell(30,5,"",0,0,"L");
	$pdf->Cell(20,5,"",0,0,"L");
	$pdf->Cell(20,5,"",0,0,"L");
	$pdf->Cell(15,5,$datos['Codigo'],0,0,"L");
	$pdf->Cell(55,5,$datos['Empleado'],0,0,"L");
		$pdf->Cell(20,5,$datos['Unidades'],0,0,"C");
		$pdf->Cell(20,5,$datos['Importe'],0,0,"C");
		$pdf->Cell(20,5,$datos['Saldo'],0,0,"C");
		$pdf->Ln();
	// 	$pdf->Cell(30,5,"",0,0,"L");
	// $pdf->Cell(30,5,"",0,0,"L");
	// $pdf->Cell(40,5,"",0,0,"L");
	// 	$pdf->Cell(40,5,"",0,0,"L");
	// 	$pdf->Cell(20,5,$datos['E'],0,0,"C");
	// 	$pdf->Cell(20,5,$datos['A'],0,0,"C");
	// 	$pdf->Cell(20,5,$datos['B'],0,0,"C");
	// 	$pdf->Ln();
		$contadorBajas=$contadorBajas+$datos['Saldo'];
		$contadorAltas=$contadorAltas+$datos['Importe'];
		$contadorActivos=$contadorActivos+$datos['Unidades'];
		$cont=$cont+10;
		$contadorVueltas++;
	

}
$pdf->Ln();

$pdf->Cell(40,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(50,1,"",0,0,"L");
	$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"_____________",0,0,"L");
		$pdf->Cell(20,1,"________",0,0,"L");;
		$pdf->Ln();
		$pdf->Cell(40,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(50,5,"",0,0,"L");
	$pdf->Cell(20,5,$contadorActivos,0,0,"C");
		$pdf->Cell(20,5,$contadorAltas,0,0,"C");
		$pdf->Cell(20,5,$contadorBajas,0,0,"C");
		$pdf->Ln();
		$contadorVueltas=0;
		$contadorActivos=0;
		$contadorBajas=0;
		$contadorAltas=0;

$pdf->Output("Recibo_Conceptrados_por_Concepto.pdf",'I');
ob_end_flush(); 
?>