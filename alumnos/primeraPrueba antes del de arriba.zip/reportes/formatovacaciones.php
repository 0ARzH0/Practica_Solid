<?php 
include_once "../model/nom_vacaciones.php";
ob_start();
include('../components/fpdf/fpdf.php');

#datos
$nom_vacaciones = new nom_vacaciones($_POST['SolicitudID'],"","","","","","","","","");
$r = $nom_vacaciones->get_vac_empl_sol();
foreach ($r as $d){
$FechaIncial = $d['FechaInicio'];
$FechaRegreso = $d['FechaRegreso'];
$FechaTermino = $d['FechaTermino'];
$NumeroDias = $d['NumeroDias'];
$Observaciones = $d['Observaciones'];
$FechaSolicitud=$d['FechaSolicitud'];
$Empleado = $d['Empleado'];
$Area = $d['Area'];
$Departamento = $d['Departamento'];
$Puesto = $d['Puesto'];
$Telefono = $d['Telefono'];
$ImgFormato = $d['ImgFormato'];
}


$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','',15);

if (file_exists($ImgFormato)) {	
$pdf->Image($ImgFormato,10,10,190,200,'JPG','');
}else{
$pdf->Cell(200,10,"Solicitud de Vacaciones",0,0,"C"); 
$pdf->Ln();

$pdf->Ln();
$pdf->Cell(160,10,utf8_decode("Fecha de solicitud: "),0,0,"R");
$pdf->Cell(30,10,$FechaSolicitud,0,0,"R");
$pdf->Ln();
$pdf->Ln();

$pdf->SetFont('Arial','',12);
$pdf->Cell(25,10,"NOMBRE: ",0,0,"L");
$pdf->Cell(100,10,$Empleado,'B',0,"L");
//$pdf->Image('fotos/F1.jpg',150,60,50,60,'JPG','');
$pdf->Ln();
$pdf->Cell(30,10,utf8_decode("ÁREA: "),0,0,"L");
$tem=explode(" ", $Area);
$pdf->Cell(70,10,$tem[1],'B',0,"L");
$pdf->Cell(40,10,utf8_decode("DEPARTAMENTO: "),0,0,"L");
$pdf->Cell(50,10,$Departamento,'B',0,"L");
$pdf->Ln();
$pdf->Cell(30,10,utf8_decode("PUESTO: "),0,0,"L");
$pdf->Cell(70,10,$Puesto,'B',0,"L");
$pdf->Cell(40,10,utf8_decode("TELÉFONO: "),0,0,"L");
$pdf->Cell(50,10,$Telefono,'B',0,"L");

$pdf->Ln();

$pdf->Cell(50,10,"FECHA DE INICIO: ",0,0,"L");
$pdf->Cell(50,10,$FechaIncial,'B',0,"L");

$pdf->Cell(50,10,"FECHA DE TERMINO: ",0,0,"L");
$pdf->Cell(40,10,$FechaTermino,'B',0,"L");
$pdf->Ln();
$pdf->Cell(50,10,"FECHA DE REGRESO: ",0,0,"L");
$pdf->Cell(50,10,$FechaRegreso,'B',0,"L");



$pdf->Cell(50,10,utf8_decode("NUMERO DE DIAS: "),0,0,"L");
$pdf->SetFont('Arial','B',15);
$pdf->Cell(40,10,$NumeroDias,'B',0,"C");
$pdf->Ln();

$pdf->SetFont('Arial','',12);
$pdf->Cell(190,10,utf8_decode("OBSERVACIONES: "),0,0,"C");
$pdf->Cell(190,10,$Observaciones,0,0,"C");


$pdf->Ln();
$pdf->Cell(95,10,'NOMBRE Y FIRMA SOLICITA',0,0,"C");
$pdf->Cell(95,10,'NOMBRE Y FIRMA DEL JEFE DEL AREA',0,0,"C");

$pdf->Ln();
$pdf->Ln();
$pdf->Cell(95,10,'________________________________',0,0,"C");
$pdf->Cell(95,10,'________________________________',0,0,"C");


$pdf->Ln();
$pdf->Ln();
$pdf->Ln();
}

$pdf->Output("FormatoVacaciones.pdf",'I');
ob_end_flush();
?>
