<?php 
include_once "../model/nom_incapacidades.php";
ob_start();
include('../components/fpdf/fpdf.php');

@$IncapacidadID = $_GET['IncapacidadID'];

$nom_incapacidades = new nom_incapacidades($IncapacidadID,"","","","","","","","");
$r = $nom_incapacidades->get_incapacidad();

foreach ($r as $d) {
	
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','',15);

if (file_exists($d['Comprobante']) /*|| (strlen($d['Comprobante'])!=0)*/ ) {	
$pdf->Image($d['Comprobante'],10,10,190,200,'JPG','');
}else{
$pdf->Cell(190,10,"No hay Archivo! :(",0,0,"C");	
/*$pdf->Image("../img/imagenes/foto_default.jpg",150,60,50,60,'JPG','');	*/
}
$pdf->Ln();
$pdf->Output("FormatoIncapacidad.pdf",'I');
ob_end_flush(); 
}
?>