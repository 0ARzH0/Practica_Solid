<?php 
include_once "conexion.php";

class seg_catpermisos{

var $PermisoID;
var $AgrupacionID;
var $UsuarioID;
var $AreaID;
var $DepartamentoID;

function seg_catpermisos($PermisoID,$AgrupacionID,$UsuarioID,$AreaID,$DepartamentoID){

$this->PermisoID=$PermisoID;
$this->AgrupacionID=$AgrupacionID;
$this->UsuarioID=$UsuarioID;
$this->AreaID=$AreaID;
$this->DepartamentoID=$DepartamentoID;

}
function get_permisos_user(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT DISTINCT AgrupacionID,AreaID,DepartamentoID FROM seg_catpermisos WHERE UsuarioID = '$this->UsuarioID'  ");
return $resp;
}
function add_permiso(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO seg_catpermisos (AgrupacionID,UsuarioID,AreaID,DepartamentoID) VALUES ('$this->AgrupacionID','$this->UsuarioID','$this->AreaID','$this->DepartamentoID') ");
return $resp; 
}
function val_permisos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM seg_catpermisos WHERE AgrupacionID='$this->AgrupacionID' AND UsuarioID = '$this->UsuarioID' AND AreaID = '$this->AreaID' AND DepartamentoID='$this->DepartamentoID' ");
return $resp;
}
function get_agrupacion_user(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT DISTINCT p.AgrupacionID,a.Agrupacion,u.Usuario FROM seg_catpermisos p
INNER JOIN  nom_catagrupaciones a ON p.AgrupacionID = a.AgrupacionID
INNER JOIN  seg_catusuarios u ON p.UsuarioID = u.UsuarioID
WHERE p.UsuarioID = '$this->UsuarioID' ");
return $resp;
}/*
function get_area_user(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT DISTINCT p.AreaID,a.Area,u.Usuario FROM seg_catpermisos p
INNER JOIN  nom_catareas a ON p.AreaID = a.AreaID
INNER JOIN  seg_catusuarios u ON p.UsuarioID = u.UsuarioID
WHERE p.UsuarioID = '$this->UsuarioID' ");
return $resp;
}
function get_depto_user(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT DISTINCT p.DepartamentoID,a.Departamento,u.Usuario FROM seg_catpermisos p
INNER JOIN  nom_catdepartamentos  a ON p.DepartamentoID = a.DepartamentoID
INNER JOIN  seg_catusuarios u ON p.UsuarioID = u.UsuarioID
WHERE p.UsuarioID = '$this->UsuarioID' ");
return $resp;
}*/
}


class grid_funciones{

var $AgrupacionID;
var $TipoNominaID;
var $UsuarioID;
var $AreaID;
var $DepartamentoID;
var $FechaInicial;
var $FechaFinal;
var $Movimiento;

function grid_funciones($AgrupacionID,$TipoNominaID,$UsuarioID,$AreaID,$DepartamentoID,$FechaInicial,$FechaFinal,$Movimiento){

$this->AgrupacionID=$AgrupacionID;
$this->TipoNominaID=$TipoNominaID;
$this->UsuarioID=$UsuarioID;
$this->AreaID=$AreaID;
$this->DepartamentoID=$DepartamentoID;
$this->FechaInicial=$FechaInicial;
$this->FechaFinal=$FechaFinal;
$this->Movimiento=$Movimiento;

}
function reporte_alta_baja(){

$conexion = new conexion();

$sql = "SELECT e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado, d.Departamento, a.Agrupacion,mo.Movimiento,mo.Fecha,ar.Area,pu.Puesto,pe.FechaInicial,pe.FechaFinal,n.TipoNomina

    FROM nom_catempleados e 

    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID

    INNER JOIN nom_catperiodos pe ON  e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1

    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID

    INNER JOIN nom_catagrupaciones a ON mp.AgrupacionID = a.AgrupacionID

    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID

    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID

    INNER JOIN nom_catpuestos pu ON mp.PuestoID =  pu.PuestoID 

    INNER JOIN nom_movpersonal mo ON e.Codigo = mo.Codigo

    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND mp.DepartamentoID = p.DepartamentoID AND p.UsuarioID = '$this->UsuarioID'      

    WHERE mo.Fecha BETWEEN '$this->FechaInicial' AND '$this->FechaFinal' AND mo.Movimiento LIKE '%$this->Movimiento%'";

    if($this->AgrupacionID > 0){ $sql = $sql." AND mp.AgrupacionID = '$this->AgrupacionID'"; }

    if($this->TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$this->TipoNominaID'"; }

    if($this->AreaID > 0){ $sql = $sql." AND mp.AreaID ='$this->AreaID'"; }

    if($this->DepartamentoID > 0){ $sql = $sql." AND mp.DepartamentoID = '$this->DepartamentoID'"; }

    $sql=$sql." ORDER BY ar.AreaID";

$resp = $conexion->ejecutarconsulta($sql);

return $resp;

}



function reporte_activo(){

$conexion = new conexion();

$sql = "SELECT e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado, d.Departamento, a.Agrupacion,e.FechaIngreso,ar.Area,pu.Puesto,n.TipoNomina

    FROM nom_catempleados e 

    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID

    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID

    INNER JOIN nom_catagrupaciones a ON mp.AgrupacionID = a.AgrupacionID

    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID

    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID

    INNER JOIN nom_catpuestos pu ON mp.PuestoID =  pu.PuestoID

    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND mp.DepartamentoID = p.DepartamentoID AND p.UsuarioID = '$this->UsuarioID'

    WHERE e.Estatus = 'A'";

    if($this->AgrupacionID > 0){ $sql = $sql." AND mp.AgrupacionID = '$this->AgrupacionID'"; }

    if($this->TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$this->TipoNominaID'"; }

    if($this->AreaID > 0){ $sql = $sql." AND mp.AreaID ='$this->AreaID'"; }

    if($this->DepartamentoID > 0){ $sql = $sql." AND mp.DepartamentoID = '$this->DepartamentoID'"; }

    $sql=$sql." ORDER BY ar.AreaID ASC,d.DepartamentoID ASC, e.Codigo ASC";

$resp = $conexion->ejecutarconsulta($sql);

return $resp;

}

function get_empleados_user(){
$conexion = new conexion();
$sql = "SELECT e.Codigo,p.AgrupacionID,a.Agrupacion,p.AreaID,e.EmpresaID, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado, p.DepartamentoID,d.Departamento,e.TipoNominaID,n.TipoNomina,pe.PeriodoID,pe.FechaInicial,pe.FechaFinal,pe.Ejercicio,pe.Bloqueado
    FROM nom_catempleados e 
    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID
    INNER JOIN nom_catperiodos pe ON  e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1
    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
    INNER JOIN nom_catagrupaciones a ON mp.AgrupacionID = a.AgrupacionID
    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND mp.DepartamentoID = p.DepartamentoID AND p.UsuarioID = '$this->UsuarioID'
    WHERE e.Estatus = 'A'";
    if($this->AgrupacionID > 0){ $sql = $sql." AND p.AgrupacionID = '$this->AgrupacionID'"; }
    if($this->TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$this->TipoNominaID'"; }
    if($this->AreaID > 0){ $sql = $sql." AND p.AreaID ='$this->AreaID'"; }
    if($this->DepartamentoID > 0){ $sql = $sql." AND p.DepartamentoID = '$this->DepartamentoID'"; }
$sql = $sql." ORDER BY mp.AreaID,Empleado ".$this->Movimiento;
$resp = $conexion->ejecutarconsulta($sql);
return $resp;
}
function formatoconcepto(){
$conexion = new conexion();
$sql = "SELECT e.CodigoNominaID,p.AgrupacionID,a.Agrupacion ,p.AreaID,e.EmpresaID, e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado, mp.DepartamentoID,d.Departamento, e.TipoNominaID, n.TipoNomina, ar.Area , pe.PeriodoID, pe.FechaInicial, pe.FechaFinal, pe.Ejercicio, co.ConceptoID, co.Concepto, dt.Importe, co.PercepcionDed, dt.Unidades, dt.Saldo
    FROM nom_catempleados e 
    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID
    INNER JOIN nom_catperiodos pe ON  e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1
    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
    INNER JOIN nom_catagrupaciones a ON mp.AgrupacionID = a.AgrupacionID
    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
    INNER JOIN nom_detmovnom dt ON e.Codigo = dt.Codigo AND dt.PeriodoID = pe.PeriodoID AND dt.Ejercicio = pe.Ejercicio
    INNER JOIN nom_catconceptos co ON dt.ConceptoID = co.ConceptoID
    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND mp.DepartamentoID = p.DepartamentoID AND p.UsuarioID = '$this->UsuarioID'
    WHERE e.Estatus = 'A' AND (dt.Importe <> 0 or dt.Unidades <> 0)";
if($this->AgrupacionID > 0){ $sql = $sql." AND mp.AgrupacionID = '$this->AgrupacionID'"; }
if($this->TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$this->TipoNominaID'"; }
if($this->AreaID > 0){ $sql = $sql." AND mp.AreaID ='$this->AreaID'"; }
if($this->DepartamentoID > 0){ $sql = $sql." AND mp.DepartamentoID = '$this->DepartamentoID'"; }
$sql = $sql." ORDER BY  mp.DepartamentoID, co.PercepcionDed,dt.ConceptoID,mp.AreaID, e.Codigo";
$resp = $conexion->ejecutarconsulta($sql);
return $resp;    
}
function formatoincapacidades(){
$conexion = new conexion();  
$sql = "SELECT  a.Agrupacion,ar.Area,e.Imss, e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado,i.SerieFolio,i.DiasAutorizados,i.ApartirDel, DATE_ADD(i.ApartirDel, INTERVAL i.DiasAutorizados-'1' DAY) AS FechaFin,i.RamoSeguro
    FROM nom_incapacidades i  
    INNER JOIN nom_catempleados e ON i.Codigo = e.Codigo
    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID
    INNER JOIN nom_catperiodos pe ON e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1
    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
    INNER JOIN nom_catagrupaciones a ON a.AgrupacionID = mp.AgrupacionID
    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
    INNER JOIN nom_catpuestos pu ON mp.PuestoID =  pu.PuestoID   
    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND mp.DepartamentoID = p.DepartamentoID AND p.UsuarioID = '$this->UsuarioID'
    WHERE i.ApartirDel BETWEEN '$this->FechaInicial' AND '$this->FechaFinal' OR DATE_ADD(i.ApartirDel, INTERVAL i.DiasAutorizados-'1' DAY) BETWEEN '$this->FechaInicial' AND '$this->FechaFinal' ";
if($this->AgrupacionID > 0){ $sql = $sql." AND mp.AgrupacionID = '$this->AgrupacionID'"; }
if($this->TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$this->TipoNominaID'"; }
if($this->AreaID > 0){ $sql = $sql." AND mp.AreaID ='$this->AreaID'"; }
if($this->DepartamentoID > 0){ $sql = $sql." AND mp.DepartamentoID = '$this->DepartamentoID'"; }
$sql = $sql." ORDER BY  mp.DepartamentoID,mp.AreaID, e.Codigo";
$resp = $conexion->ejecutarconsulta($sql);
return $resp;   
}
function formatovacaciones(){
$conexion = new conexion();  
$sql = "SELECT  a.Agrupacion,ar.Area, e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado,v.FechaSolicitud,v.NumeroDias,v.FechaInicio,v.FechaTermino,v.FechaRegreso
    FROM nom_vacaciones v  
    INNER JOIN nom_catempleados e ON v.Codigo = e.Codigo
    INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID
    INNER JOIN nom_catperiodos pe ON e.TipoNominaID = pe.TipoNominaID AND pe.Actual = 1
    INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
    INNER JOIN nom_catagrupaciones a ON a.AgrupacionID = mp.AgrupacionID
    INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
    INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
    INNER JOIN nom_catpuestos pu ON mp.PuestoID =  pu.PuestoID   
    INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND mp.AreaID = p.AreaID AND mp.DepartamentoID = p.DepartamentoID AND p.UsuarioID = '$this->UsuarioID'
    WHERE v.FechaInicio BETWEEN '$this->FechaInicial' AND '$this->FechaFinal' OR v.FechaTermino BETWEEN '$this->FechaInicial' AND '$this->FechaFinal'";
if($this->AgrupacionID > 0){ $sql = $sql." AND mp.AgrupacionID = '$this->AgrupacionID'"; }
if($this->TipoNominaID > 0){ $sql = $sql." AND e.TipoNominaID ='$this->TipoNominaID'"; }
if($this->AreaID > 0){ $sql = $sql." AND mp.AreaID ='$this->AreaID'"; }
if($this->DepartamentoID > 0){ $sql = $sql." AND mp.DepartamentoID = '$this->DepartamentoID'"; }
$sql = $sql." ORDER BY  mp.DepartamentoID,mp.AreaID, e.Codigo";
$resp = $conexion->ejecutarconsulta($sql);
return $resp;      
}
}

?>