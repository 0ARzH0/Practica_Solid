<?php

include_once 'conexion.php';

class nom_catperiodos{

var $TipoNominaID;
var $PeriodoID;
var $Ejercicio;
var $Actual;
var $Cerrado;
var $FechaInicial;
var $FechaFinal;
var $Domingos;
var $Mes;
var $InicioMes;
var $FinMes;
var $InicioEjercicio;
var $FinEjercicio;
var $FechaContable;
var $Desface;
var $Sobres;
var $Timbrado;
var $Bloqueado;

function nom_catperiodos($TipoNominaID,$PeriodoID,$Ejercicio,$Actual,$Cerrado,$FechaInicial,$FechaFinal,$Domingos,$Mes,$InicioMes,$FinMes,$InicioEjercicio,$FinEjercicio,$FechaContable,$Desface,$Sobres,$Timbrado,$Bloqueado){

$this->TipoNominaID=$TipoNominaID;
$this->PeriodoID=$PeriodoID;
$this->Ejercicio=$Ejercicio;
$this->Actual=$Actual;
$this->Cerrado=$Cerrado;
$this->FechaInicial=$FechaInicial;
$this->FechaFinal=$FechaFinal;
$this->Domingos=$Domingos;
$this->Mes=$Mes;
$this->InicioMes=$InicioMes;
$this->FinMes=$FinMes;
$this->InicioEjercicio=$InicioEjercicio;
$this->FinEjercicio=$FinEjercicio;
$this->FechaContable=$FechaContable;
$this->Desface=$Desface;
$this->Sobres=$Sobres;
$this->Timbrado=$Timbrado;
$this->Bloqueado=$Bloqueado;

}
function get_ejercicio(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catperiodos WHERE TipoNominaID = '$this->TipoNominaID' AND  Actual = '$this->Actual'");
return $resp;
}
function show_nom_catperiodos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catperiodos");
return $resp;
}
function add_nom_catperiodos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catperiodos (TipoNominaID,PeriodoID,Ejercicio,Actual,Cerrado,FechaInicial,FechaFinal,Domingos,Mes,InicioMes,FinMes,InicioEjercicio,FinEjercicio,FechaContable,Desface,Sobres,Timbrado,Bloqueado) VALUES ('$this->TipoNominaID' ,'$this->PeriodoID' ,'$this->Ejercicio' ,'$this->Actual' ,'$this->Cerrado' ,'$this->FechaInicial' ,'$this->FechaFinal' ,'$this->Domingos' ,'$this->Mes' ,'$this->InicioMes' ,'$this->FinMes' ,'$this->InicioEjercicio' ,'$this->FinEjercicio' ,'$this->FechaContable' ,'$this->Desface' ,'$this->Sobres' ,'$this->Timbrado' ,'$this->Bloqueado') ");
return $resp;
}
function mod_nom_catperiodos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catperiodos SET TipoNominaID='$this->TipoNominaID', PeriodoID='$this->PeriodoID', Ejercicio='$this->Ejercicio', Actual='$this->Actual', Cerrado='$this->Cerrado', FechaInicial='$this->FechaInicial', FechaFinal='$this->FechaFinal', Domingos='$this->Domingos', Mes='$this->Mes', InicioMes='$this->InicioMes', FinMes='$this->FinMes', InicioEjercicio='$this->InicioEjercicio', FinEjercicio='$this->FinEjercicio', FechaContable='$this->FechaContable', Desface='$this->Desface', Sobres='$this->Sobres', Timbrado='$this->Timbrado', Bloqueado='$this->Bloqueado'  WHERE TipoNominaID = '$this->TipoNominaID'");
return $resp;
}
function del_nom_catperiodos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catperiodos WHERE TipoNominaID = '$this->TipoNominaID' ");
return $resp;
}
}
?>
