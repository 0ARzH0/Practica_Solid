<?php

include_once 'conexion.php';

class nom_bajas{

var $BajaID;
var $Codigo;
var $FechaAlta;
var $FechaBaja;
var $Motivo;
var $MotivoBaja;

function nom_bajas($BajaID,$Codigo,$FechaAlta,$FechaBaja,$Motivo,$MotivoBaja){

$this->BajaID=$BajaID;
$this->Codigo=$Codigo;
$this->FechaAlta=$FechaAlta;
$this->FechaBaja=$FechaBaja;
$this->Motivo=$Motivo;
$this->MotivoBaja=$MotivoBaja;

}
function get_bajas_empl(){
	$conexion = new conexion();
	$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_bajas WHERE Codigo='$this->Codigo'");
	return $resp;
}
function show_nom_bajas(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_bajas");
return $resp;
}
function add_bajas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_bajas (Codigo,FechaAlta,FechaBaja,Motivo,MotivoBaja) VALUES ('$this->Codigo' ,'$this->FechaAlta' ,'$this->FechaBaja' ,'$this->Motivo' ,'$this->MotivoBaja' ) ");
return $resp;
}
function mod_nom_bajas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_bajas SET BajaID='$this->BajaID', Codigo='$this->Codigo', FechaAlta='$this->FechaAlta', FechaBaja='$this->FechaBaja', Motivo='$this->Motivo', MotivoBaja='$this->MotivoBaja'   WHERE BajaID = '$this->BajaID'");
return $resp;
}
function del_nom_bajas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_bajas WHERE BajaID = '$this->BajaID' ");
return $resp;
}
}
?>
