<?php 

include_once "conexion.php";

class vistas{

var $UsuarioID;
var $AgrupacionID;
var $Agrupacion;
var $AreaID;
var $Area;
var $DepartamentoID;
var $Departamento;

function vistas($UsuarioID,$AgrupacionID,$Agrupacion,$AreaID,$Area,$DepartamentoID,$Departamento){

$this->UsuarioID=$UsuarioID;
$this->AgrupacionID=$AgrupacionID;
$this->Agrupacion=$Agrupacion;
$this->AreaID=$AreaID;
$this->Area=$Area;
$this->DepartamentoID=$DepartamentoID;
$this->Departamento=$Departamento;

}
function get_agrupaciones_user(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM vw_filtroagrupacionesporusuario WHERE UsuarioID = '$this->UsuarioID' ");
return $resp;
}
function get_areaxagrup_user(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM vw_filtroareasporusuario WHERE UsuarioID = '$this->UsuarioID' AND AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
function get_deptoxarea_user(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM vw_filtrodepartamentosporusuario WHERE UsuarioID = '$this->UsuarioID' AND AgrupacionID = '$this->AgrupacionID' AND AreaID = '$this->AreaID' ");
return $resp;
}
function get_departamentos_user(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM vw_filtrodepartamentosporusuario WHERE UsuarioID = '$this->UsuarioID' ");
return $resp;
}
function get_areas_user(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM vw_filtroareasporusuario WHERE UsuarioID = '$this->UsuarioID' ");
return $resp;
}
function bus_areasporagrup(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT DISTINCT Area,AreaID FROM vw_filtroareasporusuario WHERE  AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
function bus_deptoporagrup(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT DISTINCT Departamento,DepartamentoID FROM vw_filtrodepartamentosporusuario WHERE  AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
function get_conceptos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT cp.ConceptoID,cn.Concepto,cn.Importe,cn.Unidades,cn.Saldos,cp.Ordenacion
	FROM nom_captura cp INNER JOIN nom_catconceptos cn ON cp.ConceptoID = cn.ConceptoID 
	WHERE cp.AgrupacionID = '$this->AgrupacionID' AND cp.AreaID = '$this->AreaID' ORDER BY cp.Ordenacion");
return $resp;
}
}
?>