<?php

include_once 'conexion.php';

class nom_vacaciones{

var $SolicitudID;
var $Codigo;
var $FechaSolicitud;
var $NumeroDias;
var $FechaInicio;
var $FechaTermino;
var $FechaRegreso;
var $Observaciones;
var $ImgFormato;
var $Cancelado;

function nom_vacaciones($SolicitudID,$Codigo,$FechaSolicitud,$NumeroDias,$FechaInicio,$FechaTermino,$FechaRegreso,$Observaciones,$ImgFormato,$Cancelado){

$this->SolicitudID=$SolicitudID;
$this->Codigo=$Codigo;
$this->FechaSolicitud=$FechaSolicitud;
$this->NumeroDias=$NumeroDias;
$this->FechaInicio=$FechaInicio;
$this->FechaTermino=$FechaTermino;
$this->FechaRegreso=$FechaRegreso;
$this->Observaciones=$Observaciones;
$this->ImgFormato=$ImgFormato;
$this->Cancelado=$Cancelado;

}
function get_vac_goz(){
$conexion=new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM nom_vacaciones WHERE Codigo = '$this->Codigo' AND Cancelado = '$this->Cancelado'");
return $resp;
}
function add_vacaciones(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_vacaciones (Codigo,FechaSolicitud,NumeroDias,FechaInicio,FechaTermino,FechaRegreso,Observaciones,ImgFormato,Cancelado) VALUES ('$this->Codigo' ,'$this->FechaSolicitud' ,'$this->NumeroDias' ,'$this->FechaInicio' ,'$this->FechaTermino' ,'$this->FechaRegreso' ,'$this->Observaciones' ,'$this->ImgFormato' ,'$this->Cancelado' ) ");
return $resp;
}
function get_vac_empl(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_vacaciones WHERE Codigo ='$this->Codigo' ");
return $resp;
}
function get_vac_empl_sol(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT v.*,e.Telefono,CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado,a.Area,d.Departamento,p.Puesto FROM nom_vacaciones v 
INNER JOIN nom_catempleados e ON v.Codigo = e.Codigo
INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID
INNER JOIN nom_catareas a ON mp.AreaID = a.AreaID
INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID
INNER JOIN nom_catpuestos p ON mp.PuestoID = p.PuestoID
WHERE v.SolicitudID ='$this->SolicitudID' ");
return $resp;
}
function add_imgformato(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_vacaciones SET ImgFormato='$this->ImgFormato' WHERE SolicitudID = '$this->SolicitudID'");
return $resp;
}
/*function mod_nom_vacaciones(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_vacaciones SET SolicitudID='$this->SolicitudID', Codigo='$this->Codigo', FechaSolicitud='$this->FechaSolicitud', NumeroDias='$this->NumeroDias', FechaInicio='$this->FechaInicio', FechaTermino='$this->FechaTermino', FechaRegreso='$this->FechaRegreso', Observaciones='$this->Observaciones', ImgFormato='$this->ImgFormato', Cancelado='$this->Cancelado'   WHERE SolicitudID = '$this->SolicitudID'");
return $resp;
}
function del_nom_vacaciones(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_vacaciones WHERE SolicitudID = '$this->SolicitudID' ");
return $resp;
}*/
}
?>
