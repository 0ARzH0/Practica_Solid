<?php

include_once 'conexion.php';

class nom_detmovnom{

var $detmov_id;
var $Codigo;
var $ConceptoID;
var $TipoNominaID;
var $PeriodoID;
var $Ejercicio;
var $Unidades;
var $Importe;
var $Saldo;
var $Ajuste;
var $Parametro1;
var $Parametro2;
var $IngresoDeduc;
var $ImporteAnterior;
var $fechamov;
var $Aprobado;
var $AprobadoUsuarioID;

function nom_detmovnom($detmov_id,$Codigo,$ConceptoID,$TipoNominaID,$PeriodoID,$Ejercicio,$Unidades,$Importe,$Saldo,$Ajuste,$Parametro1,$Parametro2,$IngresoDeduc,$ImporteAnterior,$fechamov,$Aprobado,$AprobadoUsuarioID){

$this->detmov_id=$detmov_id;
$this->Codigo=$Codigo;
$this->ConceptoID=$ConceptoID;
$this->TipoNominaID=$TipoNominaID;
$this->PeriodoID=$PeriodoID;
$this->Ejercicio=$Ejercicio;
$this->Unidades=$Unidades;
$this->Importe=$Importe;
$this->Saldo=$Saldo;
$this->Ajuste=$Ajuste;
$this->Parametro1=$Parametro1;
$this->Parametro2=$Parametro2;
$this->IngresoDeduc=$IngresoDeduc;
$this->ImporteAnterior=$ImporteAnterior;
$this->fechamov=$fechamov;
$this->Aprobado=$Aprobado;
$this->AprobadoUsuarioID=$AprobadoUsuarioID;

}
function ver_ultimos_10(){
	$conexion = new conexion();
	$resp = $conexion->ejecutarconsulta('SELECT * FROM nom_detmovnom ORDER BY fechamov DESC LIMIT 10');
	return $resp;
}
function get_concepto_empl_uni(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_detmovnom WHERE Codigo='$this->Codigo' AND ConceptoID='$this->ConceptoID' AND TipoNominaID = '$this->TipoNominaID' AND PeriodoID='$this->PeriodoID' ");
return $resp;
}
function get_concepto_empl(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT d.detmov_id,d.ConceptoID,c.Concepto,d.Unidades,d.Importe,d.Saldo,d.Aprobado 
	FROM nom_detmovnom d 
	INNER JOIN nom_catconceptos c ON d.ConceptoID = c.ConceptoID
	WHERE d.Codigo='$this->Codigo' AND d.TipoNominaID = '$this->TipoNominaID' AND d.PeriodoID='$this->PeriodoID' ");
return $resp;
}
function add_movimiento_conc(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_detmovnom (Codigo,ConceptoID,TipoNominaID,PeriodoID,Ejercicio,Unidades,Importe,Saldo,fechamov) VALUES('$this->Codigo','$this->ConceptoID','$this->TipoNominaID','$this->PeriodoID','$this->Ejercicio','$this->Unidades','$this->Importe','$this->Saldo','$this->fechamov')");
return $resp;	
}
function mod_movimiento_conc(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_detmovnom SET  Unidades='$this->Unidades',Importe='$this->Importe' WHERE Codigo='$this->Codigo' AND ConceptoID='$this->ConceptoID' AND TipoNominaID = '$this->TipoNominaID' AND PeriodoID='$this->PeriodoID' AND Ejercicio='$this->Ejercicio' ");
return $resp;	
}
function det_concepto_empl_uni(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_detmovnom WHERE detmov_id = '$this->detmov_id' ");
return $resp;
}
function mod_movimiento_conc_aprob(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_detmovnom SET  Unidades='$this->Unidades',Importe='$this->Importe',Aprobado='$this->Aprobado' WHERE detmov_id='$this->detmov_id'");
return $resp;	
}
function add_movimiento_conc_aprob(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_detmovnom (Codigo,ConceptoID,TipoNominaID,PeriodoID,Ejercicio,Unidades,Importe,Saldo,fechamov,Aprobado,AprobadoUsuarioID) VALUES('$this->Codigo','$this->ConceptoID','$this->TipoNominaID','$this->PeriodoID','$this->Ejercicio','$this->Unidades','$this->Importe','$this->Saldo','$this->fechamov','$this->Aprobado','$this->AprobadoUsuarioID')");
return $resp;	
}
/*function show_nom_detmovnom(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_detmovnom");
return $resp;
}
function add_nom_detmovnom(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_detmovnom (detmov_id,Codigo,ConceptoID,TipoNominaID,PeriodoID,Ejercicio,Unidades,Importe,Saldo,Ajuste,Parametro1,Parametro2,IngresoDeduc,ImporteAnterior,fechamov,Aprobado,AprobadoUsuarioID) VALUES ('$this->detmov_id' ,'$this->Codigo' ,'$this->ConceptoID' ,'$this->TipoNominaID' ,'$this->PeriodoID' ,'$this->Ejercicio' ,'$this->Unidades' ,'$this->Importe' ,'$this->Saldo' ,'$this->Ajuste' ,'$this->Parametro1' ,'$this->Parametro2' ,'$this->IngresoDeduc' ,'$this->ImporteAnterior' ,'$this->fechamov' ,'$this->Aprobado' ,'$this->AprobadoUsuarioID') ");
return $resp;
}
function mod_nom_detmovnom(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_detmovnom SET detmov_id='$this->detmov_id', Codigo='$this->Codigo', ConceptoID='$this->ConceptoID', TipoNominaID='$this->TipoNominaID', PeriodoID='$this->PeriodoID', Ejercicio='$this->Ejercicio', Unidades='$this->Unidades', Importe='$this->Importe', Saldo='$this->Saldo', Ajuste='$this->Ajuste', Parametro1='$this->Parametro1', Parametro2='$this->Parametro2', IngresoDeduc='$this->IngresoDeduc', ImporteAnterior='$this->ImporteAnterior', fechamov='$this->fechamov', Aprobado='$this->Aprobado', AprobadoUsuarioID='$this->AprobadoUsuarioID'   WHERE detmov_id = '$this->detmov_id'");
return $resp;
}
*/
}
?>
