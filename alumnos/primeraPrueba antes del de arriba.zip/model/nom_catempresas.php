<?php 

include_once "conexion.php";

class nom_catempresas{

var $EmpresaID;
var $Empresa;
var $RFC;
var $Curp;
var $Direccion;
var $Colonia;
var $Ubicacion;
var $CodigoPostal;
var $Telefono;
var $Email;
var $Representante;
var $RfcRepresentante;
var $CurpRepresentante;
var $GiroEmpresa;
var $MascaraCuenta;
var $Creo;
var $FechaCreacion;
var $Modifico;
var $FechaModifico;
var $NomCorto;
var $Logotipo;
var $ArchivoMovtos;
var $HojasxPagina;
var $RegistrosxSobre;
var $ReporteSobres;
var $Estado;
var $Municipio;
var $Localidad;
var $NumInterior;
var $NumExterior;
var $Calle;
var $Regimen;
var $Cruzamiento1;
var $Cruzamiento2;
var $NoCertificado;
var $ws;
var $wsUsuario;
var $wsPassword;
var $Serie;
var $RutaXML;
var $Certificado;
var $keyCertificado;
var $cerPassword;

function nom_catempresas($EmpresaID,$Empresa,$RFC,$Curp,$Direccion,$Colonia,$Ubicacion,$CodigoPostal,$Telefono,$Email,$Representante,$RfcRepresentante,$CurpRepresentante,$GiroEmpresa,$MascaraCuenta,$Creo,$FechaCreacion,$Modifico,$FechaModifico,$NomCorto,$Logotipo,$ArchivoMovtos,$HojasxPagina,$RegistrosxSobre,$ReporteSobres,$Estado,$Municipio,$Localidad,$NumInterior,$NumExterior,$Calle,$Regimen,$Cruzamiento1,$Cruzamiento2,$NoCertificado,$ws,$wsUsuario,$wsPassword,$Serie,$RutaXML,$Certificado,$keyCertificado,$cerPassword){

$this->EmpresaID=$EmpresaID;
$this->Empresa=$Empresa;
$this->RFC=$RFC;
$this->Curp=$Curp;
$this->Direccion=$Direccion;
$this->Colonia=$Colonia;
$this->Ubicacion=$Ubicacion;
$this->CodigoPostal=$CodigoPostal;
$this->Telefono=$Telefono;
$this->Email=$Email;
$this->Representante=$Representante;
$this->RfcRepresentante=$RfcRepresentante;
$this->CurpRepresentante=$CurpRepresentante;
$this->GiroEmpresa=$GiroEmpresa;
$this->MascaraCuenta=$MascaraCuenta;
$this->Creo=$Creo;
$this->FechaCreacion=$FechaCreacion;
$this->Modifico=$Modifico;
$this->FechaModifico=$FechaModifico;
$this->NomCorto=$NomCorto;
$this->Logotipo=$Logotipo;
$this->ArchivoMovtos=$ArchivoMovtos;
$this->HojasxPagina=$HojasxPagina;
$this->RegistrosxSobre=$RegistrosxSobre;
$this->ReporteSobres=$ReporteSobres;
$this->Estado=$Estado;
$this->Municipio=$Municipio;
$this->Localidad=$Localidad;
$this->NumInterior=$NumInterior;
$this->NumExterior=$NumExterior;
$this->Calle=$Calle;
$this->Regimen=$Regimen;
$this->Cruzamiento1=$Cruzamiento1;
$this->Cruzamiento2=$Cruzamiento2;
$this->NoCertificado=$NoCertificado;
$this->ws=$ws;
$this->wsUsuario=$wsUsuario;
$this->wsPassword=$wsPassword;
$this->Serie=$Serie;
$this->RutaXML=$RutaXML;
$this->Certificado=$Certificado;
$this->keyCertificado=$keyCertificado;
$this->cerPassword=$cerPassword;
}

function get_empresa(){ 
	$conexion = new conexion();
	$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catempresas WHERE EmpresaID = '$this->EmpresaID' ");
	return $resp;
}

function crea_empresa(){
	$conexion= new conexion();
	$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catempresas (EmpresaID, Empresa, RFC, Curp, Direccion, Colonia, Ubicacion, CodigoPostal, Telefono, Email, Representante, RfcRepresentante, CurpRepresentante, GiroEmpresa, MascaraCuenta, Creo, FechaCreacion, Modifico, FechaModifico, NomCorto, Logotipo, ArchivoMovtos, HojasxPagina, RegistrosxSobre, ReporteSobres, Estado, Municipio, Localidad, NumInterior, NumExterior, Calle, Regimen, Cruzamiento1, Cruzamiento2, NoCertificado, ws, wsUsuario, wsPassword, Serie, RutaXML, Certificado, keyCertificado, cerPassword) VALUES ('$this->EmpresaID','$this->Empresa','$this->RFC','$this->Curp', '$this->Direccion', '$this->Colonia', '$this->Ubicacion', '$this->CodigoPostal', '$this->Telefono', '$this->Email', '$this->Representante', '$this->RfcRepresentante', '$this->CurpRepresentante', '$this->GiroEmpresa', '$this->MascaraCuenta', '$this->Creo', '$this->FechaCreacion', '$this->Modifico', '$this->FechaModifico', '$this->NomCorto', '$this->Logotipo', '$this->ArchivoMovtos', '$this->HojasxPagina', '$this->RegistrosxSobre', '$this->ReporteSobres', '$this->Estado', '$this->Municipio', '$this->Localidad', '$this->NumInterior', '$this->NumExterior', '$this->Calle', '$this->Regimen', '$this->Cruzamiento1', '$this->Cruzamiento2', '$this->NoCertificado', '$this->ws', '$this->wsUsuario', '$this->wsPassword', '$this->Serie', '$this->RutaXML', '$this->Certificado', '$this->keyCertificado', '$this->cerPassword')");
	return $resp;
}

function show_empresas(){
	$conexion= new conexion();
	$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catempresas");
	return $resp;
}

}
?>
