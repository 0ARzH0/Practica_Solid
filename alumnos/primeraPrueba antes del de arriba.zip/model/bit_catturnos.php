<?php

include_once 'conexion.php';

class bit_catturnos{

var $TurnoID;
var $AgrupacionID;
var $Turno;
var $TurnoCortado;
var $RotaTurnoID;
var $TraslapaTurno;
var $UsuarioID;
var $FechaCreo;
var $UsuarioModID;
var $FechaMod;
var $Tolerancia;

function bit_catturnos($TurnoID,$AgrupacionID,$Turno,$TurnoCortado,$RotaTurnoID,$TraslapaTurno,$UsuarioID,$FechaCreo,$UsuarioModID,$FechaMod,$Tolerancia){

$this->TurnoID=$TurnoID;
$this->AgrupacionID=$AgrupacionID;
$this->Turno=$Turno;
$this->TurnoCortado=$TurnoCortado;
$this->RotaTurnoID=$RotaTurnoID;
$this->TraslapaTurno=$TraslapaTurno;
$this->UsuarioID=$UsuarioID;
$this->FechaCreo=$FechaCreo;
$this->UsuarioModID=$UsuarioModID;
$this->FechaMod=$FechaMod;
$this->Tolerancia=$Tolerancia;

}
function get_turnos_agr(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM bit_catturnos WHERE AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
function get_ult_turnoid(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM bit_catturnos ORDER BY TurnoID DESC LIMIT 1");
return $resp;
}
function show_turnos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM bit_catturnos");
return $resp;
}
function add_catturnos(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO bit_catturnos (AgrupacionID,Turno,TurnoCortado,RotaTurnoID,TraslapaTurno,UsuarioID,FechaCreo,UsuarioModID,FechaMod,Tolerancia) VALUES ('$this->AgrupacionID' ,'$this->Turno' ,'$this->TurnoCortado' ,'$this->RotaTurnoID' ,'$this->TraslapaTurno' ,'$this->UsuarioID' ,'$this->FechaCreo' ,'$this->UsuarioModID' ,'$this->FechaMod' ,'$this->Tolerancia') ");
return $resp;
}
function mod_bit_catturnos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE bit_catturnos SET TurnoID='$this->TurnoID', AgrupacionID='$this->AgrupacionID', Turno='$this->Turno', TurnoCortado='$this->TurnoCortado', RotaTurnoID='$this->RotaTurnoID', TraslapaTurno='$this->TraslapaTurno', UsuarioID='$this->UsuarioID', FechaCreo='$this->FechaCreo', UsuarioModID='$this->UsuarioModID', FechaMod='$this->FechaMod', Tolerancia='$this->Tolerancia'  WHERE TurnoID = '$this->TurnoID'");
return $resp;
}
function del_bit_catturnos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM bit_catturnos WHERE TurnoID = '$this->TurnoID' ");
return $resp;
}
}
?>
