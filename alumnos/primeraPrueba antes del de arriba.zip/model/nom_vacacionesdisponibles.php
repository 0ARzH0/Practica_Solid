<?php

include_once 'conexion.php';

class nom_vacacionesdisponibles{

var $RegistroVacID;
var $Codigo;
var $CantidadDisponible;
var $UltimoAnio;
var $VacacionesPorGozar;
var $VacacionesGozadas;

function nom_vacacionesdisponibles($RegistroVacID,$Codigo,$CantidadDisponible,$UltimoAnio,$VacacionesPorGozar,$VacacionesGozadas){

$this->RegistroVacID=$RegistroVacID;
$this->Codigo=$Codigo;
$this->CantidadDisponible=$CantidadDisponible;
$this->UltimoAnio=$UltimoAnio;
$this->VacacionesPorGozar=$VacacionesPorGozar;
$this->VacacionesGozadas=$VacacionesGozadas;

}

function show_nom_vacacionesdisponibles(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_vacacionesdisponibles");
return $resp;
}
function get_vacacionesdisponibles_empl(){
$conexion = new conexion();
$resp=$conexion->ejecutarconsulta("SELECT * FROM nom_vacacionesdisponibles WHERE Codigo='$this->Codigo' ORDER BY RegistroVacID DESC LIMIT 1");
return $resp;
}
function add_nom_vacacionesdisponibles(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_vacacionesdisponibles (RegistroVacID,Codigo,CantidadDisponible,UltimoAnio,VacacionesPorGozar,VacacionesGozadas,RegistroVacID,Codigo,Codigo) VALUES ('$this->RegistroVacID' ,'$this->Codigo' ,'$this->CantidadDisponible' ,'$this->UltimoAnio' ,'$this->VacacionesPorGozar' ,'$this->VacacionesGozadas') ");
return $resp;
}
function mod_nom_vacacionesdisponibles(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_vacacionesdisponibles SET RegistroVacID='$this->RegistroVacID', Codigo='$this->Codigo', CantidadDisponible='$this->CantidadDisponible', UltimoAnio='$this->UltimoAnio', VacacionesPorGozar='$this->VacacionesPorGozar', VacacionesGozadas='$this->VacacionesGozadas' ");
return $resp;
}
function del_nom_vacacionesdisponibles(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_vacacionesdisponibles WHERE RegistroVacID = '$this->RegistroVacID' ");
return $resp;
}
}
?>
