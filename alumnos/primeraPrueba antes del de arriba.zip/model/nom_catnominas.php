<?php

include_once 'conexion.php';

class nom_catnominas{

var $TipoNominaID;
var $TipoNomina;

function nom_catnominas($TipoNominaID,$TipoNomina){

$this->TipoNominaID=$TipoNominaID;
$this->TipoNomina=$TipoNomina;

}
function get_tiponomina(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catnominas WHERE TipoNominaID='$this->TipoNominaID' ");
return $resp;
}
function show_catnominas(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catnominas");
return $resp;
}
function add_nom_catnominas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catnominas (TipoNominaID,TipoNomina) VALUES ('$this->TipoNominaID' ,'$this->TipoNomina' ) ");
return $resp;
}
function mod_nom_catnominas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catnominas SET TipoNominaID='$this->TipoNominaID', TipoNomina='$this->TipoNomina'   WHERE TipoNominaID = '$this->TipoNominaID'");
return $resp;
}
function del_nom_catnominas(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catnominas WHERE TipoNominaID = '$this->TipoNominaID' ");
return $resp;
}
}
?>
