<?php

include_once 'conexion.php';

class nom_catagrupaciones{

var $AgrupacionID;
var $Agrupacion;
var $RFC;
var $Comision;
var $SegmentoNegocios;
var $CostoSocial;
var $Creo;
var $FechaCreo;
var $Modifico;
var $FechaModifico;
var $NombreCorto;
var $EmpresaContratoID;
var $SDI_Antig;
var $SDI_Inicial;
var $ClienteFacID;
var $SubsidioEmpleo;
var $FormaCobranza;

function nom_catagrupaciones($AgrupacionID,$Agrupacion,$RFC,$Comision,$SegmentoNegocios,$CostoSocial,$Creo,$FechaCreo,$Modifico,$FechaModifico,$NombreCorto,$EmpresaContratoID,$SDI_Antig,$SDI_Inicial,$ClienteFacID,$SubsidioEmpleo,$FormaCobranza){

$this->AgrupacionID=$AgrupacionID;
$this->Agrupacion=$Agrupacion;
$this->RFC=$RFC;
$this->Comision=$Comision;
$this->SegmentoNegocios=$SegmentoNegocios;
$this->CostoSocial=$CostoSocial;
$this->Creo=$Creo;
$this->FechaCreo=$FechaCreo;
$this->Modifico=$Modifico;
$this->FechaModifico=$FechaModifico;
$this->NombreCorto=$NombreCorto;
$this->EmpresaContratoID=$EmpresaContratoID;
$this->SDI_Antig=$SDI_Antig;
$this->SDI_Inicial=$SDI_Inicial;
$this->ClienteFacID=$ClienteFacID;
$this->SubsidioEmpleo=$SubsidioEmpleo;
$this->FormaCobranza=$FormaCobranza;

}
function bus_agrupaciones(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catagrupaciones WHERE Agrupacion LIKE '%$this->Agrupacion%'");
return $resp;
}
function get_agrupacion(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catagrupaciones WHERE AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
function show_nom_catagrupaciones(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_catagrupaciones");
return $resp;
}
function add_nom_catagrupaciones(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_catagrupaciones (AgrupacionID,Agrupacion,RFC,Comision,SegmentoNegocios,CostoSocial,Creo,FechaCreo,Modifico,FechaModifico,NombreCorto,EmpresaContratoID,SDI_Antig,SDI_Inicial,ClienteFacID,SubsidioEmpleo,FormaCobranza) VALUES ('$this->AgrupacionID' ,'$this->Agrupacion' ,'$this->RFC' ,'$this->Comision' ,'$this->SegmentoNegocios' ,'$this->CostoSocial' ,'$this->Creo' ,'$this->FechaCreo' ,'$this->Modifico' ,'$this->FechaModifico' ,'$this->NombreCorto' ,'$this->EmpresaContratoID' ,'$this->SDI_Antig' ,'$this->SDI_Inicial' ,'$this->ClienteFacID' ,'$this->SubsidioEmpleo' ,'$this->FormaCobranza' ) ");
return $resp;
}
function mod_nom_catagrupaciones(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_catagrupaciones SET AgrupacionID='$this->AgrupacionID', Agrupacion='$this->Agrupacion', RFC='$this->RFC', Comision='$this->Comision', SegmentoNegocios='$this->SegmentoNegocios', CostoSocial='$this->CostoSocial', Creo='$this->Creo', FechaCreo='$this->FechaCreo', Modifico='$this->Modifico', FechaModifico='$this->FechaModifico', NombreCorto='$this->NombreCorto', EmpresaContratoID='$this->EmpresaContratoID', SDI_Antig='$this->SDI_Antig', SDI_Inicial='$this->SDI_Inicial', ClienteFacID='$this->ClienteFacID', SubsidioEmpleo='$this->SubsidioEmpleo', FormaCobranza='$this->FormaCobranza'   WHERE AgrupacionID = '$this->AgrupacionID'");
return $resp;
}
function del_nom_catagrupaciones(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_catagrupaciones WHERE AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
}
?>
