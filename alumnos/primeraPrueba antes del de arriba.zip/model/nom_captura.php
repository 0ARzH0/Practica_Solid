<?php

include_once 'conexion.php';

class nom_captura{

var $AgrupacionID;
var $AreaID;
var $ConceptoID;
var $Ordenacion;

function nom_captura($AgrupacionID,$AreaID,$ConceptoID,$Ordenacion){

$this->AgrupacionID=$AgrupacionID;
$this->AreaID=$AreaID;
$this->ConceptoID=$ConceptoID;
$this->Ordenacion=$Ordenacion;

}
function add_concepto(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_captura (AgrupacionID,AreaID,ConceptoID,Ordenacion) VALUES('$this->AgrupacionID','$this->AreaID','$this->ConceptoID','$this->Ordenacion')");
return $resp;	
}
function get_conceptos(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT DISTINCT cp.ConceptoID,cn.Concepto,cn.Importe,cn.Unidades,cn.Saldos
	FROM nom_captura cp INNER JOIN nom_catconceptos cn ON cp.ConceptoID = cn.ConceptoID 
	WHERE cp.AgrupacionID = '$this->AgrupacionID' AND cp.AreaID = '$this->AreaID' ");
return $resp;
}
function show_nom_captura(){
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("SELECT * FROM nom_captura");
return $resp;
}
function add_nom_captura(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("INSERT INTO nom_captura (AgrupacionID,AreaID,ConceptoID,Ordenacion) VALUES ('$this->AgrupacionID' ,'$this->AreaID' ,'$this->ConceptoID' ,'$this->Ordenacion' ) ");
return $resp;
}
function mod_nom_captura(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("UPDATE nom_captura SET AgrupacionID='$this->AgrupacionID', AreaID='$this->AreaID', ConceptoID='$this->ConceptoID', Ordenacion='$this->Ordenacion'   WHERE AgrupacionID = '$this->AgrupacionID'");
return $resp;
}
function del_nom_captura(){ 
$conexion = new conexion();
$resp = $conexion->ejecutarconsulta("DELETE FROM nom_captura WHERE AgrupacionID = '$this->AgrupacionID' ");
return $resp;
}
}
?>
