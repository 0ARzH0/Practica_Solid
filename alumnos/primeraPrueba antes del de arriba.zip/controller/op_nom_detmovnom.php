<?php

include_once '../model/nom_detmovnom.php';

$op=$_REQUEST['opcion'];

@$detmov_id = $_REQUEST['detmov_id'];
@$Codigo = $_REQUEST['Codigo'];
@$ConceptoID = $_REQUEST['ConceptoID'];
@$TipoNominaID = $_REQUEST['TipoNominaID'];
@$PeriodoID = $_REQUEST['PeriodoID'];
@$Ejercicio = $_REQUEST['Ejercicio'];
if(empty($Ejercicio)){
$Ejercicio = date("Y");
}
@$Unidades = $_REQUEST['Unidades'];
@$Importe = $_REQUEST['Importe'];
@$Saldo = $_REQUEST['Saldo'];
@$Ajuste = $_REQUEST['Ajuste'];
@$Parametro1 = $_REQUEST['Parametro1'];
@$Parametro2 = $_REQUEST['Parametro2'];
@$IngresoDeduc = $_REQUEST['IngresoDeduc'];
@$ImporteAnterior = $_REQUEST['ImporteAnterior'];
@$fechamov = date("Y-m-d");
@$Aprobado = $_REQUEST['Aprobado'];
@$AprobadoUsuarioID = $_REQUEST['AprobadoUsuarioID'];


$nom_detmovnom = new nom_detmovnom($detmov_id,$Codigo,$ConceptoID,$TipoNominaID,$PeriodoID,$Ejercicio,$Unidades,$Importe,$Saldo,$Ajuste,$Parametro1,$Parametro2,$IngresoDeduc,$ImporteAnterior,$fechamov,$Aprobado,$AprobadoUsuarioID);

$nom_detmovnom_gen = new nom_detmovnom('','','','','','','','','','','','','','','','','');

switch($op){

    case 'agregarconceptos':                  
    $Codigos = json_decode($_POST['Codigos'], true);
    $ConceptoIDs = json_decode($_POST['ConceptoIDs'], true);
    $UnidadesImportes = json_decode($_POST['UnidadesImportes'], true);
    $Valores = json_decode($_POST['Valores'], true);
    for ($i=0; $i < count($Codigos) ; $i++) {
    $Importe = 0;
    $Unidades = 0; 
    if($UnidadesImportes[$i]=="10"){ #unidades
    $Unidades = $Valores[$i];
    }else{ #importes
    $Importe = $Valores[$i];
    }
    if($Valores[$i]!=null){
    $nom_detmovnom_1 = new nom_detmovnom("",$Codigos[$i],$ConceptoIDs[$i],$TipoNominaID,$PeriodoID,$Ejercicio,$Unidades,$Importe,$Saldo,$Ajuste,$Parametro1,$Parametro2,$IngresoDeduc,$ImporteAnterior,$fechamov,$Aprobado,$AprobadoUsuarioID);
    $r = $nom_detmovnom_1->get_concepto_empl_uni(); 
    if(mysqli_num_rows($r)>0){
    /*si existe es update*/
    $nom_detmovnom_1->mod_movimiento_conc();
    }else{
    /*si no existe en insert*/
    $nom_detmovnom_1->add_movimiento_conc();
    }
    }
    }
    break;

case 'aprobarconcepto':
    if($_POST['UnidadImporte']=="10"){ #unidades
    $Unidades = $_POST['Valor'];
    }else{ #importes
    $Importe = $_POST['Valor'];
    }

    $nom_detmovnom_1 = new nom_detmovnom($detmov_id,$Codigo,$ConceptoID,$TipoNominaID,$PeriodoID,$Ejercicio,$Unidades,$Importe,$Saldo,$Ajuste,$Parametro1,$Parametro2,$IngresoDeduc,$ImporteAnterior,$fechamov,$Aprobado,$AprobadoUsuarioID);
    if($detmov_id > 0){
     #update   
        $nom_detmovnom_1->mod_movimiento_conc_aprob();
    }else{
     #insert   
        $nom_detmovnom_1->add_movimiento_conc_aprob();
    }
    break;

case 'agregarconceptoempl':
    if($nom_detmovnom->add_movimiento_conc()){ $msj=0; }else{ $msj=0; }
    header("Location:../views/editarempleado.php?msj=".$msj);     
    break;

 case 'eliminarconceptoempl':
    $nom_detmovnom->det_concepto_empl_uni();
    break;   
    default:

     break;
     }
?>
