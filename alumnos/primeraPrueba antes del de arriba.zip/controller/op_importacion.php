<?php 
session_start();
#include_once "../model/funcion_importacion";
include_once "../model/plantillas.php";
include_once "funcion_importacion.php";

$datos_empl_imp = array();
$datos_imp = array();
$cont_txt = 0;
$UsuarioID=$_SESSION['UsuarioID'];
$fechamov=date("Y-m-d H:i:s");
$errores_aux = "";
$errores="Sucesos inesperados o errores: ".chr(13).chr(10);

$plantillas = new plantillas($_SESSION['Nombre'],$_SESSION['TipoUsuario'],1,"Gestor Factor9","");
echo $plantillas->cabecera();

echo "<body class='text-center'>";

echo $plantillas->nav_bar();

		$rutaEnServidor = "../archivos";
		@$rutaTemporal=$_FILES['archivo']['tmp_name'];
		@$nombreImagen=$_FILES['archivo']['name'];
		@$archivo=$rutaEnServidor.'/'.$nombreImagen;
		move_uploaded_file($rutaTemporal, $archivo);

		if (file_exists($archivo)) {
		$fp = fopen($archivo, "r");
		while(!feof($fp)) {
	    	$linea = fgets($fp);
	    	if (strlen($linea)>0) {
				$datos_empl_imp[$cont_txt] = $linea;
	        	$cont_txt++; 
			} 
		}
		fclose($fp);
	    }else{
		echo "el archivo no existe";
		}
        
         /*eliminar archivo txt*/
		if (unlink($archivo)) {
		#echo "el archivo se ha eliminado correctamente";
		}else{
		echo "hubo un error al eliminar el archivo ".$archivo;
		} 
      

	   #arreglo de datos por empl
	   for ($i=0; $i < count($datos_empl_imp) ; $i++){ #inicio del for principal
	   $datos_empl_imp_aux = explode("|", $datos_empl_imp[$i]);
	   $datos_imp[$i] = array("tipobusqueda" =>  intval(preg_replace('/[^0-9]+/', '', $datos_empl_imp_aux[0]), 10),
	   	                      "valorbusqueda" => $datos_empl_imp_aux[1],
	   	                      "EmpresaID" => @$datos_empl_imp_aux[2],
	   	                      "ConceptoID" => @$datos_empl_imp_aux[3],
	   	                      "Unidades" => @$datos_empl_imp_aux[4],
	   	                      "Importe" => @$datos_empl_imp_aux[5],
	   	                      "Saldo" => @$datos_empl_imp_aux[6]);
     
      /*echo "<br>";
      echo "<br>";
      echo "<br>";
      echo "<br>";
      echo "<br>";
      print_r($datos_imp[$i]);
      echo "<br>";*/

      if($datos_imp[$i]['tipobusqueda'] == 1){ #codigo
      $sql_bus = " WHERE e.Estatus = 'A' AND e.Codigo = ".$datos_imp[$i]['valorbusqueda']." ORDER BY e.Codigo ASC";
      $resp = busquedas_importacion($UsuarioID,$sql_bus);
      $valorbusqueda_str = "el Código";

	  $errores_aux = val_insert($valorbusqueda_str,$datos_imp[$i]['valorbusqueda'],$resp,$datos_imp[$i]['Unidades'],$datos_imp[$i]['Importe'],$datos_imp[$i]['Saldo'],$fechamov,$datos_imp[$i]['ConceptoID'],$datos_imp[$i]['EmpresaID']);
      $errores = $errores." ".$errores_aux;      
      }elseif($datos_imp[$i]['tipobusqueda'] == 2){ #codigonominaID
      $sql_bus = " WHERE e.Estatus = 'A' AND e.CodigoNominaID = ".$datos_imp[$i]['valorbusqueda']." AND e.EmpresaID = ".$datos_imp[$i]['EmpresaID']." ";
      $resp = busquedas_importacion($UsuarioID,$sql_bus);
      $valorbusqueda_str = "el Código de nomina";

	  $errores_aux = val_insert($valorbusqueda_str,$datos_imp[$i]['valorbusqueda'],$resp,$datos_imp[$i]['Unidades'],$datos_imp[$i]['Importe'],$datos_imp[$i]['Saldo'],$fechamov,$datos_imp[$i]['ConceptoID'],$datos_imp[$i]['EmpresaID']);
      $errores = $errores." ".$errores_aux;     
      }elseif($datos_imp[$i]['tipobusqueda'] == 3){  #rfc
      	$strlimp= limpiar_metas($datos_imp[$i]['valorbusqueda'],"");
      	$trimmed = trim($strlimp);

      /*$sql_bus = " WHERE e.Estatus = 'A' AND e.Rfc = ' ".$datos_imp[$i]['valorbusqueda']." ' ";*/
      $sql_bus = " WHERE e.Estatus = 'A' AND e.Rfc ='".$trimmed."'";

      $resp = busquedas_importacion($UsuarioID,$sql_bus);
      $valorbusqueda_str = "el RFC";


	  $errores_aux = val_insert($valorbusqueda_str,$datos_imp[$i]['valorbusqueda'],$resp,$datos_imp[$i]['Unidades'],$datos_imp[$i]['Importe'],$datos_imp[$i]['Saldo'],$fechamov,$datos_imp[$i]['ConceptoID'],$datos_imp[$i]['EmpresaID']);
      $errores = $errores." ".$errores_aux;

      }else{
      	$errores = $errores.chr(13).chr(10)."No existe creterio de busqueda (".$datos_imp[$i]['tipobusqueda'].")";
      }
	   
	  }#final del for principal


	  /*Crear reporte de errores*/
	  $tiempo=date("Y-m-d_H-i-s");
	  $nombre_archivo = "../archivos/Errores_".$tiempo.".txt";
	  $archivo = fopen($nombre_archivo, "a");
	  fwrite($archivo,$errores);
	  fclose($archivo); 
 ?>

<section class="container-fluid">
	<section class="well col_lg-12 " style="margin: 4% 0% 4% 0%; min-height: 500px;" >
	     <h2>Bitacora de Errores</h2>
	     <h3><?php echo $fechamov; ?></h3>
	     <div class="form-group">
	    <textarea class="form-control text-center" name="" cols="30" rows="10" readonly>
	    	<?php echo $errores; ?>
	    </textarea> 
	    </div>
	    <div class="form-group">
	    <!-- <a href="../views/menu.php" class="btn btn-danger"><span class="fa fa-arrow-left"></span>&nbsp Atras</a> -->
	    <a href="<?php echo $nombre_archivo; ?>" class="btn btn-primary" target="_blank"><span class="fa fa-download"></span>&nbsp <?php echo "Errores_".$tiempo.".txt"; ?> </a>	
	    </div>
	    
	</section>
</section>
	
</body>

<?php  include_once "../views/footer.php";  ?>

    <script src="../components/jquery/jquery.js"></script>
    <script src="../components/bootstrap/js/bootstrap.min.js"></script>

</html>