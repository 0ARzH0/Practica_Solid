<?php
ob_start();
include_once '../model/nom_catempleados.php';
include_once '../model/nom_movpuestos.php';
include_once '../model/nom_bajas.php';

@$op=$_REQUEST['opcion'];

@$Codigo = $_REQUEST['Codigo'];
@$ApellidoPaterno = strtoupper($_REQUEST['ApellidoPaterno']);
@$ApellidoMaterno = strtoupper($_REQUEST['ApellidoMaterno']);
@$Nombre = strtoupper($_REQUEST['Nombre']);
@$FechaNacimiento = $_REQUEST['FechaNacimiento'];
@$Domicilio = strtoupper($_REQUEST['Domicilio']);
@$Colonia = strtoupper($_REQUEST['Colonia']);
@$Telefono = $_REQUEST['Telefono'];
@$Municipio = strtoupper($_REQUEST['Municipio']);
@$EstadoID = $_REQUEST['EstadoID'];
@$EstadoCivil = $_REQUEST['EstadoCivil'];
@$Sexo = $_REQUEST['Sexo'];
@$Sueldo = $_REQUEST['Sueldo'];
@$FechaIngreso = $_REQUEST['FechaIngreso'];
@$Curp = strtoupper($_REQUEST['Curp']);
@$Rfc = strtoupper($_REQUEST['Rfc']);
@$Imss = strtoupper($_REQUEST['Imss']);
@$DatosInfonavitID = $_REQUEST['DatosInfonavitID'];
@$EmpresaID = $_REQUEST['EmpresaID'];
@$CodigoNominaID = $_REQUEST['CodigoNominaID'];
@$Estatus = $_REQUEST['Estatus'];
@$TipoNominaID = $_REQUEST['TipoNominaID'];
@$CodigoPostal = strtoupper($_REQUEST['CodigoPostal']);
@$Fotografia = $_REQUEST['Fotografia'];
@$CentroCostos = $_REQUEST['CentroCostos'];
@$BancoID = $_REQUEST['BancoID'];
@$NumCuenta = $_REQUEST['NumCuenta'];
@$NumTarjeta = $_REQUEST['NumTarjeta'];
@$ClaveInterbancaria = strtoupper($_REQUEST['ClaveInterbancaria']);
@$TurnoID = $_REQUEST['TurnoID'];
@$RelojID = $_REQUEST['RelojID'];
@$CodigoRelojID = $_REQUEST['CodigoRelojID'];
@$RegistraES = $_REQUEST['RegistraES'];
@$MovID =  intval($_REQUEST['MovID']);
$msj = 0;

/*Vista*/
@$Empleado = $_REQUEST['Empleado'];
@$AgrupacionID = $_REQUEST['AgrupacionID'];
@$Agrupacion = $_REQUEST['Agrupacion'];
@$DepartamentoID = $_REQUEST['DepartamentoID'];
@$Departamento = $_REQUEST['Departamento'];
@$PuestoID = $_REQUEST['PuestoID'];
@$Puesto = $_REQUEST['Puesto'];
@$AreaID = $_REQUEST['AreaID'];
@$Area = $_REQUEST['Area'];
@$EstadoRep = $_REQUEST['EstadoRep'];
@$UsuarioID = $_REQUEST['UsuarioID'];
@$Usuario = $_REQUEST['Usuario'];
@$Antig = $_REQUEST['Antig'];

/*bajas*/
#@$FechaAlta = $_REQUEST['FechaAlta'];
@$FechaBaja = $_REQUEST['FechaBaja'];
@$Motivo = $_REQUEST['Motivo'];
@$MotivoBaja = $_REQUEST['MotivoBaja'];


if(@$MovID == 0){
$nom_movpuestos = new nom_movpuestos("",$AgrupacionID,$AreaID,$DepartamentoID,$PuestoID,"");    
$r2 = $nom_movpuestos->get_movid();
foreach ($r2 as $d){  $MovID = $d['MovID'];  }
}

/*subir foto*/
if(@$_POST['Subir_foto']==1){
$rutaEnServidor='../fotos/empleados';
@$rutaTemporal=$_FILES['imagen']['tmp_name'];
@$nombreImagen=$_FILES['imagen']['name'];
@$Fotografia=$rutaEnServidor.'/'.$nombreImagen;
@$nombreImagen_nvo = "F".$Codigo.".jpg";
@$Fotografia=$rutaEnServidor.'/'.$nombreImagen;
move_uploaded_file($rutaTemporal, $Fotografia);
#cambio de tamaño
@$Fotografia_nvo=$rutaEnServidor.'/'.$nombreImagen_nvo;
if (file_exists($Fotografia)) {
$img_origen = imagecreatefromjpeg($Fotografia);
$img_destino  = imagecreatetruecolor(500, 500);
imagecopyresized($img_destino, $img_origen, 0, 0, 0, 0, 500, 500, imagesx($img_origen), imagesy($img_origen));
imagejpeg($img_destino,$Fotografia_nvo);
unlink($Fotografia);
$Fotografia = $Fotografia_nvo;
}else{ 
#no existe la foto
}
}


$nom_catempleados = new nom_catempleados($Codigo,$ApellidoPaterno,$ApellidoMaterno,$Nombre,$MovID,$FechaNacimiento,$Domicilio,$Colonia,$Telefono,$Municipio,$EstadoID,$EstadoCivil,$Sexo,$Sueldo,$FechaIngreso,$Curp,$Rfc,$Imss,$DatosInfonavitID,$EmpresaID,$CodigoNominaID,$Estatus,$TipoNominaID,$CodigoPostal,$Fotografia,$CentroCostos,$BancoID,$NumCuenta,$NumTarjeta,$ClaveInterbancaria,$TurnoID,$RelojID,$CodigoRelojID,$RegistraES);

$nom_catempleados_gen = new nom_catempleados('','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');

$vw_empleadosporusuario = new vw_empleadosporusuario($Codigo,$ApellidoPaterno,$ApellidoMaterno,$Nombre,$FechaNacimiento,$Domicilio,$Colonia,$Telefono,$Municipio,$EstadoID,$Sexo,$Curp,$Estatus,$CodigoPostal,$CodigoNominaID,$Empleado,$AgrupacionID,$Agrupacion,$DepartamentoID,$Departamento,$PuestoID,$Puesto,$AreaID,$Area,$EstadoRep,$UsuarioID,$Usuario,$Fotografia,$Antig);

$vw_empleadosporusuario_gen = new vw_empleadosporusuario('','','','','','','','','','','','','','','','','','','','','','','','','','','','','');

switch($op){
     
     case 'buscarempleado_nom':
     $r=$vw_empleadosporusuario->bus_vw_empl_nom();
     foreach($r as $d){    
     $data[] = array("label" => utf8_encode($d['Empleado']),
                     "value" => $d['Codigo']);
     } 
     echo json_encode($data);
     break;
     
     case 'buscarempleado_cod':
     $r=$vw_empleadosporusuario->bus_vw_empl_cod();
     foreach($r as $d){    
     $data[] = array("label" => $d['Codigo'],
                     "value" => $d['Codigo']);
     } 
     echo json_encode($data);
     break;

     case 'subir_foto_empl':
     if($nom_catempleados->add_foto_empl()){ $msj =3; }else{ $msj = 47; }
     header("Location:../views/editarempleado.php?msj=".$msj); 
     break;
     
     case 'agregarempleado':
     #validar empleado
     $r = $nom_catempleados->get_empleado_rfc();
     $r1 = $nom_catempleados->get_empleado_curp();
    if(mysqli_num_rows($r)>0){
    $msj = 27;
    }else{
    if(mysqli_num_rows($r1)>0){
    $msj = 28; 
    }else{
    if($nom_catempleados->add_empleado()){ 
    #agregar bajas
    if($Estatus == 'B' ){    
    $nom_bajas = new nom_bajas("",$Codigo,$FechaIngreso,$FechaBaja,$Motivo,$MotivoBaja);
    $nom_bajas->add_bajas();  
    }  
    $msj = 8;
    }else{ $msj = 53;}
    }   
    }   
    header("Location:../views/verempleados.php?msj=".$msj);
    break;

    case 'modificarempleado':
    $r = $nom_catempleados->get_empleado_rfc();
    $r1 = $nom_catempleados->get_empleado_curp();
    if((mysqli_num_rows($r)-1)>0){
    $msj = 27;
    }else{
    if((mysqli_num_rows($r1)-1)>0){
    $msj = 28; 
    }else{
    if($nom_catempleados->mod_empleado()){ 
    if($Estatus == 'B' ){  
    $nom_bajas = new nom_bajas("",$Codigo,$FechaIngreso,$FechaBaja,$Motivo,$MotivoBaja);
    $nom_bajas->add_bajas();    
    }
    $msj = 8;}else{ $msj = 54;}
    }   
    }
    header("Location:../views/verempleados.php?msj=".$msj);
     break;

     default:
     break;
     }
ob_end_flush();
?>