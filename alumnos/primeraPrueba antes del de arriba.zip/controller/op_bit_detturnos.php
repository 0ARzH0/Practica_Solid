<?php

include_once '../model/bit_detturnos.php';

$op=$_REQUEST['opcion'];

@$DetTurnoID = $_REQUEST['DetTurnoID'];
@$TurnoID = $_REQUEST['TurnoID'];
@$DiaID = $_REQUEST['DiaID'];
@$Entrada = $_REQUEST['Entrada'];
@$Salida = $_REQUEST['Salida'];
@$EntradaMD = $_REQUEST['EntradaMD'];
@$SalidaMD = $_REQUEST['SalidaMD'];
@$Descanso = $_REQUEST['Descanso'];

$bit_detturnos = new bit_detturnos($DetTurnoID,$TurnoID,$DiaID,$Entrada,$Salida,$EntradaMD,$SalidaMD,$Descanso);

$bit_detturnos_gen = new bit_detturnos('','','','','','','','');

switch($op){
    case 'agregar':

     break;
    default:

     break;
     }
?>
