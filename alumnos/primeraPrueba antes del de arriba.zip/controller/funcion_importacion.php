<?php 
include_once "../model/conexion.php";
include_once "../model/nom_detmovnom.php";

function busquedas_importacion($UsuarioID,$sql_bus){
$conexion = new conexion();
$sql = "SELECT e.Codigo, CONCAT(e.ApellidoPaterno,' ',e.ApellidoMaterno,' ',e.Nombre) AS Empleado, d.Departamento, a.Agrupacion, e.FechaIngreso, ar.Area, pu.PuestoID, pu.Puesto ,pe.TipoNominaID,pe.FechaInicial,pe.FechaFinal, pe.PeriodoID,pe.Ejercicio 
		FROM nom_catempleados e 
		INNER JOIN nom_movpuestos mp ON e.MovID = mp.MovID 
		INNER JOIN nom_catdepartamentos d ON mp.DepartamentoID = d.DepartamentoID 
		INNER JOIN nom_catnominas n ON n.TipoNominaID = e.TipoNominaID 
		INNER JOIN nom_catperiodos pe ON e.TipoNominaID = pe.TipoNominaID AND pe.Actual = '1' 
		INNER JOIN nom_catagrupaciones a ON a.AgrupacionID = mp.AgrupacionID 
		INNER JOIN nom_catpuestos pu ON mp.PuestoID = pu.PuestoID
		INNER JOIN nom_catareas ar ON mp.AreaID = ar.AreaID
		INNER JOIN seg_catpermisos p ON mp.AgrupacionID = p.AgrupacionID AND p.DepartamentoID=d.DepartamentoID and p.AreaID=ar.AreaID AND p.UsuarioID = $UsuarioID ";
$sql = $sql.$sql_bus;
$resp = $conexion->ejecutarconsulta($sql);
return $resp;
}

function val_insert($valorbusqueda_str,$valorbusqueda,$resp,$Unidades,$Importe,$Saldo,$fechamov,$ConceptoID,$EmpresaID){
$conexion = new conexion();	
$errores = "";
if ( @mysqli_num_rows($resp) >1 || @mysqli_num_rows($resp) ==1) {
	$d = $resp->fetch_array(MYSQLI_ASSOC);
	#validaciones
	$sql2="SELECT * FROM nom_catconceptos WHERE ConceptoID = $ConceptoID AND EmpresaID = $EmpresaID";
	$sql3="SELECT * FROM nom_catempresas WHERE EmpresaID = $EmpresaID";
	$resp3 = $conexion->ejecutarconsulta($sql3);
	if (mysqli_num_rows($resp3)==1) {
		$resp2 = $conexion->ejecutarconsulta($sql2);
		if (mysqli_num_rows($resp2)==1) {
			#Alta de del movimiento
			$nom_detmovnom= new nom_detmovnom("",$d['Codigo'],$ConceptoID,$d['TipoNominaID'],$d['PeriodoID'],$d['Ejercicio'],$Unidades,$Importe,$Saldo,"","","","","",$fechamov,"","");
			$mvtos=$nom_detmovnom->get_concepto_empl_uni();
			if (mysqli_num_rows($mvtos)==0) {
				$nom_detmovnom->add_movimiento_conc();
			}
			else{
				$errores=$errores.chr(13).chr(10)."El empleado con código (".$d['Codigo'].") ya tiene movimientos registrados";
			}
		}
		else{
			$errores=$errores.chr(13).chr(10)."El concepto (".$ConceptoID.") no existe";
		}
	}
	else{
		$errores=$errores.chr(13).chr(10)."La empresa (".$EmpresaID.") no existe";
	}

}
else{
	$errores=$errores.chr(13).chr(10)."No tiene acceso al empleado con ".$valorbusqueda_str." (".$valorbusqueda.") ";	
}	
return $errores;	
}

function limpiar_metas($string,$corte = null)
    {
        $caracters_no_permitidos = array('"',"'");
        # paso los caracteres entities tipo &aacute; $gt;etc a sus respectivos html
        $s = html_entity_decode($string,ENT_COMPAT,'UTF-8');
        # quito todas las etiquetas html y php
        $s = strip_tags($s);
        # elimino todos los retorno de carro
        $s = str_replace("r", '', $s);
        # en todos los espacios en blanco le añado un <br /> para después eliminarlo
        $s = preg_replace('/(?<!>)n/', "<br />n", $s);
        # elimino la inserción de nuevas lineas
        $s = str_replace("n", '', $s);
        # elimino tabulaciones y el resto de la cadena
        $s = str_replace("t", '', $s);
        # elimino caracteres en blanco
        $s = preg_replace('/[ ]+/', ' ', $s);
        $s = preg_replace('/<!--[^-]*-->/', '', $s);
        # vuelvo a hacer el strip para quitar el <br /> que he añadido antes para eliminar las saltos de carro y nuevas lineas
        $s  = strip_tags($s);
        # elimino los caracters como comillas dobles y simples
        $s = str_replace($caracters_no_permitidos,"",$s);
         
        if (isset($corte) && (is_numeric($corte)))
        {
            $s = mb_substr($s,0,$corte, 'UTF-8');
        }
                 
        return $s;
    }

		
?>