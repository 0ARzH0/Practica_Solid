<?php

include_once '../model/nom_vacaciones.php';

@$op=$_REQUEST['opcion'];

@$SolicitudID = $_REQUEST['SolicitudID'];
@$Codigo = $_REQUEST['Codigo'];
@$FechaSolicitud = $_REQUEST['FechaSolicitud'];
@$NumeroDias = $_REQUEST['NumeroDias'];
@$FechaInicio = $_REQUEST['FechaInicio'];
@$FechaTermino = $_REQUEST['FechaTermino'];
@$FechaRegreso = $_REQUEST['FechaRegreso'];
@$Observaciones = $_REQUEST['Observaciones'];
@$ImgFormato = $_REQUEST['ImgFormato'];
@$Cancelado = $_REQUEST['Cancelado'];
@$msj=0; 

$rutaEnServidor='../fotos/comp_vacacion';
@$rutaTemporal=$_FILES['archivo']['tmp_name'];
@$nombrearchivo=$_FILES['archivo']['name'];
@$nombrearchivo_nvo = "E".str_pad($EmpleadoID, 5, "0", STR_PAD_LEFT)."".$SolicitudID.".jpg";
@$ImgFormato=$rutaEnServidor.'/'.$nombrearchivo;
move_uploaded_file($rutaTemporal, $ImgFormato);

@$ImgFormato_nvo=$rutaEnServidor.'/'.$nombrearchivo_nvo;

$nom_vacaciones = new nom_vacaciones($SolicitudID,$Codigo,$FechaSolicitud,$NumeroDias,$FechaInicio,$FechaTermino,$FechaRegreso,$Observaciones,$ImgFormato_nvo,$Cancelado);

$nom_vacaciones_gen = new nom_vacaciones('','','','','','','','','','');

switch($op){

	case 'subirformatovac':
    if (file_exists($ImgFormato)){
    rename ("../fotos/comp_vacacion/".$nombrearchivo, "../fotos/comp_vacacion/".$nombrearchivo_nvo);
    }else{  
    move_uploaded_file($rutaTemporal, $ImgFormato);
    }
    if($nom_vacaciones->add_imgformato()){ $msj = 1; }else{ $msj = 41; }
    header("Location:../views/vervacaciones.php?msj=".$msj);
    break;

    case 'agregarvacaciones':
    if($nom_vacaciones->add_vacaciones()){ $msj = 4; }else{ $msj = 14; }
    header("Location:../views/vervacaciones.php?msj=".$msj);   
    break;
       
    case "FechaTermino":
    $FechaInicio= $_POST['FechaInicio'];
    $NumeroDias = $_POST['NumeroDias'];
    $FechaTermino = "";
    $FechaTermino = strtotime ( "+".$NumeroDias." day" , strtotime ( $FechaInicio) ) ;
    $FechaTermino = date ( 'Y-m-d' , $FechaTermino );
    echo $FechaTermino;
    break;

    default:
    break;
}
?>
