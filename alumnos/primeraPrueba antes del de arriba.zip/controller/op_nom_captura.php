<?php

include_once '../model/nom_captura.php';

$op=$_REQUEST['opcion'];

@$AgrupacionID = $_REQUEST['AgrupacionID'];
@$AreaID = $_REQUEST['AreaID'];
@$ConceptoID = $_REQUEST['ConceptoID'];
@$Ordenacion = $_REQUEST['Ordenacion'];
$msj = 0;

$nom_captura = new nom_captura($AgrupacionID,$AreaID,$ConceptoID,$Ordenacion);

$nom_captura_gen = new nom_captura('','','','');

switch($op){

    case 'agregarconcepto_blobal':
    if($r=$nom_captura->add_concepto()){ $msj=1; }else{ $msj=43; }
    header("Location:../views/ordenacionconceptos.php?msj=".$msj);	
    break; 

    default:
    break;
    }
?>
