<?php

include_once '../model/seg_catusuarios.php';

$op = $_REQUEST['opcion'];

@$UsuarioID = $_POST['UsuarioID'];
@$Nombre = $_POST['Nombre'];
@$Usuario = $_POST['Usuario'];
@$Password = $_POST['Password'];
@$TipoUsuario = $_POST['TipoUsuario'];

$seg_catusuarios = new seg_catusuarios($UsuarioID,$Nombre,$Usuario,$Password,$TipoUsuario);

switch($op){
    case 'iniciar':
     $r=$seg_catusuarios->get_usuario_nom();
     $r1=$seg_catusuarios->get_usuario_pass();
     $r2 =$seg_catusuarios->iniciar_usuario();
     /*verificamos nombre*/
     if(mysqli_num_rows($r) > 0){
     /*verificamos contraseña*/	
     if(mysqli_num_rows($r1) > 0){
     /*traemos los datos del usuario*/	 	
     foreach ($r2 as $d) {
     
     @session_start();
     $_SESSION['UsuarioID'] = $d['UsuarioID'];
     $_SESSION['Nombre'] = $d['Nombre'];
     $_SESSION['Usuario'] = $d['Usuario'];
     $_SESSION['Password'] = $d['Password'];
     $_SESSION['TipoUsuario'] = $d['TipoUsuario'];
     $_SESSION['Verificar'] = 1;
     }
     
     /*dependiendo del TipoUsuario redireccionamos*/
     if($_SESSION['TipoUsuario']==1):#Jefe de Area
     header("Location:../views/grid_captura_user.php");
     elseif($_SESSION['TipoUsuario']==2):#Jefe de Recursos Humanos
     header("Location:../views/menu.php");
     elseif($_SESSION['TipoUsuario']==3):#Administrador
     header("Location:../views/menu.php");
     elseif($_SESSION['TipoUsuario']==4):#Usuario signa permisos
     header("Location:../views/menu.php");
     else:
     header("Location:../views/login.php?msj=4");	
     endif;	
     /*deuelven errores de pass o user*/
     }else{
     header("Location:../views/login.php?msj=44");
     }
     }else{
     header("Location:../views/login.php?msj=43");
     }
     break;

  case 'salir':
     session_start();
     session_destroy();
     header("Location:../views/login.php");
     break;

  case 'modificarusuario':
     $seg_catusuarios->mod_usuario();
     header("Location:../views/perfil.php?msj=1");   
     break;   

 case 'buscarusuario':
     $r = $seg_catusuarios->bus_usuario();
     foreach($r as $d){    
     $data[] = array("label" => $d['Usuario'],
                     "value" => $d['UsuarioID']);
     } 
     echo json_encode($data);
     break;    

 case 'agregarusuario':
     $v = $seg_catusuarios->get_usuario_nom();
     if(mysqli_num_rows($v) > 0){
     header("Location:../views/verpermisos.php?msj=5");
     }else{
     $r = $seg_catusuarios->add_usuario();     
     if($r){
     header("Location:../views/verpermisos.php?msj=4"); 
     }else{
     header("Location:../views/verpermisos.php?msj=2"); 
     }
     }

     break;    

     default:
     break;
     }
?>